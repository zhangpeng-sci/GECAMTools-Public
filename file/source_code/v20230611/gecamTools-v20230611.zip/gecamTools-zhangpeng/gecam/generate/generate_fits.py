#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from astropy.io import fits
import numpy as np
from gecam.utils import file_utils
import os


def generate_spec_fits(det_short_name, counts, counts_err, e_min, e_max, grouping=None, exposure=0,
                       file_save_path=None):
    """
    Generate energy spectrum fits file
    :param det_short_name: str;
        detector name, eg,
         GRD01 low gain:bg01L,
         GRD02 high gain:bg02H
    :param counts:
    :param counts_err:
    :param e_min:
    :param e_max:
    :param grouping:
    :param exposure:
    :param file_save_path:
    :return:
    """
    if grouping is None:
        grouping = np.ones(e_min.size)

    channels = np.arange(0, e_min.size)

    hdu0 = fits.PrimaryHDU()
    # hdu[0].header['SIMPLE']  = ( T ,' file does conform to FITS standard')
    # hdu[0].header['BITPIX']  = (16 ,' number of bits per data pixel')
    # hdu[0].header['NAXIS']   = ( 0 ,' number of data axes')
    # hdu[0].header['EXTEND']  = ( T ,' FITS dataset may contain extensions')
    # COMMENT  FITS (Flexible Image Transport System) format is defined in 'Astronomy
    # COMMENT   and Astrophysics', volume 376, page 359; bibcode: 2001A&A...376..359H

    col_channel = fits.Column(name='CHANNEL', format='1I', array=channels)
    col_e_min = fits.Column(name='E_MIN', format='1E', array=e_min)
    col_e_max = fits.Column(name='E_MAX', format='1E', array=e_max)
    hdu_ebounds = fits.BinTableHDU.from_columns([col_channel, col_e_min, col_e_max])
    hdu_ebounds.header['EXTNAME'] = ('EBOUNDS', 'name of this binary table extension')
    hdu_ebounds.header['TTYPE1'] = ('CHANNEL ', '')
    hdu_ebounds.header['TFORM1'] = ('I', '')
    hdu_ebounds.header['TUNIT1'] = ('  ', 'physical unit of field')

    hdu_ebounds.header['TTYPE2'] = ('E_MIN', '')
    hdu_ebounds.header['TFORM2'] = ('1E', '')
    hdu_ebounds.header['TUNIT2'] = ('keV', 'physical unit of field')

    hdu_ebounds.header['TTYPE3'] = ('E_MAX', '')
    hdu_ebounds.header['TFORM3'] = ('1E', '')
    hdu_ebounds.header['TUNIT3'] = ('keV', 'physical unit of field')

    col1 = fits.Column(name='CHANNEL', format='1J', array=channels)
    col2 = fits.Column(name='COUNTS', format='1D', array=counts)
    col3 = fits.Column(name='STAT_ERR', format='1D', array=counts_err)
    col4 = fits.Column(name='GROUPING', format='1I', array=grouping)
    hdu1 = fits.BinTableHDU.from_columns([col1, col2, col3, col4])
    hdu1.header['LONGSTRN'] = ('OGIP 1.0', 'The HEASARC Long String Convention may be used')
    # hdu1.header['XTENSION']= ('BINTABLE', 'binary table extension')
    # hdu1.header['BITPIX']= (8 ,'8-bit bytes')
    # hdu1.header['NAXIS']= (2 ,'2-dimensional binary table')
    # hdu1.header['NAXIS1']= (16 ,'width of table in bytes')
    # hdu1.header['NAXIS2']= (1536 ,'number of rows in table')
    # hdu1.header['PCOUNT']= ( 0 ,'size of special data area')
    # hdu1.header['GCOUNT']= ( 1 ,'one data group (required keyword)')
    # hdu1.header['TFIELDS']= ( 3 ,'number of fields in each row')
    hdu1.header['TTYPE1'] = ('CHANNEL ', 'label for field   1')
    hdu1.header['TFORM1'] = ('1J', 'data format of field: 4-byte INTEGER')
    hdu1.header['TUNIT1'] = ('  ', 'physical unit of field')
    hdu1.header['TTYPE2'] = ('COUNTS', 'label for field   2')
    hdu1.header['TFORM2'] = ('1J', 'data format of field: 4-byte INTEGER')
    hdu1.header['TUNIT2'] = ('counts', 'physical unit of field')
    hdu1.header['TTYPE3'] = ('STAT_ERR', 'label for field   3')
    hdu1.header['TFORM3'] = ('1D', 'data format of field: 8-byte DOUBLE')
    hdu1.header['TUNIT3'] = ('counts', 'physical unit of field')
    hdu1.header['EXTNAME'] = ('SPECTRUM', 'name of this binary table extension')
    hdu1.header['DETCHANS'] = (channels.size, 'Total no. detector channels available')
    hdu1.header['TELESCOP'] = ('GECAM', ' Telescope (mission) name')
    hdu1.header['INSTRUME'] = ('GRD', ' Instrument name')
    hdu1.header['DETNAME'] = (det_short_name, ' Name of the detector')
    hdu1.header['BACKFILE'] = ('NONE', ' background FITS file for this object')
    hdu1.header['BACKSCAL'] = (1.0000000000E+00, 'background scaling factor')
    hdu1.header['CORRFILE'] = ('NONE', ' correlation FITS file for this object')
    hdu1.header['CORRSCAL'] = (1.0000000000E+00, 'correlation scaling factor')
    hdu1.header['FILTER'] = ('NONE', 'redistribution matrix file(RMF)')
    hdu1.header['PHAVERSN'] = ('1992a', 'OGIP classification of FITS format')
    # define rsp name
    # detID=fitsname[-7:-5]
    # detID='docs/rspgenerator_CLI_GECAM_FITS/det' +detID
    # hdu1.header['RESPFILE']= (detID+'.rsp' ,'RSP')
    hdu1.header['RESPFILE'] = ('NONE', 'RSP')
    hdu1.header['ANCRFILE'] = ('NONE', 'ARF')
    hdu1.header['STATERR'] = (False, 'no statisical error specified')
    hdu1.header['SYSERR'] = (False, 'no systematic error')
    hdu1.header['POISSERR'] = (False, 'Poissonian statistical errors to be assumed')
    hdu1.header['GROUPING'] = (0, 'grouping of the data has been defined')
    hdu1.header['QUALITY'] = (0, 'data quality information specified')
    hdu1.header['AREASCAL'] = (1, 'area scaling factor')
    # datatype=glv.datatype
    # if datatype=='DATA':
    #   hdu1.header['EXPOSURE']= ( glv.timeinterval_ROI_cor[detID],'exposure time')
    # else:
    #   hdu1.header['EXPOSURE']= ( glv.timeinterval_ROI,'exposure time')
    hdu1.header['EXPOSURE'] = (exposure, 'mean exposure time')
    # hdu1.header['LIVETIME'] = (2.00000E+04, 'Total spectrum accumulation time')
    # hdu1.header['DEADC'] = (5.19000E+02, ' Deadtime correction factor')

    fits_obj = fits.HDUList([hdu0, hdu_ebounds, hdu1])

    if file_save_path is not None:
        file_utils.check_dir_exit(os.path.dirname(file_save_path))

        fits_obj.writeto(file_save_path, overwrite=True)
    else:
        return fits_obj
