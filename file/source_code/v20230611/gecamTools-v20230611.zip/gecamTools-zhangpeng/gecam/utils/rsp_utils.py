# rsp_utils.py: 
#
#     Authors:Peng Zhang (IHEP),
#           
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import warnings
import os


def check_CALDB_decorator(func):
    """
        check if the CALDB is installed correctly
    Args:
        func:

    Returns:

    """

    def _deco(*args, **kwargs):
        try:
            from RSP_Generator import gen_rsp_fits

            return func(*args, **kwargs)
        except Exception as e:
            warnings.warn("CALDB is not installed correctly, operation terminated.")

            return ""

    return _deco


def get_CALDB_version():
    """
    get the version of CALDB from dictionary name
    Returns:

    """
    try:
        from RSP_Generator import get_version
        return get_version()
    except:
        return "00"


@check_CALDB_decorator
def generate_rsp_fits(det_name: str, theta: float, phi: float, met: float, event_type="evt", out_dir: str = None,
                      out_path: str = None, file_uid=None):
    """
        Generate a response matrix in fits format

    Args:

        det_name (str): det_name, GRD:[a/b]g[01-25][H/L]，CPD:[a/b]c[01-08]
        theta (float): incident angle theta
        phi (float): incident angle phi
        met (float): met
        event_type (str):  evt/bspec/btime
        out_dir (str): saving dir(if out_dir is None,out_dir='./')
                    format of file name:g[a/b/c][g/c]_XX[H/L/S]_[x/e/p]_[evt/bspec/btime]_[file_uid]_vXX.rsp
                    (1)g:GECAM; a/b/c:satellite; g/c: grd or cpd
                    (2)XX[H/L/S]:detector number; H:high-gain; L:low gain; S: single channel detector
                    (3)x/e/p: Photons, electrons, protons；
                    (4)evt/bspec/btime: event type；
                    (5)file_uid: sign of file create time
                    (6)vXX: version of CALDB
        out_path (str): saving total path (if out_path is None, output to out_dir)
        file_uid (str,optional):  sign of file create time

    Returns:
        success_sig (bool): if success to generate rsp file: True

    """

    try:
        from RSP_Generator import gen_rsp_fits

        CALDB_version = get_CALDB_version()

        if out_path is None:
            if out_dir is None:
                out_dir = "./"

            if file_uid is None:
                rsp_out_path = f"{out_dir}" \
                               f"g{det_name[:2]}_{det_name[2:]}_x_{event_type}_v{CALDB_version}.rsp"
            else:
                rsp_out_path = f"{out_dir}" \
                               f"g{det_name[:2]}_{det_name[2:]}_x_{event_type}_{file_uid}_v{CALDB_version}.rsp"
        else:
            rsp_out_path = out_path

        gen_rsp_fits(det_name, theta, phi, fits_filepath=rsp_out_path, is_overwrite=True,
                            event_type=event_type, particle='gamma', MET=met)

        return rsp_out_path

    except Exception as e:
        warnings.warn(f"Failed to generate response matrix. reason:{e}")

        return ""
