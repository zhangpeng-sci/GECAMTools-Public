# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/07/25/0025 22:29
@Version:1.0
@Desc   :


"""
import numpy as np
from gecam.utils import fit_utils
from gecam import config
from collections import OrderedDict
import math


def generate_net_lc_and_spec(time_list, PI_list, channel_range_list, bg_time_range_list, time_bins, dead_time_bins,
                             bg_fit_order, source_time_range):
    """
    extract net light curve and energy spectrum on source

    :param dead_time_list:
    :param time_list:np.array,
        receive time of photon.
    :param PI_list:np.array,
        channels of photon.
    :param channel_range_list:list,
        list of channel range. eg. [  [channel_start,channel_stop],[] ]
    :param source_time_range:list,
        source time range
    :param bg_time_range_list:list,
        background time range list. [  [bg_time_start,bg_time_stop] ]
    :param time_bins:
    :param bg_fit_order:
    :return: tuple ( source light curve, source energy spectrum, bg_fit_info_dic)

       light curve: (lc_x_source, lc_y_source, bg_lc_y_source, net_lc_y_source)
           lc_x_source:np.array, time of light curves in one energy channel on source
           lc_y_source:np.array, counts of light curves in each energy channel on source
           bg_lc_y_source:np.array, counts of background light curves in each energy channel on source
           net_lc_y_source:np.array, counts of net light curves in each energy channel on source

       energy spectrum: (es_source, bg_es_source, net_es_source)
            es_source:np.array, energy_spectrum on source
           bg_es_source:np.array, background energy_spectrum on source
           net_es_source:np.array, net energy_spectrum on source

       bg_fit_info_dic[f"{channel_start}-{channel_stop}"] = {
            "time_bin": time_bins, "time_range": time_range_all,
            "lc_x": lc_x, "lc_y": lc_y, "lc_deadtime": lc_deadtime,
            "bg_time_range": bg_time_range_list,
            "bg_fit_y": lc_bg_fit_y, "bg_fit_y_err": lc_bg_fit_y_err, "bg_fit_info": bg_fit_info
        }
    """

    from gecam.utils import fit_utils

    single_channel_lc_x = None
    channel_lc_y = None
    channel_bg_lc_y = None
    channel_net_lc_y = None

    bg_fit_info_dic = OrderedDict()

    exposure_on_bins = np.diff(time_bins) - dead_time_bins

    for index, (channel_start, channel_stop) in enumerate(channel_range_list):
        channel_filter = np.where((PI_list >= channel_start) & (PI_list < channel_stop))

        # get light curve in all time range
        channel_filtered_time = time_list[channel_filter]
        lc_x, lc_y, _ = generate_lc(channel_filtered_time, time_bins)

        background_fitter = fit_utils.BackgroundFitter()
        lc_bg_fit_y, lc_bg_fit_y_err, bg_fit_result = background_fitter.fit(lc_x, np.diff(time_bins), lc_y,
                                                                            bg_time_range_list, bg_fit_order,
                                                                            dead_time_bins)

        bg_fit_info_dic[f"{channel_start}-{channel_stop}"] = {
            "time_bins": time_bins,
            "lc_x_all": lc_x, "lc_y_all": lc_y, "lc_deadtime_all": dead_time_bins,
            "bg_time_range": bg_time_range_list,
            "bg_fit_y": lc_bg_fit_y, "bg_fit_y_err": lc_bg_fit_y_err, "bg_fit_result": bg_fit_result
        }

        # fit background
        # bg_lc_x_all, bg_lc_y_all = joint_background_from_lc(lc_x, lc_y, bg_time_range_list)
        # bg_fit_func, params, params_error = fit_utils.get_poly_fit_func(bg_lc_x_all, bg_lc_y_all,
        #                                                                 fit_order=bg_fit_order)
        # fit background in all time range
        # lc_fit_by_bg_y = bg_fit_func(lc_x)

        # get net light curve
        net_lc_y = lc_y - lc_bg_fit_y

        if single_channel_lc_x is None:
            single_channel_lc_x = lc_x
            channel_lc_y, channel_bg_lc_y, channel_net_lc_y = lc_y, lc_bg_fit_y, net_lc_y
        else:
            channel_lc_y = np.vstack((channel_lc_y, lc_y))
            channel_bg_lc_y = np.vstack((channel_bg_lc_y, lc_bg_fit_y))
            channel_net_lc_y = np.vstack((channel_net_lc_y, net_lc_y))

    # filter source light curve and energy spectrum
    source_start, source_stop = source_time_range
    s_start_index = np.where(single_channel_lc_x <= source_start)[0][-1]
    s_stop_index = np.where(single_channel_lc_x > source_stop)[0][0]
    s_time_len = single_channel_lc_x[s_stop_index] - single_channel_lc_x[s_start_index]

    # cut source light curve
    lc_x_source = single_channel_lc_x[s_start_index:s_stop_index]
    lc_y_source = channel_lc_y[:, s_start_index:s_stop_index]
    bg_lc_y_source = channel_bg_lc_y[:, s_start_index:s_stop_index]
    net_lc_y_source = channel_net_lc_y[:, s_start_index:s_stop_index]

    # es:energy spectrum
    es_source = np.sum(lc_y_source, axis=1)
    es_source_err = np.sqrt(es_source)
    es_exposure = np.array([exposure_on_bins[s_start_index:s_stop_index].sum()] * len(channel_range_list))

    bg_es_source = np.sum(bg_lc_y_source, axis=1)
    bg_es_source_err = np.sqrt(bg_es_source)
    bg_es_exposure = np.array([s_time_len] * len(channel_range_list))

    net_es_source = np.sum(net_lc_y_source, axis=1)
    net_es_source_err = np.sqrt(es_source_err + bg_es_source_err)
    net_es_exposure = np.array([s_time_len] * len(channel_range_list))

    result_lc = (lc_x_source, lc_y_source, bg_lc_y_source, net_lc_y_source)
    result_energy_spectrum = (
        es_source, es_source_err, es_exposure, bg_es_source, bg_es_source_err, bg_es_exposure, net_es_source,
        net_es_source_err, net_es_exposure)

    return result_lc, result_energy_spectrum, bg_fit_info_dic


def generate_time_bins(time_range, time_bin, trig_time=None):
    """
        generate time bins, ensure trig_time is the left edge of one bin.
        if trig_time out of time_range, always keep trig_time is the left edge of time_bins.
    Args:
        time_range (tuple): time range
        time_bin (float):  time bin, eg. 1s, 0.1s
        trig_time (float,optional):  trigger time
            if trigger_time is None, trigger time will be set to time_range[0]

    Returns:
        time_bins (np.array): time bins

        eg1:
            time_range=(-2, 2), time_bin=0.3, trig_time=None
            return: [-2.  -1.7 -1.4 -1.1 -0.8 -0.5 -0.2  0.1
                    0.4  0.7  1.   1.3  1.6  1.9 2.2]

        eg2:
            time_range=(-2, 2), time_bin=0.3, trig_time=0
            return: [-2.1 -1.8 -1.5 -1.2 -0.9 -0.6 -0.3  0.
                    0.3  0.6  0.9  1.2  1.5  1.8 2.1]
    """
    if type(time_bin) not in [int, float]:
        return np.array(time_bin)

    start_time, stop_time = time_range

    if trig_time is None:
        trig_time = start_time

    if trig_time < start_time or trig_time > stop_time:
        # if trig_time out of time_range, always keep trig_time is the left edge of time_bins
        start_time = trig_time - ((trig_time - start_time) // time_bin) * time_bin
        time_bins = np.arange(start_time, stop_time + time_bin, time_bin)
        return time_bins
    else:
        pre_time_bins = np.arange(trig_time, start_time - time_bin, -time_bin)
        post_time_bins = np.arange(trig_time, stop_time + time_bin, time_bin)
        time_bins = np.hstack((pre_time_bins[::-1], post_time_bins[1:]))
        return time_bins


def generate_dead_time(time_array, time_bins, dead_time_array):
    dead_t_bins_pre = np.unique(dead_time_array)  #
    dead_t_bins = np.append(dead_t_bins_pre, dead_t_bins_pre.max() + 1)

    y, (time_x, dead_t_x) = np.histogramdd((time_array, dead_time_array), (time_bins, dead_t_bins))

    # time_bins_counts = np.sum(y, axis=1)

    time_bins_dead_time = np.multiply(y, dead_t_bins_pre) * 1e-6
    time_bins_dead_time_all = np.sum(time_bins_dead_time, axis=1)

    return time_bins_dead_time_all


def generate_lc(time_array, time_bins, dead_time_array=None) -> tuple:
    """
    get light curve
    :param time_array: time data: np.array
    :param time_bin : time bin width(second), such as: 1s, 2s, etc
    :param time_range: tuple, (start_time,stop_time)
    :param dead_time_array: np.array, dead time
    :return:
        (light curve x, light curve y):np.array
    """
    time_bins_width = np.diff(time_bins)
    if dead_time_array is not None and time_array.size > 0:
        # Corrected photon count for dead time

        dead_t_bins_pre = np.unique(dead_time_array)  #
        dead_t_bins = np.append(dead_t_bins_pre, dead_t_bins_pre.max() + 1)

        y, (time_x, dead_t_x) = np.histogramdd((time_array, dead_time_array), (time_bins, dead_t_bins))

        time_bins_counts = np.sum(y, axis=1)

        time_bins_dead_time = np.multiply(y, dead_t_bins_pre) * 1e-6
        time_bins_dead_time_all = np.sum(time_bins_dead_time, axis=1)

        time_bins_exposure = time_bins_width - time_bins_dead_time_all
        time_bins_exposure_rate = time_bins_exposure / time_bins_width

        # correct counts by exposure rate  95%
        exposure_beyond_rate_index = np.where(time_bins_exposure_rate < config.EXPOSURE_MAX_RATE)

        temp_ones = np.ones(time_bins_counts.shape)
        temp_ones[exposure_beyond_rate_index] = time_bins_exposure_rate[exposure_beyond_rate_index]
        time_bins_counts_final = time_bins_counts / temp_ones

        # time_bins_counts_final = time_bins_counts / time_bins_exposure_rate

        lc_x = time_x[:-1]
        lc_y = time_bins_counts_final
        lc_exposure = time_bins_exposure

    else:
        lc_y, lc_x = np.histogram(time_array, bins=time_bins)
        lc_x = lc_x[:-1]

        lc_exposure = time_bins_width

    return lc_x, lc_y, lc_exposure


def generate_spec(energy_array, energy_range, energy_bin=1, bins=None) -> tuple:
    """
    generate energy spectrum
    :param energy_array:energy array
    :param energy_bin:energy bin width
    :return:
        (energy spectrum x, energy spectrum y):np.array
    """

    if bins is None:
        bins = np.arange(energy_range[0], energy_range[1] + energy_bin, energy_bin)

    y, x = np.histogram(energy_array, bins=bins)

    return x[:-1], y


def joint_background_from_lc(lc_x, lc_y, bg_time_range_list):
    """
    The background light curve is captured from all
    the light curve based on the multi-segment background time input.
    :param lc_x: np.array
    :param lc_y: np.array
    :param bg_time_range_list: list, eg.
            [
                [background_time_start,background_time_stop]
            ]
    :return:
        lc_bg_x_all:concatenated background light curve x
        lc_bg_y_all:concatenated background light curve y
    """
    lc_bg_x_all = np.array([])
    lc_bg_y_all = np.array([])
    for bg_time_start, bg_time_stop in bg_time_range_list:
        lc_bg_filter = np.where((lc_x >= bg_time_start) & (lc_x < bg_time_stop))
        lc_bg_x = lc_x[lc_bg_filter]
        lc_bg_y = lc_y[lc_bg_filter]
        lc_bg_x_all = np.concatenate((lc_bg_x_all, lc_bg_x))
        lc_bg_y_all = np.concatenate((lc_bg_y_all, lc_bg_y))

    return lc_bg_x_all, lc_bg_y_all


def cutoff_line(x, y, x_range):
    x_start, x_stop = x_range
    x_filter = np.where((x >= x_start) & (x < x_stop))

    x_filter_indexs = x_filter[0]

    return x[x_filter], y[x_filter]


def curve_background_fit(curve_x, curve_y, bg_x_range, poly_order):
    """
    fit background
    :param curve_x:
    :param curve_y:
    :param bg_x_range: eg. BG_TIME_RANGE = [(-40, -5), (60, 100)]
    :param poly_order:
    :return:
    """
    bg_pre_x_start, bg_pre_x_stop = bg_x_range[0]
    bg_post_x_start, bg_post_x_stop = bg_x_range[1]

    # get pre-background
    bg_pre_index = np.where((curve_x >= bg_pre_x_start) & (curve_x < bg_pre_x_stop))
    bg_pre_x = curve_x[bg_pre_index]
    bg_pre_y = curve_y[bg_pre_index]

    # get post-background
    bg_post_index = np.where((curve_x >= bg_post_x_start) & (curve_x < bg_post_x_stop))
    bg_post_x = curve_x[bg_post_index]
    bg_post_y = curve_y[bg_post_index]
    # concatenate background
    bg_x = np.concatenate((bg_pre_x, bg_post_x))
    bg_y = np.concatenate((bg_pre_y, bg_post_y))

    # polynomial fit background
    fit_func = fit_utils.get_poly_fit_func(bg_x, bg_y, poly_order)

    return fit_func(curve_x)


def calculate_time_duration(curve_x, curve_y, bg_x_range, poly_order, category="T90"):
    """
    fit background

    :param curve_x:
    :param curve_y:np.ndarray
        2D light curve array, shape(M,N), M:channel, N:time bins
    :param bg_x_range: list
        eg. BG_TIME_RANGE = [(-40, -5), (60, 100)]
    :param poly_order:
    :param category:(str) T90 or T50
    :return:
    """
    if category == "T90":
        factor = 0.05
    elif category == "T50":
        factor = 0.25
    else:
        raise ValueError("Input category should be T90 or T50")
    # get background counts
    bg_y = curve_background_fit(curve_x, curve_y, bg_x_range, poly_order)
    # get pure counts
    curve_net_y = curve_y - bg_y
    # get cumulative counts
    curve_cumulate_y = np.cumsum(curve_net_y)

    bg_pre_x_start, bg_pre_x_stop = bg_x_range[0]
    bg_post_x_start, bg_post_x_stop = bg_x_range[1]

    # get pre-background
    bg_pre_index = np.where((curve_x >= bg_pre_x_start) & (curve_x < bg_pre_x_stop))
    bg_pre_x = curve_x[bg_pre_index]
    pre_cumulate_y = curve_cumulate_y[bg_pre_index]

    pre_fit_func = fit_utils.get_poly_fit_func(bg_pre_x, pre_cumulate_y, poly_order)
    pre_cumulate_fit_y = pre_fit_func(bg_pre_x)
    pre_cumulate_fit_y_mean = np.mean(pre_cumulate_fit_y)

    # get post-background
    bg_post_index = np.where((curve_x >= bg_post_x_start) & (curve_x < bg_post_x_stop))
    bg_post_x = curve_x[bg_post_index]
    post_cumulate_y = curve_cumulate_y[bg_post_index]

    post_fit_func = fit_utils.get_poly_fit_func(bg_post_x, post_cumulate_y, poly_order)
    post_cumulate_fit_y = post_fit_func(bg_post_x)
    post_cumulate_fit_y_mean = np.mean(post_cumulate_fit_y)

    # calculate duration
    y_len = post_cumulate_fit_y_mean - pre_cumulate_fit_y_mean
    T_y_start = pre_cumulate_fit_y_mean + y_len * factor
    T_y_stop = post_cumulate_fit_y_mean - y_len * factor

    T_start_index = np.where(curve_cumulate_y > T_y_start)[0][0]
    T_stop_index = np.where(curve_cumulate_y > T_y_stop)[0][0]

    T_start = curve_x[T_start_index]
    T_stop = curve_x[T_stop_index]

    T = T_stop - T_start

    return T_start, T
