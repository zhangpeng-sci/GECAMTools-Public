# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/08/08/0008 19:32
@Version:1.0
@Desc   :


"""

import os


def check_dir_exit(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
