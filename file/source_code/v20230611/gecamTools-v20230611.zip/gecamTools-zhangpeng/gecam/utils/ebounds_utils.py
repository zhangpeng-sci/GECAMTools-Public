# ebounds_utils.py: 
#
#     Authors:Peng Zhang (IHEP),
#           
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import numpy as np
import warnings


def get_energy_range(ebounds):
    e_min = ebounds.field("E_MIN")
    e_max = ebounds.field("E_MAX")

    return [e_min[0], e_max[-1]]


def get_channel_range(ebounds):
    return [0, len(ebounds)]


def generate_grouping_by_channel_bins(ebounds, channel_bins, counts_on_bins, counts_err_on_bins):
    """
    generate grouping flag
    Args:
        ebounds:
        channel_bins (list):
        counts_on_bins (np.array):

    Returns:

    """
    channel_len = len(ebounds)

    grouping_flag = np.zeros(channel_len)
    grouping_counts = np.zeros(channel_len)
    grouping_counts_err = np.zeros(channel_len)

    channel_start = channel_bins[0]
    for index, channel_stop in enumerate(channel_bins[1:]):
        grouping_flag[channel_start + 1:channel_stop] = -1
        grouping_flag[channel_start] = 1
        grouping_counts[channel_start] = counts_on_bins[index]
        grouping_counts_err[channel_start] = counts_err_on_bins[index]

        channel_start = channel_stop
    return grouping_flag, grouping_counts, grouping_counts_err


def find_channels_by_energy_list(ebounds, energy_list):
    """
    find channel index by energy
    Args:
        ebounds (np.array): [channel, energy_min, energy_max]
        energy (float): energy

    Returns:
        index of channel (int)

    Raises:
        The input energy exceeds the energy range

    """
    result = []

    for energy in energy_list:
        channel = find_channel_by_energy(ebounds, energy)

        result.append(channel)

    return np.array(result)


def find_channel_by_energy(ebounds, energy):
    """
    find channel index by energy
    Args:
        ebounds (np.array): [channel, energy_min, energy_max]
        energy (float): energy

    Returns:
        index of channel (int)

    Raises:
        The input energy exceeds the energy range

    """
    # Since the energy of the last 50 energy channels of GECAM is not increasing,
    # only the first 448 is taken
    ebounds = ebounds[:448]

    if energy > ebounds.field("E_MAX")[-1]:
        return len(ebounds) - 1

    # channels = ebounds.field("CHANNEL")
    e_min = ebounds.field("E_MIN")
    e_max = ebounds.field("E_MAX")

    if energy < e_min[0]:
        # warnings.warn(f"The input energy:{energy} is beyond the energy range ({e_min[0]} to {e_max[-1]}).")
        return 0
    elif energy > e_max[-1]:
        # warnings.warn(f"The input energy:{energy} is beyond the energy range ({e_min[0]} to {e_max[-1]}).")
        return len(ebounds) - 1

    c_index_list = np.where((energy >= e_min) & (energy < e_max))[0]
    if len(c_index_list) == 0:
        raise Exception(f"The input energy:{energy} is beyond the energy range ({e_min[0]} to {e_max[-1]}).")

    return c_index_list[-1]


def find_channel_range_by_energy_range(ebounds, energy_range):
    pre_e = find_channel_by_energy(ebounds, energy_range[0])
    post_e = find_channel_by_energy(ebounds, energy_range[1])

    return [pre_e, post_e]


def find_energy_range_by_channel_range(ebounds, channel_range):
    pre_e_start, pre_e_stop = find_energy_range_by_channel(ebounds, channel_range[0])
    post_e_start, post_e_stop = find_energy_range_by_channel(ebounds, channel_range[1])

    return [pre_e_start, post_e_stop]


def find_energy_range_by_channel(ebounds, channel_index):
    """
    find find_energy_range_by_channel by channel_index
    Args:
        ebounds (np.array): [channel, energy_min, energy_max]
        channel_index (int): channel from 0 to 497

    Returns:
        energy range (tuple)

    Raises:
        The input channel_index exceeds the channel_index range

    """
    channels = ebounds.field("CHANNEL")

    if channel_index < 0:
        channel_index = 0
    elif channel_index >= len(channels):
        channel_index = len(channels) - 1

    return list(ebounds[channel_index])[1:]


def channel_bins_to_energy_bins(channel_bins, ebounds):
    energy_bins = []
    for index, c in enumerate(channel_bins):
        e_start, e_stop = find_energy_range_by_channel(ebounds, c)

        if index == len(channel_bins) - 1:
            energy_bins.append(e_stop)
        else:
            energy_bins.append(e_start)

    return np.array(energy_bins)
