# feature_utils: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import numpy as np

from gecam.data.curve import LightCurve, BackgroundLightCurve


def cal_time_duration(lc: LightCurve, bg_lc: BackgroundLightCurve, bg_range_list, category="T90"):
    """
    fit background

    :param curve_x:
    :param curve_y:np.ndarray
        2D light curve array, shape(M,N), M:channel, N:time bins
    :param bg_x_range: list
        eg. BG_TIME_RANGE = [(-40, -5), (60, 100)]
    :param poly_order:
    :param category:(str) T90 or T50
    :return:
    """
    if category == "T90":
        factor = 0.05
    elif category == "T50":
        factor = 0.25
    else:
        raise ValueError("Input category should be T90 or T50")

    # TODO: 如果直接
    lc_x, lc_y, lc_y_err = lc.get_data()

    bg_lc_x, bg_lc_y, bg_lc_y_err = bg_lc.get_data()

    net_lc_y = lc_y - bg_lc_y

    net_lc_cumulate_y = np.cumsum(net_lc_y)
