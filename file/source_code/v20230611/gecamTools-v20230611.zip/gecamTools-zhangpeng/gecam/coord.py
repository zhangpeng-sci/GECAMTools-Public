# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 11:45:19 2020
@author: huangyue
"""

import numpy as np
from scipy.linalg import norm
from scipy.spatial.transform import Rotation
from astropy.coordinates import SkyCoord
from astropy import units as u
import astropy.coordinates as coordinates
import astropy.time
from astropy.io import fits
import os


# from time_conversion import met2utc, utc2met

def quat(q1, q2, q3, q0):
    """
    q1 np.array
    """
    q1 = np.asarray(q1)
    q2 = np.asarray(q2)
    q3 = np.asarray(q3)
    q0 = np.asarray(q0)
    if q1.size != q2.size or q1.size != q3.size or q1.size != q0.size:
        raise ValueError(" 'q1', 'q2', 'q3', 'q0' must have the same length! ")
    # if q1.ndim != 1 or q2.ndim != 1 or q3.ndim != 1 or q0.ndim != 1:
    #     raise ValueError("'q1', 'q2', 'q3', 'q0' expected to have shape (1xN)! ")

    quat = np.array([q1, q2, q3, q0])
    return quat.T  # N-by-4


def normalize(quat):
    norms = norm(quat, axis=1)
    zero_norms = norms == 0

    return quat[~zero_norms] / norms[~zero_norms][:, None]


def calc_q0(q1, q2, q3):
    return np.sqrt(1 - q1 ** 2 - q2 ** 2 - q3 ** 2)


def thetaphi_to_cartesian(theta, phi, deg=True):
    """Convert spacecraft theta/phi to Cartesian coordinates
    Args:
        theta (float or np.array): Spacecraft theta. Angle between the vector and the Z axis.
        phi (float or np.array): Spacecraft phi
        deg (bool, optional): True (default) if input is in degrees,
                              otherwise input is radians
    Returns:
        np.array: 3-element Cartesian coordinate
    """
    if deg:
        theta = np.deg2rad(theta)
        phi = np.deg2rad(phi)

    return np.array(
        [np.sin(theta) * np.cos(phi), np.sin(theta) * np.sin(phi), np.cos(theta)])


def radec_to_cartesian(ra, dec, r, deg=True):
    """Convert RA/Dec to Cartesian coordinates
    Args:
        ra (float or np.array): Right Ascension
        dec (float or np.array): Declination
        deg (bool, optional): True (default) if input is in degrees,
                              otherwise input is radians
    Returns:
        np.array: 3-element Cartesian coordinate
    """
    if deg:
        ra = np.deg2rad(ra)
        dec = np.deg2rad(dec)

    return np.array(
        [r * np.cos(dec) * np.cos(ra), r * np.cos(dec) * np.sin(ra), r * np.sin(dec)])


def cartesian_to_radec(x, y, z, deg=True):
    """
    Convert cartesian coordinate to ra/dec.
    """
    c = SkyCoord(x=x, y=y, z=z, unit='m', representation_type='cartesian')
    c.representation_type = 'spherical'
    if deg:
        ra = c.ra.deg
        dec = c.dec.deg
    else:
        ra = c.ra.rad
        dec = c.dec.rad
    return ra, dec


def cartesian_to_thetaphi(x, y, z, deg=True):
    """
    Convert cartesian coordinate to theta/phi, theta is the angle between the vector and the Z axis.
    """
    ra, dec = cartesian_to_radec(x, y, z, deg=deg)
    if deg:
        theta = 90. - dec
        phi = ra
    else:
        theta = np.pi / 2. - dec
        phi = ra
    return theta, phi


def spacecraft_to_detector(satellite="b"):
    '''
    Matrix from the satellite to payload coordinate system
    '''

    if satellite in ["a", "b"]:
        return Rotation.from_matrix([[1, 0, 0], [0, -1, 0], [0, 0, -1]])
    elif satellite == "c":
        return Rotation.from_matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
    else:
        raise Exception(f"Unknown satellite `{satellite}`, not in [a,b,c]")


def thetaphi_to_radec(theta, phi, quat, satellite="b"):
    """
    Convert a position in payload coordinates (theta/phi) to J2000 RA/Dec
    Args:
        theta ():
        phi ():
        quat ():
        satellite (str):b/c

    Returns:

    """
    vec_det = thetaphi_to_cartesian(theta, phi)

    dcm_J2000_to_spacecraft = Rotation.from_quat(quat)
    dcm_spacecraft_to_det = spacecraft_to_detector(satellite)
    dcm_det_to_J2000 = dcm_spacecraft_to_det.inv() * dcm_J2000_to_spacecraft.inv()

    vec_J2000 = dcm_det_to_J2000.inv().apply(vec_det.T)
    if vec_J2000.ndim == 1:
        ra, dec = cartesian_to_radec(vec_J2000[0], vec_J2000[1], vec_J2000[2])
    else:
        ra, dec = cartesian_to_radec(vec_J2000[:, 0], vec_J2000[:, 1], vec_J2000[:, 2])

    return ra, dec


def radec_to_thetaphi(ra, dec, quat, satellite="b"):
    """
    Convert a position in J2000 RA/Dec to payload coordinates (theta/phi)
    Args:
        ra ():
        dec ():
        quat ():
        satellite (str): b/c

    Returns:

    """
    vec_J2000 = radec_to_cartesian(ra, dec, 1.)

    dcm_J2000_to_spacecraft = Rotation.from_quat(quat)
    dcm_spacecraft_to_det = spacecraft_to_detector(satellite)
    dcm_J2000_to_det = dcm_J2000_to_spacecraft * dcm_spacecraft_to_det

    vec_det = dcm_J2000_to_det.inv().apply(vec_J2000.T)
    if vec_det.ndim == 1:
        theta, phi = cartesian_to_thetaphi(vec_det[0], vec_det[1], vec_det[2])
    else:
        theta, phi = cartesian_to_thetaphi(vec_det[:, 0], vec_det[:, 1], vec_det[:, 2])

    return theta, phi


def distance(ra1, dec1, ra2, dec2, radec=True):
    """
    Calculates the angular separation between two points
    radec (bool, optional): True if input is ra and dec, else is phi and theta.
    """
    if radec:
        c1 = SkyCoord(ra=ra1 * u.deg, dec=dec1 * u.deg)
        c2 = SkyCoord(ra=ra2 * u.deg, dec=dec2 * u.deg)
    else:
        c1 = SkyCoord(ra=ra1 * u.deg, dec=(90. - dec1) * u.deg)
        c2 = SkyCoord(ra=ra2 * u.deg, dec=(90. - dec2) * u.deg)

    sep = c1.separation(c2)
    return sep.deg


def detector_pointing(quat, det):
    """Retrieve the pointing of a GRD detector in equatorial coordinates
    Args:
        det (int): The GRD detector. 1-25
        quat
    Returns:
        (np.array, np.array): The RA, Dec of the detector pointing
    """
    detectors = [det.number for det in Detectors]
    if det not in detectors:
        raise ValueError('Illegal detector name')
    d = Detectors.from_num(det)
    theta, phi = d.theta, d.phi
    ra, dec = thetaphi_to_radec(theta, phi, quat)
    return ra, dec


def detector_angle(quat, ra, dec, det):
    """Determine the angle between a sky location and a GRD detector
    Args:
        ra (float): The RA of a sky position
        dec (float): The Dec of a sky position
        det (int): The GRD detector
        quat
    Returns:
        np.array: The angle, in degrees, between the position and \
                  detector pointing
    """
    det_ra, det_dec = detector_pointing(quat, det)
    angle = distance(ra, dec, det_ra, det_dec)
    return angle


def detector_earthangle(quat, x, y, z, det):
    """Detemine the angle between earth centre and a GRD detector
    """

    det_ra, det_dec = detector_pointing(quat, det)
    earth_ra, earth_dec = geocenter_in_radec(x, y, z)
    angle = distance(earth_ra, earth_dec, det_ra, det_dec)
    return angle


def elv(ra, dec, x, y, z):
    """The ELV angle of a sky location
    """
    geo_ra, geo_dec = geocenter_in_radec(x, y, z)
    angle = distance(geo_ra, geo_dec, ra, dec)
    return angle


def location_visible(ra, dec, x, y, z, h_min=0):
    """Determine if a sky location is visible or occulted by the Earth
    Args:
        ra (float): The RA of a sky position
        dec (float): The Dec of a sky position
        x,y,z (float): The position of the satellite in meters.
        h_min (float): in meters
    Returns:
        np.array(dtype=bool): A boolean array where True indicates the \
                              position is visible.
    """
    angle = elv(ra, dec, x, y, z)
    # print('ANGLE: ', angle)
    # print('geo_half_angle(x,y,z): ',geo_half_angle(x,y,z))
    visible = (angle > geo_half_angle(x, y, z, h_min=h_min))
    return visible


def get_time(mask):
    """
        Mask: A boolean array, where True indicates the source is visible
        return:
            in_index, out_index: the index
    """
    dmask = np.diff(mask + 0)
    out_index = np.where(dmask == 1)[0]
    in_index = np.where(dmask == -1)[0]

    return in_index, out_index


def geocenter_in_radec(x, y, z):
    """Calculate the location of the Earth center RA and Dec
    Args:
        x,y,z  Geocentric cartesian coordinates in meters
    Returns:
        (np.array, np.array): RA and Dec of Earth center as viewed by \
                              GECAM in degrees
    """
    geo_ra, geo_dec = cartesian_to_radec(-x, -y, -z)
    return geo_ra, geo_dec


def geo_half_angle(x, y, z, h_min=0):
    """Calculate the apparent angular radius of the Earth
    Args:
        x,y,z (float): The position of the satellite in meters.
        h_min (float): in meters.
    Returns:
        np.array: The angular radius, in degrees
    """
    r = 6371.0 * 1000.0
    half_angle = np.rad2deg(np.arcsin((r + h_min) / np.sqrt(x ** 2 + y ** 2 + z ** 2)))
    return half_angle


def calc_beta(x, y, z, vx, vy, vz, quat):
    '''
    calculate the angle between the orbit plane and radiator surface.
    The radiator surface is the -X axis of the satellite (GRD det 22).
    Args:
        x,y,z (np.array,1-by-N): The position of the satellite in J2000
        vx,vy,vz: The velocity of the satellite
        quat :
    Returns:
        beta (np.array):
    -------
    None.
    '''

    # orbit plane
    vec_p = np.array([x, y, z])
    vec_v = np.array([vx, vy, vz])
    orbit_norm = np.cross(vec_p.T, vec_v.T)
    ra_o, dec_o = cartesian_to_radec(orbit_norm[:, 0], orbit_norm[:, 1], orbit_norm[:, 2], deg=True)

    # radiator surface
    ra_r, dec_r = detector_pointing(quat, 22)

    # print('dec_o: ', dec_o[0:10])

    beta = distance(ra_o, dec_o, ra_r, dec_r, radec=True)
    index = beta > 90.
    beta[index] = 180. - beta[index]

    beta = 90. - beta

    return beta


def calc_mcilwain_l(latitude, longitude):
    """Estimate the McIlwain L value given the latitude (-30, +30) and
    East Longitude.  This uses a cubic polynomial approximation to the full
    calculation and is similar to the approach used by the GBM FSW.
    Args:
        latitude (np.array): Latitude in degrees from -180 to 180
        longitude (np.array): East longitude in degrees from 0 to 360
    Returns:
        np.array: McIlwain L value
    """

    latitude = np.asarray([latitude])
    longitude = np.asarray([longitude])
    orig_shape = latitude.shape
    latitude = latitude.flatten()
    longitude = longitude.flatten()
    # numPts = latitude.shape[0]
    coeffs_file = os.path.join(os.path.dirname(__file__),
                               'McIlwainL_Coeffs.npy')
    poly_coeffs = np.load(coeffs_file)
    longitude[longitude < 0.0] += 360.0
    longitude[longitude == 360.0] = 0.0

    bad_idx = (latitude < -30.0) | (latitude > 30.0) | (longitude < 0.0) | (
            longitude >= 360.0)
    if np.sum(bad_idx) != 0:
        raise ValueError(
            'Out of range coordinates for McIlwain L for {0} locations'.format(
                np.sum(bad_idx)))

    idx = np.asarray((longitude / 10.0).astype(int))
    idx2 = np.asarray(idx + 1)
    idx2[idx2 >= 36] = 0
    idx2 = idx2.astype(int)

    longitude_left = 10.0 * idx
    f = (longitude - longitude_left) / 10.0  # interpolation weight, 0 to 1

    try:
        num_pts = len(latitude)
    except:
        num_pts = 1
    mc_l = np.zeros(num_pts)
    for i in range(num_pts):
        mc_l[i] = (1.0 - f[i]) * (
                poly_coeffs[idx[i], 0] + poly_coeffs[idx[i], 1] * latitude[i] +
                poly_coeffs[idx[i], 2] *
                latitude[i] ** 2 + poly_coeffs[idx[i], 3] * latitude[i] ** 3) + \
                  f[i] * (
                          poly_coeffs[idx2[i], 0] + poly_coeffs[idx2[i], 1] *
                          latitude[i] + poly_coeffs[idx2[i], 2] *
                          latitude[i] ** 2 + poly_coeffs[idx2[i], 3] *
                          latitude[i] ** 3)
    mc_l = mc_l.reshape(orig_shape)
    return np.squeeze(mc_l)


def saa_boundary():
    """The coordinates of the SAA boundary in latitude and longitude
    Returns:
        (np.array, np.array): The latitude and longitude values
    """
    # lat_saa = np.array([-20.,-10.,-10.,-32.,-43.,-55., -52.,-34.,-20.])
    # lon_saa = np.array([-80.,-60.,-30.,30.,30.,-10.,-50.,-80.,-80.])

    lat_saa = np.array([-20., -5., -1., 0., -10., -23., -30., -30., -20.])
    lon_saa = np.array([-90., -79., -60., -30., 0., 30., 30., -90., -90.])

    return lat_saa, lon_saa


def get_saa_passage(lat, lon, lat_saa, lon_saa):
    """Determine if GECAM is in an SAA passage
    Args:
        lat, lon: The latitude and longitude of GECAM in EARTH FIXED coordinate
        lat_saa, lon_saa: The coordinates of the SAA boundary
    Returns:
        np.array(dtype=bool): A boolean array, where True indicates GECAM \
                              is in SAA
    """
    from matplotlib import path
    p = path.Path(np.vstack((lon_saa, lat_saa)).T)
    in_saa = p.contains_points([(lon, lat)])

    return in_saa


def get_galactic_radec():
    l = np.arange(0., 360., 1)
    b = np.zeros(np.shape(l))
    gal = SkyCoord(l, b, frame='galactic', unit='deg')
    gal_l = gal.icrs
    ra_g = gal_l.ra.deg
    dec_g = gal_l.dec.deg

    return ra_g, dec_g


def radec_to_galacitc(ra, dec):
    pos = SkyCoord(ra * u.deg, dec * u.deg)
    return float(pos.galactic.l.deg), float(pos.galactic.b.deg)


def radec_to_ecliptic(ra, dec):
    pos = SkyCoord(ra * u.deg, dec * u.deg)
    return float(pos.geocentrictrueecliptic.lon.deg), float(pos.geocentrictrueecliptic.lat.deg)


def get_satellite_latlon(x, y, z, unit1='m'):
    """Calculate the location of the satellite in lat/lon/alt (geodetic)
    x,y,z (float): the location of satellite in xy/z (geocentric). unit: m
    """

    loc = coordinates.EarthLocation.from_geocentric(x, y, z, unit=unit1)

    return loc.lat.value, loc.lon.value, loc.height.value


def get_satellite_geocentric(lat, lon, alt):
    """Calculate the location of the satellite in xy/z (geocentric). unit: m
       lat,lon,alt (float): the location of satellite in lat/lon/alt (geodetic).
       lat and lon in unit deg, alt in unit m.
    """

    loc = coordinates.EarthLocation.from_geodetic(lon, lat, alt)

    return loc.x.value, loc.y.value, loc.z.value


def eci_to_fix(ra, dec, r, utctime, sph=True, deg=True):
    """ECI to FIX
        Input:
        if sph = True, the input is ra, dec and r (in meters) in sphere coordinate,
        else sph = False, the input is x, y and z (in meters)
        Return: x,y,z in meters.
    """
    if sph:
        x, y, z = radec_to_cartesian(ra, dec, r, deg=deg)
    else:
        x, y, z = ra, dec, r

    utctime = astropy.time.Time(utctime)
    cartrep = coordinates.CartesianRepresentation(x=x, y=y, z=z, unit=u.m)
    eci = coordinates.GCRS(cartrep, obstime=utctime)
    fix = eci.transform_to(coordinates.ITRS(obstime=utctime))

    return fix.cartesian.x.value, fix.cartesian.y.value, fix.cartesian.z.value


def fix_to_eci(x, y, z, utctime, sph=False):
    'FIX to ECI'

    if sph:
        x, y, z = radec_to_cartesian(x, y, z, deg=True)

    utctime = astropy.time.Time(utctime)
    cartrep = coordinates.CartesianRepresentation(x=x, y=y, z=z, unit=u.m)
    fix = coordinates.ITRS(cartrep, obstime=utctime)
    eci = fix.transform_to(coordinates.GCRS(obstime=utctime))

    return eci.cartesian.x.value, eci.cartesian.y.value, eci.cartesian.z.value
