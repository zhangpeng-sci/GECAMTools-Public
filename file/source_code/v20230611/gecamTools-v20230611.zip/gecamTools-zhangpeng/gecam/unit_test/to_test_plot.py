# to_test_plot: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong* (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt
import numpy as np
# 事例文件路径
# /gecamfs/Archived-DATA/GSDC/LEVEL1/triggers/2021/05/tn210511_112749_fb/gbg_evt_tn210511_112749_fb_v00.fits

from gecam.data.evt import Evt


def plot_lc_with_detectors():
    trig_met = evt.info.trig_met

    chooose_det = [GRD(1, gain_type="both"), GRD(4, gain_type="both"), GRD(5, gain_type="both")]
    slice_kwargs_dic = {
        "time_range": [trig_met - 10, trig_met + 50],
        "only_recommend": True
    }

    lc_kwargs_dic = {
        "time_bin": 0.064,
        "energy_bin": [40, 100, 300, 1000, 3000, 6000],
    }
    fig_kwargs_dic = {}

    # 画多探头的叠加光变
    dets_lc_list, lc_data, lc_fig = evt.plot_light_curve_with_detectors(chooose_det, slice_kwargs_dic,
                                                                        lc_kwargs_dic, fig_kwargs_dic)

    det_y_list = []
    for det_lc_obj in dets_lc_list:
        det_time_x, det_y, det_y_err = det_lc_obj.get_data(correct_by_dead_time=False)
        det_y_list.append(det_y)

    det_y_list = np.array(det_y_list)
    time_bin = lc_kwargs_dic["time_bin"]
    time_bins = det_time_x
    energy_bins = lc_kwargs_dic["energy_bin"]

    choose_lc_y = det_y_list.sum(axis=0) / time_bin

    sub_fig_num = choose_lc_y.shape[0]

    fig, axes = plt.subplots(sub_fig_num, 1, figsize=(10, 10))

    for index in range(sub_fig_num):
        ax = axes[index]

        ax.step(time_bins[:-1] - trig_met, choose_lc_y[index],
                label=f"energy:{energy_bins[index]}-{energy_bins[index + 1]}")
        ax.set_ylabel("Counts/s")
        ax.legend()

    plt.show()


def plot_spectrum_with_detectors():
    chooose_det = [GRD(18, gain_type="high")]
    slice_kwargs_dic = {
        "time_range": [trig_met - 50, trig_met + 60],
        "only_recommend": True
    }

    spec_kwargs_dic = {
        "channel_bin": 1
    }
    fig_kwargs_dic = {}

    # 画多探头的叠加的能谱
    total_spec_obj, dets_spec_list, plot_spec_data, spec_fig = evt.plot_spectrum_with_detectors(chooose_det,
                                                                                                slice_kwargs_dic,
                                                                                                spec_kwargs_dic,
                                                                                                fig_kwargs_dic)
    plt.yscale("log")
    plt.show()


def plot_lc_spec_file():
    # 过滤出探头18的数据
    det_events = evt.select_detector(18)
    # 对于探头数据进一步的数据过滤，增益、时间范围、能量范围、能道范围、是否只使用推荐事例

    # 根据增益过滤，both:全增益， high:高增益， low：低增益
    # gain_type=None,

    # 根据时间过滤
    # time_range=None,

    # 过滤能量范围或能道范围，不同时进行，如果channel_range不为None,则只过滤channel
    # energy_range=None,
    # channel_range=None,

    # 是否只选取推荐事例
    # only_recommend=True
    det_sliced_events = det_events.slice(gain_type="high", only_recommend=True)
    # 提取触发时间
    trig_met = evt.info.trig_met

    # 光变的总时间范围（绝对时间）
    lc_time_range = (trig_met - 50, trig_met + 70)

    # 定义源时间段
    src_time_range = [trig_met - 3, trig_met + 9]
    # 定义本底时间段
    bg_time_range_list = [[trig_met - 40, trig_met - 20],
                          [trig_met + 25, trig_met + 60]]

    # 时间bin，单位秒
    time_bin = 2
    # 能道分bin，整数为均匀分bin，一维列表为自定义分bin
    channel_bin = 1

    det_sliced_lc = det_sliced_events.to_light_curve(lc_time_range, time_bin, channel_bin)
    # 本底拟合，拟合阶次为2
    det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=2)
    # 提取源时间段的光变
    det_src_lc = det_sliced_events.to_light_curve(src_time_range, time_bin, channel_bin)

    # 画出总时长光变（合并各个能段）
    det_sliced_lc_fig = LightCurveFigure(det_sliced_lc.get_plot_data(), trig_time=trig_met, dpi=100)
    # 画出本底
    det_sliced_lc_fig.add_background(det_sliced_bg_lc.get_plot_data(),
                                     bg_time_range=det_sliced_bg_lc.bg_time_range)
    # 画出源时间段的阴影
    det_sliced_lc_fig.add_selection(det_src_lc.get_plot_data())
    det_sliced_lc_fig.show_legend()
    plt.show()

    # 生成能谱文件的数据,时间分解谱
    # det_sliced_lc： 单个探头的光变
    # det_sliced_bg_lc： 单个探头的本底光变
    from gecam.data.spec import SpecFile

    spec_file = SpecFile(det_sliced_lc, det_sliced_bg_lc)

    # 添加第一个源时间段
    src_time_range = (trig_met - 1, trig_met + 5)
    spec, bg_spec, net_spec = spec_file.add_src(src_time_range)

    # 添加第二个源时间段
    src_time_range2 = (trig_met + 5, trig_met + 9)
    spec2, bg_spec2, net_spec2 = spec_file.add_src(src_time_range2)

    from gecam.plot.spectrum import SpectrumFigure

    # 画出能谱文件的数据（当前选择第一段源时间段的能谱）
    spec_fig = SpectrumFigure()
    spec_fig.add_data(spec.get_plot_data(), color="#474747", err_color="#474747", label="full-spec",
                      linewidth=1)
    spec_fig.add_data(bg_spec.get_plot_data(), color="#0c5da5", err_color="#0c5da5", label="bg-spec",
                      linewidth=1)
    spec_fig.add_data(net_spec.get_plot_data(), color="#16bf55", err_color="#16bf55", label="net-spec",
                      linewidth=1)

    # 截断显示
    spec_fig.set_xlim([0, 200])
    spec_fig.set_yscale("linear")
    spec_fig.show_legend()
    plt.show()

    spec_file.write("./")


# def plot_spec_file():


if __name__ == '__main__':
    evt_path = r"E:/gecamTools/test/gbg_evt_tn210511_112749_fb_v00.fits"


    evt_path = r"D:\test\gecam\gbg_evt_tn230307_154406_fb_v00.fits"
    evt = Evt.open(evt_path)
    # new_evt_path:gbg_evt_tn230307_154406_fb_v00_131903036.65+30.0.fits
    new_evt_path = evt.crop(time_range=[evt.info.trig_met - 10, evt.info.trig_met + 20], out_dir="D:/test/gecam/")

    trig_met = evt.info.trig_met

    plot_lc_with_detectors()

    # plot_spectrum_with_detectors()
    plot_lc_spec_file()
