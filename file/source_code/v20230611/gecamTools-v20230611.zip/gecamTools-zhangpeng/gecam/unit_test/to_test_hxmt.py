# to_test_hxmt: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong* (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.hxmt_evt import EvtHxmt
from gecam.data.spec import SpecFile
from gecam.data.detector import HE
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt

from gecam.data.hxmt_evt import EvtHxmt
from gecam.analysis.burst_duration import BurstDuration
from gecam.data.detector import Detector, HE, LE

evt_path=r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\HEB221009553_HE-Evt.fits"
evt = EvtHxmt.open(evt_path)


trig_met=evt.info.trig_met
det_list = [HE(1),HE(2),HE(3),HE(4),HE(5)]


slice_kwargs_dic = {
    "time_range": [trig_met - 25, trig_met + 35],
}
lc_kwargs_dic = {
    "time_bin": 0.5,
    "channel_bin": [1,200],
         #HXMT的死时间通过文件单独输入，然后修正死时间
    "correct_by_dead_time":r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\DeadTime_Proportion.txt"
}
lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 20, trig_met - 5], [trig_met + 10, trig_met + 30]],
    "fit_order": 1
}
duration_obj = BurstDuration()
lc_dic, cumsum_net_lc_data=duration_obj.generate_net_light_curve_with_detectors(evt, det_list, slice_kwargs_dic,
                                                                                lc_kwargs_dic,lc_bg_fit_kwargs_dic)

## 查看净光变

from gecam.plot.light_curve import LightCurveFigure

total_lc_x, total_lc_y, total_lc_y_err = duration_obj.total_lc_1D_data
bg_lc_x, bg_lc_y, bg_lc_y_err = duration_obj.bg_lc_1D_data
net_lc_x, net_lc_y, net_lc_y_err = duration_obj.net_lc_1D_data

lc_bg_range = lc_bg_fit_kwargs_dic.get("bg_time_range")

lc_fig = LightCurveFigure((total_lc_x[:-1], total_lc_y, total_lc_y_err),
                          trig_time=duration_obj.evt_info.trig_met,
                         satellite=evt.info.satellite)
lc_fig.add_data((bg_lc_x[:-1], bg_lc_y, bg_lc_y_err), color="red",err_color="#FF5959")
lc_fig.add_background(bg_time_range=lc_bg_range)
lc_fig.set_ylabel("Counts")


evt_path=r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\HEB221009553_HE-Evt.fits"
evt = EvtHxmt.open(evt_path)

trig_met = evt.info.trig_met

chooose_det = [HE(1),HE(18)]
slice_kwargs_dic = {
    "time_range": [trig_met - 50, trig_met + 60],
}

lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": 4,
}
lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 40, trig_met - 10], [trig_met + 25, trig_met + 60]],
    "fit_order": 1,
}
spec_file_kwargs_dic = {
    "src_range_list": [
        [trig_met - 1, trig_met + 9],
        [trig_met - 1, trig_met + 5],
        [trig_met + 5, trig_met + 9],
    ],
    "rsp_list": ["gbg_18H_x_evt_v00.rsp",
                 "gbg_25H_x_evt_v00.rsp"],
    "out_dir": "./test_spec_hxmt_evt/"
}

spec_data = evt.generate_spec_file_with_detecotrs(chooose_det, slice_kwargs_dic, lc_kwargs_dic,
                                          lc_bg_fit_kwargs_dic, spec_file_kwargs_dic)

# 查看HED01的能谱数据
spec_data_HED01 = spec_data.get("HED01")
# 查看生成能谱前的总光变和本底光变
HED01_lc=spec_data_HED01.get("lc")
HED01_bg_lc=spec_data_HED01.get("bg_lc")

spec_list_HED01=spec_data_HED01.get("src_spec_list")

# 查看第一个时间段源的能谱数据
spec_list_HED01_src1 = spec_list_HED01[0]

src_range1, spec_HED01, bg_spec_HED01, net_spec_HED01 = spec_list_HED01_src1

# 示例：检查HED01在拟合光变时是否存在错误（参考后续的细致分析）
det_sliced_c_lc_fig = LightCurveFigure(HED01_lc.get_plot_data(), trig_time=trig_met)
# 标记本底范围的阴影
det_sliced_c_lc_fig.add_background(HED01_bg_lc.get_plot_data(),
                                   bg_time_range=HED01_bg_lc.bg_time_range, label="bg")
plt.show()
# 查看HED01的本底拟合评价
# channel_range=[10,200]
# HED01_bg_lc.show_fitting_quality(channel_range=channel_range)
# plt.show()