# test_spectrum: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import unittest
from gecam.time import GecamMet,HebsMet,HxmtMet

class TestingClass(unittest.TestCase):

    def test_time_convert_gecam(self):
        trig_met = 74431600.6

        # met转时间字符串
        trig_time_str = GecamMet(trig_met).iso
        # met转datetime
        trig_datetime = GecamMet(trig_met).datetime
        # met转MJD
        trig_mjd = GecamMet(trig_met).mjd

        self.assertEqual(trig_time_str,'2021-05-11T11:26:40.600000')
        self.assertEqual(trig_mjd, 59345.4768587963)


        # 时间字符串转met
        met1 = GecamMet.from_iso(trig_time_str).met
        # datetime转met
        met2 = GecamMet.from_datetime(trig_datetime).met
        # MJD转met
        met3 = GecamMet.from_mjd(trig_mjd).met

        self.assertAlmostEqual(met1, 74431600.6)
        self.assertAlmostEqual(met2, 74431600.6)

    def test_time_convert_hebs(self):
        trig_met = 74431600.6

        # met转时间字符串
        trig_time_str = HebsMet(trig_met).iso
        # met转datetime
        trig_datetime = HebsMet(trig_met).datetime
        # met转MJD
        trig_mjd = HebsMet(trig_met).mjd

        self.assertEqual(trig_time_str,'2023-05-12T11:26:40.600000')
        self.assertEqual(trig_mjd, 60076.4768587963)


        # 时间字符串转met
        met1 = HebsMet.from_iso(trig_time_str).met
        # datetime转met
        met2 = HebsMet.from_datetime(trig_datetime).met
        # MJD转met
        met3 = HebsMet.from_mjd(trig_mjd).met

        self.assertAlmostEqual(met1, 74431600.6)
        self.assertAlmostEqual(met2, 74431600.6)

    def test_time_convert_hxmt(self):
        trig_met = 74431600.6

        # met转时间字符串
        trig_time_str = HxmtMet(trig_met).iso
        # met转datetime
        trig_datetime = HxmtMet(trig_met).datetime
        # met转MJD
        trig_mjd = HxmtMet(trig_met).mjd

        self.assertEqual(trig_time_str,'2014-05-11T11:26:39.600000')
        self.assertEqual(trig_mjd, 56788.47684722222)


        # 时间字符串转met
        met1 = HxmtMet.from_iso(trig_time_str).met
        # datetime转met
        met2 = HxmtMet.from_datetime(trig_datetime).met
        # MJD转met
        met3 = HxmtMet.from_mjd(trig_mjd).met

        self.assertAlmostEqual(met1, 74431600.6)
        self.assertAlmostEqual(met2, 74431600.6)