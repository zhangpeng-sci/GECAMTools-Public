# to_test_posatt: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong* (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.posatt import PosAtt
from gecam.coord import radec_to_thetaphi
from gecam.utils import rsp_utils
from gecam.data.detector import GRD

# # 读取posatt文件
# posatt_path=r"gb_posatt_tn210511_112749_v00.fits"
# posatt_obj = PosAtt.open(posatt_path)
#
# # 选定met时间，或使用触发时间 evt.info.trig_met
# choose_met = 74431600.6
# # satallite: b/c
# choose_satellite="b"
#
# # 获取时间点对应的卫星姿态（四元数）
# # TODO: 注意：
# # For GECAMC(HEBS)， MET(59537900)前后的姿态四元数的格式错误，暂未修复
# # pre_quat = ['Q2', 'Q3', 'Q4', 'Q1'] # until 59537900
# # quat = ['Q1', 'Q2', 'Q3', 'Q4'] # from 59538144
# quat = posatt_obj.get_quat(choose_met)
#
# # 如果GECAMC的met<59537900
# # 需要手动调整，quat=[quat[3],quat[0],quat[1],quat[2]]
# if choose_satellite=="c" and choose_met<59537900:
#     quat=[quat[3],quat[0],quat[1],quat[2]]

# 设定源坐标（J2000）
# 或取出触发evt文件的header中存储的源坐标: ra,dec,err_radius=evt.info.loc
ra = 293.743
dec = 21.896

quat = [0.19336516, -0.43906426, 0.3738846, 0.79375243]
# 根据源的坐标和卫星姿态计算入射角（deg）
theta, phi = radec_to_thetaphi(ra, dec, quat, satellite="c")

print(theta, phi)
