
import pathlib
import os

__NAME__ = "GECAMTools"
__VERSION__ = "20230611"


def get_software_name():
    return __NAME__


def get_software_version():
    return __VERSION__


package_dir = str(pathlib.Path(__file__).parent.absolute())

test_dir = os.path.join(package_dir, 'test')
test_data_dir = os.path.join(test_dir, 'data')
