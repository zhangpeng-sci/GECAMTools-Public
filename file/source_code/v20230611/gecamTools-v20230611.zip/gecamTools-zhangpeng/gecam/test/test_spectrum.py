# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/09/15/0015 15:52
@Version:1.0
@Desc   :


"""

from astropy.io import fits
import numpy as np
from gecam.utils import curve_utils, fit_utils, file_utils
from gecam.utils.spec_utils import generate_all_spec_fits


def find_channel_by_energy(ebounds_min_list, ebounds_max_list, energy):
    for i in range(len(ebounds_min_list)):

        e_min = ebounds_min_list[i]
        e_max = ebounds_max_list[i]

        if e_min <= energy <= e_max:
            e_min_log = np.log(e_min)
            e_max_log = np.log(e_max)
            rate = (np.log(energy) - e_min_log) / (e_max_log - e_min_log)

            return i, e_min, e_max, rate.round(4)


def get_channel_by_energy(ebounds_min_list, ebounds_max_list, energy_range_list=None):
    """
    extract channel number by energy range
    :param ebounds_max_list: max ebounds list
    :param ebounds_min_list: min ebounds list
    :param energy_range_list: list of energy range. [ [e_start,e_stop]  ]
    :return:
        channel_list:  [ [channel_num_start,channel_num_stop]]
        real_energy_range_list: energy range corresponding to channel.   [ [] ]
    """
    if energy_range_list is None:
        energy_range_list = np.vstack((ebounds_min_list, ebounds_max_list)).transpose().tolist()

    channel_list = []
    real_energy_range_list = []

    for energy_start, energy_stop in energy_range_list:
        ebounds_index_list = np.where((ebounds_min_list >= energy_start) & (ebounds_max_list <= energy_stop))[0]

        channel_num_start, channel_num_stop = ebounds_index_list[0], ebounds_index_list[-1]

        energy_real_start = ebounds_min_list[channel_num_start]
        energy_real_stop = ebounds_max_list[channel_num_start]

        channel_list.append([channel_num_start, channel_num_stop])

        real_energy_range_list.append([energy_real_start, energy_real_stop])

    return np.array(channel_list), np.array(real_energy_range_list)


def get_energy_by_channel_range_list(ebounds_min_list, ebounds_max_list, channel_range_list=None):
    """
    get real energy range by channel range list
    :param ebounds_min_list: The low-value edges of the energy bins
    :param ebounds_max_list: The high-value edges of the energy bins
    :param channel_range_list:2D list or None
        eg.
        [ [channel_start, channel_stop] ]
    :return:2D np.array
        eg.
        [ [energy_start,energy_stop] ]

    """
    # if channel_range_list is None:
    #     return np.vstack((ebounds_min_list, ebounds_max_list)).transpose()

    channel_max_index = 448

    energy_range_list = []

    for c_start, c_stop in channel_range_list:
        c_start = np.minimum(c_start, channel_max_index)
        c_stop = np.minimum(c_stop, channel_max_index)

        energy_start = ebounds_min_list[c_start]
        energy_stop = ebounds_max_list[c_stop - 1]

        energy_range_list.append([energy_start, energy_stop])

    return np.array(energy_range_list)


# def aa(ebounds_min, ebounds_max, channel_bin=1):
#     channel_len = len(ebounds_min)
#     if type(channel_bin) is int:
#         channels_min = np.arange(0, channel_len, channel_bin)
#         channels_max = np.arange(channel_bin, channel_len + channel_bin, channel_bin)
#         channels_max[-1] = channel_len
#         channel_range_list = np.vstack((channels_min, channels_max)).transpose()
#
#         energys_min=ebounds_min[channels_min]
#         energys_max=ebounds_min[channels_max]
#         energys_max[-1]=1
#
#         # energy_range_list = np.vstack((ebounds_min[channels_min], ebounds_max[channels_max])).transpose()
#
#     elif type(channel_bin) is list:
#
#         energy_range_list = []
#
#         c_index_start =1
#         for c_index in channel_bin[1:]:
#
#         for c_start, c_stop in channel_bin:
#             c_start = np.minimum(c_start, channel_max_index)
#             c_stop = np.minimum(c_stop, channel_max_index)
#
#             energy_start = ebounds_min_list[c_start]
#             energy_stop = ebounds_max_list[c_stop - 1]
#
#             energy_range_list.append([energy_start, energy_stop])
#
#         pass
#     else:
#         raise ValueError("The type of input param <channel_bin> should be int or list.")


def get_net_lc_spec_from_evt(fits_path, detector_list, source_time_range, channel_range_list_high_gain,
                             channel_range_list_low_gain,
                             time_bin_width, bg_time_range_list: list, bg_fit_order, out_dir=None):
    """

    :param fits_path:
    :param detector_list:
    :param source_time_range:
    :param energy_range_list_high_gain:
    :param energy_range_list_low_gain:
    :param time_bin_width:
    :param bg_time_range_list:
    :param bg_fit_order:
    :return:
    """
    fits_obj = fits.open(fits_path, lazy_load_hdus=True)

    ebounds = fits_obj["EBOUNDS"].data
    ebounds_min, ebounds_max = ebounds.field("E_MIN"), ebounds.field("E_MAX")

    energy_range_low_gain = get_energy_by_channel_range_list(ebounds_min, ebounds_max, channel_range_list_low_gain)
    energy_range_high_gain = get_energy_by_channel_range_list(ebounds_min, ebounds_max, channel_range_list_high_gain)

    time_min, time_max = np.min(bg_time_range_list), np.max(bg_time_range_list)

    result_dic = {}

    for detector in detector_list:
        print(detector.full_name)
        gain_num_list = detector.gain_num(return_type="list")

        # GRD01 EVENTS01
        det_num = detector.number()
        hdu_name = f"EVENTS{str(det_num).zfill(2)}"
        detector_hdu_obj = fits_obj[hdu_name]
        detector_data_all = detector_hdu_obj.data

        # filter data in time range, which between minimum and max background
        detector_time_all = detector_data_all.field("TIME")
        detector_data_in_time = detector_data_all[(detector_time_all >= time_min) & (detector_time_all <= time_max)]

        for gain_num in gain_num_list:
            if gain_num == 0:
                channel_range_list = channel_range_list_high_gain
                energy_range_list = energy_range_high_gain
                gain_str = "high"
            else:
                channel_range_list = channel_range_list_low_gain
                energy_range_list = energy_range_low_gain
                gain_str = "low"

            # filter gain
            det_gain_data = detector_data_in_time[detector_data_in_time.field("GAIN_TYPE") == gain_num]

            # extract light curve(all, background, net) and energy spectrum(es)
            # with all, background and net in chose channel.
            lc_all, spec_all, exposure_sum_list = curve_utils.generate_net_lc_and_spec(det_gain_data.field("TIME"),
                                                                                       det_gain_data.field("PI"),
                                                                                       channel_range_list,
                                                                                       det_gain_data.field("DEAD_TIME"),
                                                                                       (time_min, time_max),
                                                                                       bg_time_range_list,
                                                                                       time_bin_width,
                                                                                       bg_fit_order,
                                                                                       source_time_range=source_time_range)

            (lc_x, lc_y, bg_lc_y, net_lc_y) = lc_all
            (spec, spec_err, bg_spec, bg_spec_err, net_spec, net_spec_err) = spec_all

            temp_detector = type(detector)(detector.number(), gain_str)

            result_dic[temp_detector] = {
                "lc_x": lc_x,
                "lc_y": lc_y,
                "bg_lc_y": bg_lc_y,
                "net_lc_y": net_lc_y,
                "spec": spec,
                "spec_err": spec_err,
                "bg_spec": bg_spec,
                "bg_spec_err": bg_spec_err,
                "net_spec": net_spec,
                "net_spec_err": net_spec_err,
                "exposure_list": exposure_sum_list,
            }

            if out_dir:
                generate_all_spec_fits(temp_detector, spec_all, ebounds_min, ebounds_max,
                                       channel_range_list, exposure_sum_list, out_dir)

    fits_obj.close()

    return result_dic
