# -*- coding:utf-8 _*-
"""
@author: Dr. Rui Qiao
@file: others.py
@time: 2019/12/03
在 time_conversion.basic中定义了 最基本的 met/mjd/utc 与 datetime 的转换，相当于 datetime为桥梁
这里利用上述函数，实现 met/mjd/utc 之间的转换，异常返回None
API函数包括：
1、met2mjd 和 mjd2met：MET与MJD的转换
2、utc2mjd 和 mjd2utc：UTC与MJD的转换
3、utc2met 和 met2utc：UTC与MET的转换
4、time2mjd(**kwargs)：在字典中，依次找寻 key为 (MJD,UTC,MET)，并把val转换为 MJD时间，如果不存在指定KEY，则返回当前的MJD时间
5、get_time_query_keys()：一系列 支持的时间 key
"""
import sys
from .basic import *


def met2mjd(met):
    date_time = met2datetime(met)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid MET', met)
        return None
    else:
        return datetime2mjd(date_time)


def mjd2met(mjd):
    date_time = mjd2datetime(mjd)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid MJD', mjd)
        return None
    else:
        return datetime2met(date_time)


def utc2mjd(utc):
    date_time = utc2datetime(utc)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid UTC', utc)
        return None
    else:
        return datetime2mjd(date_time)


def mjd2utc(mjd):
    date_time = mjd2datetime(mjd)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid MJD', mjd)
        return None
    else:
        return datetime2utc(date_time)


def utc2met(utc):
    date_time = utc2datetime(utc)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid UTC', utc)
        return None
    else:
        return datetime2met(date_time)


def met2utc(met):
    date_time = met2datetime(met)
    if date_time is None:
        print('{} Error,'.format(sys._getframe().f_code.co_name),
              'Invalid MET', met)
        return None
    else:
        return datetime2utc(date_time)


def time2mjd(**kwargs):
    """
    在字典中，依次找寻 key为 (MJD,UTC,MET)，并把val转换为 MJD时间，如果不存在指定KEY，则返回当前的MJD时间
    :param kwargs: 一系列参数
    :return: MJD时间（浮点，天）。异常返回None
    """
    if 'MJD' in kwargs:
        return kwargs['MJD']
    elif 'UTC' in kwargs:
        return utc2mjd(kwargs['UTC'])
    elif 'MET' in kwargs:
        return met2mjd(kwargs['MET'])
    else:  # 不存在指定KEY，则返回当前的MJD时间
        return get_now_mjd()

def get_time_query_keys():
    """
    对于检索条件字典，能够接受的时间相关的key
    :return: 元组
    """
    return ('MJD','UTC','MET')
