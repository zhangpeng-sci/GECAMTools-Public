import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()

pre_y = np.array(
    [0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 3, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2])
y = np.cumsum(pre_y)

plt.plot(y)

plt.show()
