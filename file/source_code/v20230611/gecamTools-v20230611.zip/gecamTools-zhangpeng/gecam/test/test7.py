# -*- coding: utf-8 -*-
"""
@author: xuewc
"""

import numpy as np


def calc_duration(t, counts, net_counts, net_uncert, f, prev_interval,
                  post_interval):
    """
    时间中点计数、净计数、净计数误差、百分数、零流量区间、全流量区间
    Args:
        t ():
        counts ():
        net_counts ():
        net_uncert ():
        f ():
        prev_interval ():
        post_interval ():

    Returns:

    """
    prev_mask = (prev_interval[0] <= t) & (t <= prev_interval[1])
    post_mask = (post_interval[0] <= t) & (t <= post_interval[1])

    cumsum_net = np.cumsum(net_counts)
    cumsum_prev = cumsum_net[prev_mask]
    cumsum_post = cumsum_net[post_mask]

    cumsum_err = np.sqrt(np.cumsum(net_counts + np.square(net_uncert)))
    prev_err = cumsum_err[prev_mask]
    post_err = cumsum_err[post_mask]

    Lz, Lz_err = wleastsq(np.ones_like(cumsum_prev), cumsum_prev, 1.0 / prev_err)
    Lt, Lt_err = wleastsq(np.ones_like(cumsum_post), cumsum_post, 1.0 / post_err)

    src_mask = (prev_interval[1] < t) & (t < post_interval[0])
    t_src = t[src_mask]
    cumsum_src = cumsum_net[src_mask]

    f1 = (1.0 - f) / 2.0
    f2 = 1.0 - f1
    L1 = Lz + f1 * (Lt - Lz)
    L2 = Lz + f2 * (Lt - Lz)
    # idx1 = np.argmin(np.abs(cumsum_src - L1))
    # idx2 = np.argmin(np.abs(cumsum_src - L2))
    idx1 = np.where(cumsum_src >= L1)[0][0]
    idx2 = np.where(cumsum_src >= L2)[0][0]
    # S1 = cumsum_src[idx1]
    # S2 = cumsum_src[idx2]
    tau1 = t_src[idx1]
    tau2 = t_src[idx2]
    src_mask2 = (prev_interval[1] < t) & (Lz <= net_counts)
    T1 = np.sum(counts[src_mask2 & (t <= tau1)])
    T2 = np.sum(counts[src_mask2 & (t <= tau2)])
    S1_err = np.sqrt(T1 + (f2 * Lz_err[0, 0]) ** 2.0 + (f1 * Lt_err[0, 0]) ** 2.0)
    S2_err = np.sqrt(T2 + (f1 * Lz_err[0, 0]) ** 2.0 + (f2 * Lt_err[0, 0]) ** 2.0)
    # tau1_l = t_src[np.argmin(np.abs(cumsum_src - (L1 - S1_err)))]
    # tau1_h = t_src[np.argmin(np.abs(cumsum_src - (L1 + S1_err)))]
    # print(L1 - S1_err, L1 + S1_err, L2 - S2_err, L2 + S2_err)
    tau1_l = t_src[np.where(cumsum_src > L1 - S1_err)[0][0]]
    tau1_h = t_src[np.where(cumsum_src > L1 + S1_err)[0][0]]
    tau1_err = tau1_h - tau1_l
    # tau2_l = t_src[np.argmin(np.abs(cumsum_src - (L2 - S2_err)))]
    # tau2_h = t_src[np.argmin(np.abs(cumsum_src - (L2 + S2_err)))]
    tau2_l = t_src[np.where(cumsum_src > L2 - S2_err)[0][0]]
    tau2_h = t_src[np.where(cumsum_src > L2 + S2_err)[0][0]]
    tau2_err = tau2_h - tau2_l
    tau_f = tau2 - tau1
    tau_err = np.sqrt(tau1_err * tau1_err + tau2_err * tau2_err)
    # print(tau1, tau1_l, tau1_h, tau2, tau2_l, tau2_h)
    # print(S1, S1_err, S2, S2_err)
    return tau_f, tau_err  # , tau1, tau1_err, tau2, tau2_err, S1, S1_err, S2, S2_err


def wleastsq(X, y, w, return_cov=True):
    """
    Return the least-squares solution to a linear matrix equation, which
    minimizes the weighted Euclidean 2-norm :math:`||W^{1/2} (y - bX)||`.
    This function is adapted from `numpy` polynomial fitter.

    Parameters
    ----------
    X : (M, N) array_like
        "Coefficient" matrix.
    y : (M,) array_like
        Ordinate or "dependent variable" values.
    w : (M,) array_like
        Weights to apply to the y-coordinates of the sample points. For
        gaussian uncertainties, use 1/sigma (not 1/sigma**2).
    return_cov : bool, optional
        Whether to return covariance. The default is True.

    Returns
    -------
    b : (N,) ndarray
        Weighted least-squares solution.
    cov : (N, N) ndarray
        The covariance matrix of the parameter estimates. The diagonal of
        this matrix are the variance estimates for each parameter.

    Warns
    -----
    RankWarning
        The rank of the coefficient matrix in the least-squares fit is
        deficient.

    """
    if len(X.shape) == 1:
        X = np.ascontiguousarray(np.atleast_2d(X).T)

    order = X.shape[1]

    # return if all values of y are zeros
    if all(y == 0):
        b = np.full(order, 0.0)
        if return_cov:
            cov = np.full((order, order), 0.0)
            return b, cov
        else:
            return b

    # set up least squares equation with weight
    WX = w[:, None] * X
    Wy = w * y

    # scale WX to improve condition number and solve
    scale = np.sqrt(np.square(WX).sum(axis=0))
    scale[scale == 0] = 1
    b, resids, rank, s = np.linalg.lstsq(WX / scale, Wy, rcond=None)
    b = b / scale

    if return_cov:
        # scale the covariance matrix, to reduce the potential bias of
        # weights
        fac = resids / (X.shape[0] - order)
        scaled_cov = fac * np.linalg.inv(WX.T @ WX)
        return b, scaled_cov
    else:
        return b