# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/11/01/0001 16:40
@Version:1.0
@Desc   :


"""
from datetime import timedelta
import datetime
from astropy.time import Time, update_leap_seconds, TimeFormat
from astropy.time.formats import erfa, TimeFromEpoch


class TimeUnixLeap(TimeFromEpoch):
    """
    Seconds from 1970-01-01 00:00:00 TAI.  Similar to Unix time
    but this includes leap seconds.
    """
    name = 'unix_leap'
    unit = 1.0 / erfa.DAYSEC  # in days (1 day == 86400 seconds)
    epoch_val = '1970-01-01 00:00:00'
    epoch_val2 = None
    epoch_scale = 'tai'  # Scale for epoch_val class attribute
    epoch_format = 'iso'  # Format for epoch_val class attribute


class TimeJD(TimeFormat):
    """
    Julian Date time format.
    """
    name = 'gecam'  # Unique format name

    def set_jds(self, val1, val2):
        """
        Set the internal jd1 and jd2 values from the input val1, val2.
        The input values are expected to conform to this format, as
        validated by self._check_val_type(val1, val2) during __init__.
        """
        pass

    @property
    def value(self):
        """
        Return format ``value`` property from internal jd1, jd2
        """
        return 11


utcStr = "2018-07-01T00:00:01"  # 输入的utc时间  格式保持一致
utcDatetime = datetime.datetime.strptime(utcStr, "%Y-%m-%dT%H:%M:%S")
time2019 = datetime.datetime.strptime(f"2001-01-01 00:00:00", "%Y-%m-%d %H:%M:%S")

metResult = (utcDatetime - time2019).total_seconds()
print(f"输入的utc:{utcDatetime},转met:{metResult}")

t = Time(utcStr, format='isot', scale='utc')

print(t.gps)
print(t.unix)
print(t.unix_leap)
print(t.gecam)

print("=============")

a = Time(1, format="gps")

print(a.to_datetime())
