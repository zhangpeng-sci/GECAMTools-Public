#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import copy

GRD_DIRECTION = {1: (0.0, 0.0), 2: (40.0, 332.17), 3: (40.0, 278.67), 4: (40.0, 225.17), 5: (40.0, 152.17),
                 6: (40.0, 98.67), 7: (40.0, 45.17), 8: (73.5, 350.5), 9: (73.5, 314.5), 10: (73.5, 278.5),
                 11: (73.5, 242.5), 12: (73.5, 206.5), 13: (73.5, 170.5), 14: (73.5, 134.5), 15: (73.5, 98.5),
                 16: (73.5, 62.5), 17: (73.5, 26.5), 18: (90.0, 0.0), 19: (90.0, 305.0), 20: (90.0, 270.0),
                 21: (90.0, 215.0), 22: (90.0, 180.0), 23: (90.0, 125.0), 24: (90.0, 90.0), 25: (90.0, 35.0)}


class Detector:
    """
    detector of GECAM

    """

    def __init__(self):
        # __satellite: a,b
        self._satellite = ""
        self._name = ""
        self._number = None
        self._gain_type = None
        self._direction = (None, None)
        self.type = ""

    def set_direction(self, direction):
        self._direction = direction

    @property
    def direction(self):
        return self._direction

    def set_name(self, name):
        self._name = name

    @property
    def name(self):
        # GRD01,CPD01,HED01
        return self._name

    def set_number(self, number):
        self._number = number

    @property
    def number(self):
        return self._number

    def set_satellite(self, satellite):
        self._satellite = satellite

    @property
    def satellite(self):
        return self._satellite

    @property
    def full_name(self):
        # grd: ag01H、bg02L  cpd：ac01 bc02
        gain_str = self.gain_type
        if gain_str == "high":
            gain = "H"
        elif gain_str == "low":
            gain = "L"
        else:
            gain = ""

        number_fill = str(self.number).zfill(2)
        satellite_short_name = self.satellite  # a,b
        detector_short_name = self.name[0].lower()

        return f"{satellite_short_name}{detector_short_name}{number_fill}{gain}"

    @property
    def gain_type(self):
        return self._gain_type

    def set_gain_type(self, gain_type):

        pass

    @property
    def hdu_name(self, file_type="evt"):
        """
        get hdu name of detector data in data product(fits)
        :param file_type: str
            "evt":event data product, return "EVENTS01"
        :return:
        """
        if file_type == "evt":
            det_num = self.number()
            # EVENTS01
            return f"EVENTS{str(det_num).zfill(2)}"
        else:
            return ""

    def copy(self):
        """
        deep copy current detector object
        Returns:

        """

        return copy.deepcopy(self)

    def unique_gain_type_list(self):

        return [None]


class GRD(Detector):
    """
    detector GRD of GECAM

    __number:number of GRD,range is 1-25
    __gain_type:gain type of GRD. [None,"high","low"] represent all-gain, high-gain, low-gain

    """

    __gain_type_list = ["both", "high", "low"]

    def __init__(self, number: int, gain_type="both"):
        super().__init__()

        if not isinstance(number, int):
            raise ValueError(f"Type of number should be int.")

        if number < 1 or number > 25:
            raise ValueError(f"Range of GRD number should in 1-25.")

        self.set_satellite("b")
        self.set_number(number)
        self.set_gain_type(gain_type)
        self.set_name(f"GRD{str(number).zfill(2)}")
        self.set_direction(GRD_DIRECTION.get(number))
        self.type = "GRD"

    def set_gain_type(self, gain_type):
        if gain_type not in self.__gain_type_list:
            raise ValueError(f"The GRD gain_type should in {self.__gain_type_list}.")

        self._gain_type = gain_type

    @property
    def gain_num(self, return_type=None):

        gain_num = self.gain_type_to_num(self.gain_type())

        if return_type == "list":
            if gain_num is None:
                return [0, 1]
            else:
                return [gain_num]
        else:
            return gain_num

    def gain_type_to_num(self, gain_type):
        """
        Get the number represented by the gain str
        :param gain_type: high,low,None
        :return:
            high:0
            low:1
            None:None
        """
        if gain_type == "high":
            return 0
        elif gain_type == "low":
            return 1
        elif gain_type in ["both", None]:
            return None
        else:
            raise ValueError(f"The 'gain_str' only have <'high'>, <'low'> or <''>, but input is <{gain_type}>")

    def unique_gain_type_list(self):
        # the GRD06 and GRD12 of GECAM-C only have the high-gain
        if self.satellite == "c" and self.number in [6, 12]:
            return ["high"]

        return ["high", "low"]


class CPD(Detector):
    """
    detector CPD of GECAM

    __number:number of GRD,range is 1-8

    """

    def __init__(self, number: int, gain_type=None):

        if not isinstance(number, int):
            raise ValueError(f"Type of number should be int.")

        if number < 1 or number > 8:
            raise ValueError(f"Range of CPD number should in 1-8.")

        super().__init__()

        self.set_satellite("b")
        self.set_number(number)
        self.set_name(f"CPD{str(number).zfill(2)}")
        self.set_gain_type(gain_type)
        self.type = "CPD"

    @property
    def gain_num(self, return_type=None):
        if return_type == "list":
            return [None]
        else:
            return None


class HE(Detector):

    def __init__(self, number: int):

        if not isinstance(number, int):
            raise ValueError(f"Type of number should be int.")

        if number < 1 or number > 18:
            raise ValueError(f"Range of HE number should in 1-18.")

        super().__init__()

        self.set_satellite("HXMT")
        self.set_number(number)
        self.set_name(f"HED{str(number).zfill(2)}")
        self.type = "HE"

    @property
    def full_name(self):
        number_fill = str(self.number).zfill(2)

        return f"HED{number_fill}"


class LE(Detector):

    def __init__(self, number: int):

        if not isinstance(number, int):
            raise ValueError(f"Type of number should be int.")

        if number < 1 or number > 18:
            raise ValueError(f"Range of LE number should in 1-18.")

        super().__init__()

        self.set_satellite("HXMT")
        self.set_number(number)
        self.set_name(f"LED{str(number).zfill(2)}")
        self.type = "LE"

    @property
    def full_name(self):
        number_fill = str(self.number).zfill(2)

        return f"LED{number_fill}"
