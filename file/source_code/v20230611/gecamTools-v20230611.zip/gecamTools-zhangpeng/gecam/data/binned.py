# btime: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import warnings, copy
from collections import OrderedDict
from astropy.io import fits
import numpy as np

from gecam import config
from gecam.data.base import EvtInfo
from gecam.utils import curve_utils, ebounds_utils, feature_utils
from gecam.utils.base_utils import concat_dets_name
from gecam.data.detector import Detector, GRD, CPD
from gecam.data.file import SciDataFile
from gecam.data.curve import Spectrum, ChannelLightCurve, LightCurve
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.spec import SpecFile


class BinnedFile(SciDataFile):

    def __init__(self):
        self.headers = OrderedDict()
        self.info = EvtInfo()

    @classmethod
    def open(cls, file_path):
        """
        open daily or trigger evt fits
        Args:
            file_path (str):

        Returns:

        """
        obj = cls()
        obj._file_properties(file_path)

        with fits.open(file_path, lazy_load_hdus=True) as hdulist:
            for hdu in hdulist:
                obj.headers.update({hdu.name: hdu.header})

            primary_header = hdulist["primary"].header

            data_type = primary_header.get("DATATYPE")
            if data_type not in ["BSPEC", "BTIME"]:
                warnings.warn(f"The type of input file should be BSPEC or BTIME, input is {data_type}.")

            evt_info = obj.info
            evt_info.file_dir = obj._file_dir
            evt_info.file_name = obj._file_name
            evt_info.file_type = data_type

            evt_info.primary_header = primary_header
            evt_info.ebounds = hdulist["EBOUNDS"].data

            telescope = primary_header.get("TELESCOP")
            evt_info.satellite = obj._get_satellite_name_by_telescope(telescope)
            if telescope in ["GECAM-A", "GECAM-B"]:
                evt_info.satellite_full_name = telescope
            elif telescope == "HEBS":
                evt_info.satellite_full_name = "GECAM-C"
            else:
                warnings.warn(f"Unknown telescope:{telescope}")

            evt_info.instrument = primary_header.get("INSTRUME")
            trig_id = primary_header.get("TRIG_ID")
            burst_id = primary_header.get("BURST_ID")
            if trig_id is not None:
                evt_info.trig_id = trig_id
            elif burst_id is not None:
                evt_info.trig_id = burst_id

            trig_met = primary_header.get("TRIGTIME")
            burst_met = primary_header.get("BST_TIME")
            if trig_met is not None:
                evt_info.trig_met = trig_met
            elif burst_met is not None:
                evt_info.trig_met = burst_met

            if evt_info.instrument == "GRD":
                evt_info.detector_type = GRD
            elif evt_info.instrument == "CPD":
                evt_info.detector_type = CPD

            evt_info.obs_met_range = (primary_header.get("TSTART"), primary_header.get("TSTOP"))

            evt_info.loc = (primary_header.get("RA_OBJ"), primary_header.get("DEC_OBJ"), primary_header.get("ERR_RAD"))

            obj.info = evt_info

        return obj

    def select_detector(self, det_num):
        """
        filter events of the select detector number
        Args:
            det_num (int): detector number

        Returns:
            :class:``
        """
        with fits.open(self._file_path, lazy_load_hdus=True) as hdulist:
            det_extension = hdulist[f"SPECTRUM{str(det_num).zfill(2)}"]
            ebounds_extension = hdulist[f"EBOUNDS"].data

            info = self.info
            detector = info.detector_type(det_num)
            detector.set_satellite(info.satellite)

            det_ebounds = ebounds_extension.field(detector.name)
            obj = DetBinned(detector, det_extension.data, det_extension.data, info, det_ebounds)

        return obj

    def plot_light_curve(self, detectors: Detector or list, time_range=None, channel_range=None,
                         lc_kwargs_dic: dict = None, fig_kwargs_dic=None):

        if fig_kwargs_dic is None:
            fig_kwargs_dic = {}
        if lc_kwargs_dic is None:
            lc_kwargs_dic = {}

        lc_x_bins, lc_y, lc_y_err = None, None, None
        for det in detectors:
            if det.gain_type in det.unique_gain_type_list():
                gain_type_list = [det.gain_type]
            else:
                gain_type_list = det.unique_gain_type_list()
            # Calculate the high and low gains separately
            for gain_type in gain_type_list:
                det_events = self.select_detector(det.number)
                det_events.detector.set_gain_type(gain_type)
                print(det_events.detector.full_name)

                det_events = det_events.slice(gain_type, time_range)

                if channel_range is None:
                    channel_range = [0, len(det_events.ebounds)]

                lc_kwargs_dic["channel_bin"] = channel_range
                det_lc = det_events.to_light_curve(**lc_kwargs_dic)
                det_x_bins, det_y, _ = det_lc.get_data(channel_index=0)

                if lc_x_bins is None:
                    lc_x_bins, lc_y = det_x_bins, det_y[0]
                    # reuse the time bins of the first detector
                    time_bin = det_lc.time_bins
                else:
                    lc_y += det_y[0]

        result_x, result_y = lc_x_bins[:-1], lc_y / np.diff(lc_x_bins)
        result_y_err = np.sqrt(result_y)
        plot_lc_data = (result_x, result_y, result_y_err)

        ref_met, bg_range = fig_kwargs_dic.get("ref_met"), fig_kwargs_dic.get("bg_range")
        src_range = fig_kwargs_dic.get("src_range")
        figure = LightCurveFigure(plot_lc_data, trig_time=self.info.trig_met, ref_time=ref_met,
                                  satellite=self.info.satellite_full_name)
        if bg_range is not None:
            figure.add_range_selection(bg_range)
        if src_range is not None:
            figure.add_range_selection([src_range], facecolor="#9a4e0e")

        x_label = figure.xlabel
        x_label += f"\nChannel range={channel_range}\nChoose detectors: {concat_dets_name(detectors, self.info.satellite)}"

        figure.set_title(self.info.satellite_full_name)
        figure.set_xlabel(x_label)

        return plot_lc_data, figure.fig


class DetBinned():

    def __init__(self, detector: Detector, data, primitive_data, evt_info: EvtInfo, ebounds):
        self.detector = detector
        self.data, self.primitive_data = data, primitive_data
        self.evt_info = evt_info
        self.ebounds = ebounds
        self.gain_type = None

        if evt_info.file_type == "BSPEC":
            self.spec_time_interval = 1
            self.spec_channel_num = 128
        elif evt_info.file_type == "BTIME":
            self.spec_time_interval = 0.05
            self.spec_channel_num = 7
        else:
            raise Exception(f"Unknown file type of {evt_info.file_type}")

    def _mask_time(self, data_array, time_range):
        if time_range is not None:
            time_array_all = data_array.field("STARTTIME")
            mask = (time_array_all >= time_range[0]) & (time_array_all < time_range[1])
        else:
            mask = (np.ones(data_array.shape, dtype=np.bool))

        return mask

    def slice(self, gain_type="high", time_range=None):
        if gain_type not in ["high", "low"]:
            raise Exception(f"The gain_type should in ['high', 'low'], current is {gain_type}")

        time_mask = self._mask_time(self.data, time_range)

        sliced_data = self.data[time_mask]
        detector = copy.deepcopy(self.detector)

        obj = DetBinned(detector, sliced_data, self.primitive_data, self.evt_info, self.ebounds)
        obj.gain_type = gain_type

        return obj

    def _split_by_gain_type(self, data_array, gain_type):
        if gain_type == "high":
            counts_of_channels = data_array.field("COUNTS")[:, :self.spec_channel_num]
            dead_time_on_bins = self.spec_time_interval - data_array.field("EXPOSURE")[:, 0]
            temp_ebounds = self.ebounds[:self.spec_channel_num]
        elif gain_type == "low":
            counts_of_channels = data_array.field("COUNTS")[:, self.spec_channel_num:]
            dead_time_on_bins = self.spec_time_interval - data_array.field("EXPOSURE")[:, 1]
            temp_ebounds = self.ebounds[self.spec_channel_num:]
            temp_ebounds[:, 0] = np.arange(0, self.spec_channel_num, dtype=np.int8)
        else:
            raise Exception(f"The gain_type should in ['high', 'low'], current is {gain_type}")

        return counts_of_channels, dead_time_on_bins, temp_ebounds

    def _rebin_time(self, time_bin, base_time_bins, counts_of_channels, dead_time_on_bins):
        if time_bin is None:
            return base_time_bins, counts_of_channels, dead_time_on_bins

        if type(time_bin) in [int, float]:
            if time_bin == self.spec_time_interval:
                return base_time_bins, counts_of_channels, dead_time_on_bins
            elif time_bin < self.spec_time_interval:
                raise Exception(
                    f"The time bin can not less than the bin of {self.evt_info.file_type} ({self.spec_time_interval} s)."
                    f" current is {time_bin} s. ")
            else:
                result_time_bins = []
                result_counts = []
                result_dead_time = []
                time_bin = np.ceil(time_bin / self.spec_time_interval).astype(int)
                i = 0
                while True:
                    if i >= len(base_time_bins) - 1:
                        result_time_bins.append(base_time_bins[-1])
                        break

                    result_time_bins.append(base_time_bins[i])
                    result_counts.append(np.sum(counts_of_channels[i:i + time_bin], axis=0))
                    result_dead_time.append(np.sum(dead_time_on_bins[i:i + time_bin]))

                    i += time_bin
        elif type(time_bin) in [list, np.ndarray]:
            result_time_bins = []
            result_counts = []
            result_dead_time = []

            pre = time_bin[0]
            for post in time_bin[1:]:
                filter = np.where((base_time_bins >= pre) & (base_time_bins < post))

                result_time_bins.append(pre)
                result_counts.append(np.sum(counts_of_channels[filter], axis=0))
                result_dead_time.append(np.sum(dead_time_on_bins[filter]))

                pre = post
            result_time_bins.append(time_bin[-1])

        else:
            raise Exception(f"The type of time bin should in [ list, int ]")

        return np.array(result_time_bins, dtype=np.float), np.array(result_counts), np.array(result_dead_time)

    def _get_channel_bins_by_energy_bin(self, energy_bin, ebounds):
        if type(energy_bin) in [int, float]:

            e_min = ebounds.field("E_MIN")[0]
            e_max = ebounds.field("E_MAX")[-1]

            e_bins = np.arange(e_min, e_max + energy_bin, energy_bin, dtype=np.int16)
        else:
            e_bins = energy_bin

        channel_bins = []
        for energy in e_bins:
            channel_bins.append(ebounds_utils.find_channel_by_energy(ebounds, energy))

        return np.array(channel_bins)

    def _rebin_energy_channel(self, channel_bin=None, energy_bin=None, counts_of_channels=None, ebounds=None):
        if channel_bin is not None:
            if type(channel_bin) == int:
                channel_bins = np.arange(0, len(ebounds) + 1, channel_bin)
            else:
                channel_bins = channel_bin
        elif energy_bin is not None:
            channel_bins = self._get_channel_bins_by_energy_bin(energy_bin, ebounds)
        else:
            channel_bins = np.array([0, len(ebounds) + 1])

        result = []
        pre_bin = channel_bins[0]
        for post_bin in channel_bins[1:]:
            result.append(np.sum(counts_of_channels[:, pre_bin:post_bin], axis=1))

            pre_bin = post_bin

        energy_bins = ebounds_utils.channel_bins_to_energy_bins(channel_bins, ebounds)

        return channel_bins, energy_bins, np.array(result).T

    def _reformat_ebounds(self, ebounds):
        """
        format ebounds
        Args:
            ebounds ():

        Returns:

        """
        result = []
        for item in ebounds:
            result.append((item[0], item[1], item[2]))

        return np.rec.array(result, dtype=[('CHANNEL', 'i4'), ('E_MIN', 'f4'), ('E_MAX', 'f4')])

    def to_light_curve(self, time_range=None, time_bin=1, channel_bin=None, energy_bin=None,
                       correct_by_dead_time=False):
        time_mask = self._mask_time(self.data, time_range)

        data_array = self.data[time_mask]

        temp_detector = self.detector.copy()
        temp_detector.set_gain_type(self.gain_type)

        time_bins = np.append(data_array.field("STARTTIME"), data_array.field("ENDTIME")[-1])

        counts_of_channels, dead_time_on_bins, temp_ebounds = self._split_by_gain_type(data_array, self.gain_type)
        temp_evt_info = self.evt_info.copy()
        temp_evt_info.ebounds = self._reformat_ebounds(temp_ebounds)

        time_bins, counts_of_channels, dead_time_on_bins = self._rebin_time(time_bin, time_bins, counts_of_channels,
                                                                            dead_time_on_bins)
        channel_bins, energy_bins, counts_of_channels = self._rebin_energy_channel(channel_bin, energy_bin,
                                                                                   counts_of_channels,
                                                                                   temp_evt_info.ebounds)

        c_lc_obj_list = []
        for index, c_counts in enumerate(counts_of_channels.T):
            c_channel_range, c_energy_range = channel_bins[index:index + 2], energy_bins[index:index + 2]
            c_lc_obj = ChannelLightCurve(time_bins, c_counts, np.sqrt(c_counts), dead_time_on_bins, c_channel_range,
                                         c_energy_range)
            c_lc_obj_list.append(c_lc_obj)

        obj = LightCurve(temp_detector, time_bins, channel_bins, energy_bins, c_lc_obj_list,
                         dead_time_on_bins, temp_evt_info)
        if correct_by_dead_time is True or type(correct_by_dead_time) == str:
            obj.correct_by_dead_time()

        return obj

    def to_spectrum(self, time_range=None, channel_bin=None, energy_bin=None):
        time_mask = self._mask_time(self.data, time_range)

        data_array = self.data[time_mask]

        temp_detector = self.detector.copy()
        temp_detector.set_gain_type(self.gain_type)

        time_bins = np.append(data_array.field("STARTTIME"), data_array.field("ENDTIME")[-1])

        counts_of_channels, dead_time_on_bins, temp_ebounds = self._split_by_gain_type(data_array, self.gain_type)
        temp_evt_info = self.evt_info.copy()
        temp_evt_info.ebounds = self._reformat_ebounds(temp_ebounds)

        channel_bins, energy_bins, counts_of_channels = self._rebin_energy_channel(channel_bin, energy_bin,
                                                                                   counts_of_channels,
                                                                                   temp_evt_info.ebounds)

        spectrum_data = np.sum(counts_of_channels, axis=0)

        time_range = [data_array.field("STARTTIME")[0], data_array.field("ENDTIME")[-1]]

        exposure = (time_range[1] - time_range[0]) - dead_time_on_bins.sum()

        spec = Spectrum(temp_detector, spectrum_data, np.sqrt(spectrum_data), exposure, time_range, channel_bins,
                        energy_bins, self.evt_info)

        return spec
