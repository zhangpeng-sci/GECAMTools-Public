# base.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import copy


class EvtInfo:
    def __init__(self):
        # a,b,c,HXMT
        self.satellite = None
        # GECAM - A, GECAM - B, GECAM - C, HXMT
        self.satellite_full_name = None
        self.instrument = None
        self.trig_id = None
        self.trig_met = None
        self.obs_met_range = None
        self.loc = None

        self.detector_type = None

        self.ebounds = None
        self.gti=None

        self.primary_header = None

        self.file_dir = None
        self.file_name = None
        self.file_type = None

    def copy(self):
        return copy.deepcopy(self)
