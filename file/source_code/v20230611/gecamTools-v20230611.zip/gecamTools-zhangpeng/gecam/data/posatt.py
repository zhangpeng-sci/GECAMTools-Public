# posatt.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from astropy.io import fits
from collections import OrderedDict

from gecam.data.file import EngDataFile
import scipy
import numpy as np
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation


class PosAtt(EngDataFile):
    """

    """

    def __init__(self):
        super(PosAtt, self).__init__()
        self._headers = OrderedDict()
        self._times = None
        self._data = None

    @classmethod
    def open(cls, filename: str):
        """Open and read a position altitude file

        Args:
            filename (str): The filename of the FITS file

        Returns:
            :class:`PosAtt`: The PosAtt object
        """
        obj = cls()
        obj._file_properties(filename)

        with fits.open(filename) as hdulist:
            for hdu in hdulist:
                obj._headers.update({hdu.name: hdu.header})
            data = hdulist['Orbit_Attitude'].data

        times = data['Time']
        obj._times = times
        obj._data = data

        # set the interpolators
        obj._set_interpolators()

        return obj

    def _set_interpolators(self, kind="nearest"):
        data = self._data
        times = self._times

        # Earth inertial coordinates interpolator
        quat = np.array((data['Q1'], data['Q2'], data['Q3'], data['Q4']))
        self._quat_interp = interp1d(times, quat, kind=kind)

    def get_quat(self, times):
        """
            Retrieve the Gecam attitude quaternions
        Args:
            times (float or np.array): met of GecamMet

        Returns:
            np.array: A (4, `n`) array of quaternions at `n` times

        """
        return self._quat_interp(times).T

    @property
    def headers(self):
        return self._headers

    @property
    def time_range(self):
        return self._times[0], self._times[-1]
