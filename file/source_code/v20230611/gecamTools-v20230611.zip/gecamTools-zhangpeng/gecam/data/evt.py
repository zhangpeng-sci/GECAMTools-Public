# evt2.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import warnings, copy
from collections import OrderedDict
from astropy.io import fits
import numpy as np
import os

from gecam import config
from gecam.data.base import EvtInfo
from gecam.utils import curve_utils, ebounds_utils, feature_utils
from gecam.utils.base_utils import concat_dets_name
from gecam.data.detector import Detector, GRD, CPD
from gecam.data.file import SciDataFile
from gecam.data.curve import Spectrum, ChannelLightCurve, LightCurve
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.spec import SpecFile


class Evt(SciDataFile):

    def __init__(self):
        self.headers = OrderedDict()
        self.file_type = "EVT"
        self.info = EvtInfo()

    @classmethod
    def open(cls, file_path):
        """
        open daily or trigger evt fits
        Args:
            file_path (str):

        Returns:

        """
        obj = cls()
        obj._file_properties(file_path)

        with fits.open(file_path, lazy_load_hdus=True) as hdulist:
            for hdu in hdulist:
                obj.headers.update({hdu.name: hdu.header})

            hdu_name_list = [item.name for item in hdulist]

            primary_header = hdulist["primary"].header

            data_type = primary_header.get("DATATYPE")
            if data_type != obj.file_type:
                warnings.warn(f"The type of input file should be EVT, input is {data_type}.")

            evt_info = obj.info
            evt_info.file_dir = obj._file_dir
            evt_info.file_name = obj._file_name
            evt_info.file_type = data_type

            evt_info.primary_header = primary_header
            evt_info.ebounds = hdulist["EBOUNDS"].data

            telescope = primary_header.get("TELESCOP")
            evt_info.satellite = obj._get_satellite_name_by_telescope(telescope)
            if telescope in ["GECAM-A", "GECAM-B"]:
                evt_info.satellite_full_name = telescope
            elif telescope == "HEBS":
                evt_info.satellite_full_name = "GECAM-C"
            else:
                warnings.warn(f"Unknown telescope:{telescope}")

            evt_info.instrument = primary_header.get("INSTRUME")
            trig_id = primary_header.get("TRIG_ID")
            burst_id = primary_header.get("BURST_ID")
            if trig_id is not None:
                evt_info.trig_id = trig_id
            elif burst_id is not None:
                evt_info.trig_id = burst_id

            trig_met = primary_header.get("TRIGTIME")
            burst_met = primary_header.get("BST_TIME")
            if trig_met is not None:
                evt_info.trig_met = trig_met
            elif burst_met is not None:
                evt_info.trig_met = burst_met

            if evt_info.instrument == "GRD":
                evt_info.detector_type = GRD
            elif evt_info.instrument == "CPD":
                evt_info.detector_type = CPD

            evt_info.obs_met_range = (primary_header.get("TSTART"), primary_header.get("TSTOP"))

            evt_info.loc = (primary_header.get("RA_OBJ"), primary_header.get("DEC_OBJ"), primary_header.get("ERR_RAD"))

            if "GTI" in hdu_name_list:
                evt_info.gti = hdulist["GTI"].data

            obj.info = evt_info

        return obj

    def crop(self, time_range=None, out_dir=None):
        """
        Crop and save the data according to the time range
        Args:
            time_range (list or tuple):
            out_dir (str, optional): default: file dir

        Returns:

        """
        if time_range is None:
            raise Exception("The input [time_range] could not be None.")

        if out_dir is None:
            out_dir = self.file_dir

        with fits.open(self.file_path, lazy_load_hdus=True) as hdulist:
            new_hdu_list = fits.HDUList()
            new_hdu_list.append(fits.PrimaryHDU(header=hdulist['PRIMARY'].header))

            for hdu in hdulist:
                hdu_name = hdu.name
                hdu_header = hdu.header
                hdu_data = hdu.data
                if hdu_name == "PRIMARY":
                    continue

                if "EVENTS" not in hdu_name:
                    temp_hdu = fits.BinTableHDU(data=hdu_data, name=hdu_name, header=hdu_header)
                else:
                    time_list = hdu_data["TIME"]
                    time_filter = (time_list >= time_range[0]) & (time_list < time_range[1])
                    new_hdu_data = hdu_data[time_filter]

                    temp_hdu = fits.BinTableHDU(data=new_hdu_data, name=hdu_name, header=hdu_header)

                new_hdu_list.append(temp_hdu)

            fnamePre, ext = os.path.splitext(self.file_name)
            new_file_name = f"{fnamePre}_{time_range[0]}+{time_range[1] - time_range[0]}{ext}"
            out_path = os.path.join(out_dir, new_file_name)

            new_hdu_list.writeto(out_path, checksum=True)
            return out_path

    def get_dets_plot_lc_data(self, detectors, time_range, time_bin, channel_range, energy_range, only_recommend,
                              correct_by_dead_time):
        """
        Get the light curve data of multiple detectors
        Args:
            detectors ():
            time_range ():
            time_bin ():
            channel_range ():
            energy_range ():
            only_recommend ():

        Returns:

        """
        lc_x_bins, lc_y, lc_y_err = None, None, None
        for det in detectors:
            if det.gain_type in det.unique_gain_type_list():
                gain_type_list = [det.gain_type]
            else:
                gain_type_list = det.unique_gain_type_list()
            # Calculate the high and low gains separately
            for gain_type in gain_type_list:
                det_events = self.select_detector(det.number)
                det_events.detector.set_gain_type(gain_type)
                print(det_events.detector.full_name)

                det_events = det_events.slice(gain_type, time_range, channel_range, energy_range, only_recommend)

                det_lc = det_events.to_light_curve(time_range=time_range, time_bin=time_bin,
                                                   channel_bin=config.CHANNEL_RANGE,
                                                   correct_by_dead_time=correct_by_dead_time)
                det_x_bins, det_y, _ = det_lc.get_data(channel_index=0)

                if lc_x_bins is None:
                    lc_x_bins, lc_y = det_x_bins, det_y[0]

                    # reuse the time bins of the first detector
                    time_bin = det_lc.time_bins
                else:
                    lc_y += det_y[0]

        result_x, result_y = lc_x_bins[:-1], lc_y / np.diff(lc_x_bins)
        result_y_err = np.sqrt(lc_y) / np.diff(lc_x_bins)

        return result_x, result_y, result_y_err

    def plot_light_curve(self, detectors: Detector or list, time_range=None, time_bin=1, channel_range=None,
                         energy_range=None, only_recommend=True, src_range=None, bg_range=None, ref_met=None,
                         correct_by_dead_time=True):
        """
        plot light curve
        Args:

            detectors (Detector):
            time_range (list): met range
            time_bin (float): time bin width , unit is second
            channel_range (list): channel range
            energy_range (list): energy range
            only_recommend (bool): if only choose recommended events
            src_range (list): one source time range
            bg_range (list): multiple background time range (absolute met)
            ref_met (): reference met
            correct_by_dead_time (bool): if correct by dead time

        Returns:
            plot_lc_data (dict): data dict
            fig (Fig): graph object

        """
        if type(detectors) is not list:
            detectors = [detectors]

        if channel_range is None and energy_range is None:
            channel_range = config.CHANNEL_RANGE

        plot_lc_data = self.get_dets_plot_lc_data(detectors, time_range, time_bin, channel_range, energy_range,
                                                  only_recommend, correct_by_dead_time)

        figure = LightCurveFigure(plot_lc_data, trig_time=self.info.trig_met, ref_time=ref_met,
                                  satellite=self.info.satellite_full_name)
        if bg_range is not None:
            figure.add_range_selection(bg_range)
        if src_range is not None:
            figure.add_range_selection([src_range], facecolor="#9a4e0e")

        x_label = figure.xlabel
        x_label += f"\nChannel range={channel_range}\nChoose detectors: {concat_dets_name(detectors, self.info.satellite)}"

        figure.set_title(self.info.satellite_full_name)
        figure.set_xlabel(x_label)

        return plot_lc_data, figure.fig

    def get_dets_plot_spec_data(self, detectors, time_range, channel_bin, energy_bin, channel_range,
                                energy_range, only_recommend):
        """

        Args:
            detectors ():
            time_range ():
            channel_bin ():
            energy_bin ():
            channel_range ():
            energy_range ():
            only_recommend ():

        Returns:

        """
        spec_c_bins, spec_e_bins, spec_y, spec_y_err = None, None, None, None
        for det in detectors:
            det_events_all = self.select_detector(det.number)
            det_events = det_events_all.slice(det.gain_type, time_range, channel_range, energy_range, only_recommend)

            det_spec = det_events.to_spectrum(time_range, channel_bin, energy_bin)
            det_c_bins, det_e_bins, det_y, _ = det_spec.get_data()

            if spec_c_bins is None:
                spec_c_bins, spec_e_bins, spec_y = det_c_bins, det_e_bins, det_y
            else:
                spec_y += det_y

        result_c_x, result_e_x, result_y = spec_c_bins[:-1], spec_e_bins[:-1], spec_y
        result_y_err = np.sqrt(result_y)

        return result_c_x, result_e_x, result_y, result_y_err

    def plot_spectrum(self, detectors, time_range=None, channel_bin=None, energy_bin=None, channel_range=None,
                      energy_range=None, only_recommend=True):
        """
        plot spectrum
        Args:
            detectors (list of Detector): detector list
            time_range (list): [time_start, time_stop]
            channel_bin (list): channel bin list
            energy_bin (list): energy bin list
            channel_range (list): [channel_start, channel_stop]
            energy_range (list): [energy_start, energy_stop]
            only_recommend (bool):

        Returns:

        """
        if type(detectors) is not list:
            detectors = [detectors]

        if channel_bin is None and energy_bin is None:
            channel_bin = 1
            x_type = "channel"
        elif energy_bin is not None:
            x_type = "energy"
        else:
            x_type = "channel"

        plot_spec_data = self.get_dets_plot_spec_data(detectors, time_range, channel_bin, energy_bin, channel_range,
                                                      energy_range, only_recommend)

        figure = SpectrumFigure(plot_spec_data, x_type=x_type)

        x_label = f"Channel, channel bin={channel_bin}" \
                  f"\nTime range: {time_range}" \
                  f"\nChoose detectors: {concat_dets_name(detectors, self.info.satellite)}"

        figure.set_title(self.info.satellite_full_name)
        figure.set_xlabel(x_label)

        return plot_spec_data, figure.fig

    def generate_spec_file(self, det_list: [Detector], src_range_list, channel_bin: [list, list], bg_range_list,
                           rsp_list: [[str, str]] = None, time_bin=1, bg_fit_method="2pass", bg_fit_order=1,
                           only_recommend=True, out_dir=""):
        """
        generate spec file of multiple detectors

        Args:
            det_list (:class:`~gecam.data.detector.Detector`): Detector object list
            src_range_list (list): source time range list (absolute time)
                                    eg:[ [ src_start1,src_stop1 ], [ src_start2,src_stop2 ]  ]
            channel_bin (list): channel bins of high gain and low gain
                            eg: [ channel_bins_high_gain, channel_bins_low_gain ]
                            channel_bins_high_gain and channel_bins_low_gain can be int or 1D-list.
            bg_range_list (list): background time range list (absolute time)
                            eg: [ [ bg_start1,bg_stop1 ], [ bg_start2,bg_stop2 ]]
            rsp_list (list): rsp file path list corresponding to each detector on Args: det_list
                            eg: [ [det1_rsp_high_gain, det1_rsp_low_gain],[det2_rsp_high_gain, det2_rsp_low_gain] ]
            time_bin (float): time bin (second) of light curve
            bg_fit_method (str): 2pass
            bg_fit_order (int): fit order of background light curve
            only_recommend (bool): True: only choose recommend events(`FLAG`<10). Flase: not filter `FLAG`
            out_dir (str): output dir of spec file

        Returns:
            result (dict): spectrum data of each detector with differential gain
                            eg: {
                                "bg01H": {
                                    "bg_lc":BackgroundLightCurve,
                                    "src_spec_list":[ src_range1, spec, bg_spec, net_spec ]
                                }
                            }

        """
        result = {}

        temp_range = np.concatenate((np.array(bg_range_list).flatten(), np.array(src_range_list).flatten()))
        lc_total_range = [temp_range.min() - 1, temp_range.max() + 1]

        for index, det in enumerate(det_list):
            det_events_all = self.select_detector(det.number)
            if rsp_list is not None:
                det_rsp_list = rsp_list[index]
            else:
                det_rsp_list = None

            det_c_rsp_list = self.match_det_channel_and_rsp(det, channel_bin, det_rsp_list)
            for gain_type, c_bins, rsp in det_c_rsp_list:
                temp_det: Detector = copy.deepcopy(det)
                temp_det.set_gain_type(gain_type), temp_det.set_satellite(self.info.satellite)
                print(temp_det.full_name)

                det_events = det_events_all.slice(gain_type, only_recommend=only_recommend)

                det_lc = det_events.to_light_curve(time_range=lc_total_range, time_bin=time_bin, channel_bin=c_bins)
                det_bg_lc = det_lc.fit_background(bg_range_list, fit_method=bg_fit_method, fit_order=bg_fit_order)
                spec_file = SpecFile(det_lc, det_bg_lc)

                det_spec_list = []
                for src_range in src_range_list:
                    spec, bg_spec, net_spec = spec_file.add_src(src_range)
                    det_spec_list.append([src_range, spec, bg_spec, net_spec])

                # feature_dic = {
                #     "T90": feature_utils.calculate_time_duration(det_lc, det_bg_lc, bg_range_list,"T90")
                # }

                result[temp_det.full_name] = {"lc": det_lc, "bg_lc": det_bg_lc, "src_spec_list": det_spec_list}

                spec_file.write(out_dir, rsp_path=rsp)

        return result

    def select_detector(self, det_num):
        """
        filter events of the select detector number
        Args:
            det_num (int): detector number

        Returns:
            :class:``
        """
        with fits.open(self._file_path, lazy_load_hdus=True) as hdulist:
            det_extension = hdulist[f"EVENTS{str(det_num).zfill(2)}"]

            info = self.info

            detector = info.detector_type(det_num)
            detector.set_satellite(info.satellite)

            obj = DetEvents(detector, det_extension.data, det_extension.data, info)

        return obj


class DetEvents():
    """
    events of single detector
    """

    def __init__(self, detector, data, primitive_data, evt_info: EvtInfo):
        self.detector = detector
        # ('TIME', '>f8'), ('PI', '>i2'), ('GAIN_TYPE', 'u1'), ('DEAD_TIME', '>f4'),
        # ('EVT_TYPE', 'u1'), ('FLAG', 'u1'), ('EVT_PAIR', 'u1', (1,))
        self.primitive_data, self.data = primitive_data, data
        self.ebounds = evt_info.ebounds

        self.evt_info = evt_info
        self.trig_met = evt_info.trig_met

        self._time_array = data.field("TIME")
        self._channel_array = data.field("PI")

    def slice_in_custom(self, mask, mark_gain_type):
        """
        slice data in custom
        Args:
            mask: condition of filter events
            mark_gain_type: gain type of Detector. only used to mark without filter events

        Returns:

        """
        sliced_data = self.data[mask]

        detector = copy.deepcopy(self.detector)
        detector.set_gain_type(mark_gain_type)

        return DetEvents(detector, sliced_data, self.primitive_data, self.evt_info)

    def slice(self, gain_type="both", time_range=None, channel_range=None, energy_range=None, only_recommend=True):
        """
        slice events
        Args:
            gain_type (str): 'both', 'high' or 'low'
            time_range (list or tuple): min_time<= time < max_time
            channel_range (list or tuple): min_channel <= channel < max_channel
            energy_range (list or tuple): min_energy <= energy < max_energy
            only_recommend (bool):
                True: only choose recommend events (Flag < 10).
                False: not filter 'Flag'

        Returns:
            DetEvents

        """

        mask = self._mask_det_gain_type(gain_type) & self._mask_time(time_range) & self._mask_recommend_events(
            only_recommend)

        if channel_range is not None:
            mask = mask & self._mask_channel(channel_range)
        elif energy_range is not None:
            mask = mask & self._mask_energy(energy_range)

        sliced_data = self.data[mask]
        if len(sliced_data) == 0:
            warnings.warn(f"After slice operation, there is no events left. Please reset the slice filter.")

        detector = copy.deepcopy(self.detector)
        detector.set_gain_type(gain_type)

        return DetEvents(detector, sliced_data, self.primitive_data, self.evt_info)

    def _mask_data_by_range_type(self, data_list, data_range):
        if data_range is None:
            return (True)
        mask = (data_list >= data_range[0]) & (data_list < data_range[1])
        return mask

    def _mask_recommend_events(self, only_recommend=True):
        """
        if only choose recommended events
        Args:
            only_recommend (bool):

        Returns:

        """
        if only_recommend:
            return (self.data.field("FLAG") < 10)

        return (True)

    def _mask_det_gain_type(self, gain_type):

        if gain_type == "high":
            mask = (self.data.field("GAIN_TYPE") == 0)
        elif gain_type == "low":
            mask = (self.data.field("GAIN_TYPE") == 1)
        else:
            mask = (True)

        return mask

    def _mask_time(self, time_range):

        if time_range is None:
            return (True)

        time_array_all = self.data.field("TIME")
        mask = (time_array_all >= time_range[0]) & (time_array_all < time_range[1])

        return mask

    def _mask_energy(self, energy_range):
        if energy_range is None:
            return (True)

        channel_start, channel_stop = ebounds_utils.find_channels_by_energy_list(self.ebounds, energy_range)

        channel_array_all = self.data.field("PI")
        mask = (channel_array_all >= channel_start) & (channel_array_all <= channel_stop)

        return mask

    def _mask_channel(self, channel_range):
        if channel_range is None:
            return (True)

        channel_array_all = self.data.field("PI")
        mask = (channel_array_all >= channel_range[0]) & (channel_array_all < channel_range[1])

        return mask

    def _get_channel_bins(self, channel_bin):
        c_min, c_max = 0, len(self.ebounds)
        if channel_bin is None:
            return [c_min, c_max]
        elif type(channel_bin) in [int, float]:
            return np.arange(c_min, c_max + channel_bin, channel_bin, dtype=np.int16)
        else:
            return channel_bin

    def _get_channel_bins_by_energy_bin(self, energy_bin, ebounds):
        if type(energy_bin) in [int, float]:

            e_min = ebounds.field("E_MIN")[0]
            e_max = ebounds.field("E_MAX")[-1]

            e_bins = np.arange(e_min, e_max + energy_bin, energy_bin, dtype=np.int16)
        else:
            e_bins = energy_bin

        channel_bins = []
        for energy in e_bins:
            channel_bins.append(ebounds_utils.find_channel_by_energy(ebounds, energy))

        return np.array(channel_bins)

    def _channel_bins_to_energy_bins(self, channel_bins):
        energy_bins = []
        for index, c in enumerate(channel_bins):
            e_start, e_stop = ebounds_utils.find_energy_range_by_channel(self.ebounds, c)

            if index == len(channel_bins) - 1:
                energy_bins.append(e_stop)
            else:
                energy_bins.append(e_start)

        return np.array(energy_bins)

    def _check_bins_is_increase(self, bins):
        """
        check bins list is increase
        Args:
            bins (np.array):

        Returns:

        """
        bins_diff = np.diff(bins)
        bins_wrong_index_list = np.where(bins_diff < 1)[0]
        if len(bins_wrong_index_list) > 0:
            return False

        return True

    def _get_channel_and_energy_bins(self, channel_bin=None, energy_bin=None):
        if channel_bin is not None:
            channel_bins = self._get_channel_bins(channel_bin)
        elif energy_bin is not None:
            channel_bins = self._get_channel_bins_by_energy_bin(energy_bin, self.ebounds)
        else:
            channel_bins = self._get_channel_bins(channel_bin=None)

        energy_bins = self._channel_bins_to_energy_bins(channel_bins)

        return channel_bins, energy_bins

    def _get_dead_time(self, time_bins, correct_by_dead_time=None, det_num=None):
        gain_type = self.detector.gain_type

        if gain_type == "high":
            mask = (self.primitive_data.field("GAIN_TYPE") == 0)
            temp_data = self.primitive_data[mask]
        elif gain_type == "low":
            mask = (self.primitive_data.field("GAIN_TYPE") == 1)
            temp_data = self.primitive_data[mask]
        else:
            warnings.warn(
                "Dead time calculations must distinguish between high and low gain, and the current gain type is both")
            temp_data = self.primitive_data

        dead_time_on_bins = curve_utils.generate_dead_time(temp_data.field("TIME"), time_bins,
                                                           temp_data.field("DEAD_TIME"))

        return dead_time_on_bins

    def to_light_curve(self, time_range=None, time_bin=1, channel_bin=None, energy_bin=None,
                       correct_by_dead_time=False) -> LightCurve:
        """
        generate light curve
        Args:
            correct_by_dead_time (bool or str): bool: if correct counts by dead time; str: dead time file, such as HXMT DeadTime_Proportion.txt
            time_range (tuple or list): [start_met, stop_met)
            time_bin (float or list): time bin (float) or time bins (list)
            channel_bin (float or list): channel bin (float) or channel bins (list)
            energy_bin (float or list): energy bin (float) or energy bins (list)

        Returns:

        """
        time_array, channel_array = self._time_array, self._channel_array

        if time_range is None:
            time_range = (time_array.min(), time_array.max())

        channel_bins, energy_bins = self._get_channel_and_energy_bins(channel_bin, energy_bin)

        if not self._check_bins_is_increase(channel_bins):
            warnings.warn(f"Channel_bins is not incremental.")

        time_bins = curve_utils.generate_time_bins(time_range, time_bin, self.trig_met)
        dead_time_on_bins = self._get_dead_time(time_bins, correct_by_dead_time, self.detector.number)
        y, (time_x, channel_x) = np.histogramdd((time_array, channel_array), (time_bins, channel_bins))

        c_lc_obj_list = []
        for index, c_counts in enumerate(y.T):
            c_channel_range, c_energy_range = channel_bins[index:index + 2], energy_bins[index:index + 2]
            c_lc_obj = ChannelLightCurve(time_x, c_counts, np.sqrt(c_counts), dead_time_on_bins, c_channel_range,
                                         c_energy_range)
            c_lc_obj_list.append(c_lc_obj)

        obj = LightCurve(self.detector, time_bins, channel_bins, energy_bins, c_lc_obj_list,
                         dead_time_on_bins, self.evt_info)
        if correct_by_dead_time is True or type(correct_by_dead_time) == str:
            obj.correct_by_dead_time()

        return obj

    def to_spectrum(self, time_range=None, channel_bin=None, energy_bin=None):
        """
        generate energy spectrum
        Args:
            time_range ():
            channel_bin ():
            energy_bin ():

        Returns:

        """
        time_array, channel_array = self._time_array, self._channel_array

        if time_range is None:
            time_range = [time_array.min(), time_array.max()]
        else:
            mask = self._mask_time(time_range)
            channel_array = channel_array[mask]

        channel_bins, energy_bins = self._get_channel_and_energy_bins(channel_bin, energy_bin)

        y, _ = np.histogram(channel_array, channel_bins)

        exposure = time_range[1] - time_range[0]

        spec = Spectrum(self.detector, y, np.sqrt(y), exposure, time_range, channel_bins, energy_bins, self.evt_info)

        return spec
