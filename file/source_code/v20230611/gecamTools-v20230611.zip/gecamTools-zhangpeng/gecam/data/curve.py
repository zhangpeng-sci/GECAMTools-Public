# curve.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import copy
import numpy as np
from gecam.data.base import EvtInfo
from gecam.data.detector import Detector
from gecam.plot.base_curve import LineFigure


def trunc_background_lc(time_bins, channel_counts, bg_time_range: list, exposure_on_bins):
    """
    truncate background light curve on channel-light-curve
    Args:
        time_bins (np.array): ntimes, time bins
        channel_counts (np.array): (``nchans``, ``ntimes``) array_like
                Count data of each channel over time bins.
        bg_time_range (list): background time range list

    Returns:
        bg_time_bins_pre (np.array): left edge of background time bins
        bg_time_bins_post (np.array): right edge of background time bins
        bg_counts (np.array): (``nchans``, ``ntimes``) array_like
                Background count data of each channel over time bins.
    """
    bg_counts, bg_exposures = None, None
    bg_time_bins_pre = None
    bg_time_bins_post = None

    for t_start, t_stop in bg_time_range:
        start_index_list = np.where(time_bins <= t_start)[0]
        if len(start_index_list) > 0:
            start_index = start_index_list[-1]
        else:
            start_index = 0

        stop_index_list = np.where(time_bins >= t_stop)[0]
        if len(stop_index_list) > 0:
            stop_index = stop_index_list[0]
        else:
            stop_index = len(time_bins) - 1

        if stop_index - start_index <= 0:
            stop_index = start_index + 1

        item_bg_time_bins = time_bins[start_index:stop_index + 1]
        item_bg_time_bins_pre = item_bg_time_bins[:-1]
        item_bg_time_bins_post = item_bg_time_bins[1:]

        item_bg_counts = channel_counts[:, start_index:stop_index]
        item_exposure = exposure_on_bins[start_index:stop_index]

        if bg_counts is None:
            bg_time_bins_pre = item_bg_time_bins_pre
            bg_time_bins_post = item_bg_time_bins_post

            bg_counts, bg_exposures = item_bg_counts, item_exposure
        else:
            bg_time_bins_pre = np.concatenate((bg_time_bins_pre, item_bg_time_bins_pre), axis=0)
            bg_time_bins_post = np.concatenate((bg_time_bins_post, item_bg_time_bins_post), axis=0)

            bg_counts = np.concatenate((bg_counts, item_bg_counts), axis=1)
            bg_exposures = np.concatenate((bg_exposures, item_exposure), axis=0)

    return bg_time_bins_pre, bg_time_bins_post, bg_counts, bg_exposures


class Spectrum():
    """
    enerpy spectrum

    Attributes:
        detector (Detector):detector
        counts (np.ndarray):
        counts_err (np.ndarray):
        exposure (np.ndarray):
        time_range (list or tuple):
        channel_bins (np.ndarray):
        energy_bins (np.ndarray):
        evt_info (EvtInfo):
        mark (str): mark 'primary' or 'custom'
    """

    def __init__(self, detector, counts, counts_err, exposure, time_range, channel_bins, energy_bins, evt_info,
                 mark="primary"):
        """

        Args:
            detector (Detector):
            counts (np.ndarray): not correct by deadtime
            counts_err (np.ndarray):
            exposure (np.ndarray): exposure
            time_range (list or tuple):
            channel_bins (np.ndarray):
            energy_bins (np.ndarray):
            evt_info (EvtInfo):
            mark (str):mark 'primary' or 'custom'
        """
        self.counts, self.counts_err, self.exposure, self.time_range = counts, counts_err, exposure, time_range
        self.evt_info = evt_info
        self.detector = copy.deepcopy(detector)
        self.mark = mark

        self.channel_bins, self.energy_bins = channel_bins, energy_bins
        self._flag_correct_by_dead_time = False

        # if corrected_deadtime is True:
        #     self.counts_corrected_deadtime, self.counts_err_corrected_deadtime = counts, counts_err
        #     self._flag_correct_by_dead_time = True
        # else:
        #     self._flag_correct_by_dead_time = False
        #     self.counts_corrected_deadtime, self.counts_err_corrected_deadtime = None, None

    @property
    def flag_correct_by_dead_time(self):
        return self._flag_correct_by_dead_time

    def get_data(self):
        return self.channel_bins, self.energy_bins, self.counts, self.counts_err

    def get_plot_data(self):
        """
        get the spectrum (converted counts to counts per second) to plot figure
        By default, the energy spectrum after the dead time correction is automatically selected
        Returns:
            if self.counts_corrected_deadtime is not None

        """
        return self.channel_bins[:-1], self.energy_bins[:-1], \
            self.counts / self.exposure, self.counts_err / self.exposure


class ChannelLightCurve():

    def __init__(self, time_bins, counts, counts_err, dead_time_on_bins, channel_range, energy_range):
        self.time_bins, self.counts, self.counts_err = time_bins, counts, counts_err
        self.counts_uncorrect_by_dead_time = counts
        self.count_error_uncorrect_by_dead_time = counts_err

        self.dead_time_on_bins = dead_time_on_bins
        self.exposure_on_bins = np.diff(time_bins) - dead_time_on_bins

        self.channel_range, self.energy_range = channel_range, energy_range

        self.channel_bg_lc: ChannelBackgroundLightCurve = None

        self._flag_correct_by_dead_time = False

    @property
    def flag_correct_by_dead_time(self):
        return self._flag_correct_by_dead_time

    def correct_by_dead_time(self, correct_factor=None):
        """
        correct counts by dead time
        Returns:

        """
        if self._flag_correct_by_dead_time is True:
            return

        if correct_factor is None:
            correct_factor = (self.exposure_on_bins / np.diff(self.time_bins))

        self.counts_uncorrect_by_dead_time = self.counts
        self.count_error_uncorrect_by_dead_time = self.counts_err

        self.counts = self.counts / correct_factor
        self.counts_err = np.sqrt(self.counts)

        self._flag_correct_by_dead_time = True

    def fit_background(self, bg_time_range, fit_method="2pass", fit_order=1):
        """
        fit background of the light curve
        Args:
            bg_time_range (list): background time range
            fit_method (str): fit method
            fit_order (int): order of fit function

        Returns:

        """
        from gecam.fitting.polynomial_fitter import PolynomialFitter

        # channel_counts uncorrect_by_dead_time
        channel_counts = self.counts_uncorrect_by_dead_time[np.newaxis, :]
        # truncate background light curve
        bg_t_pre, bg_t_post, bg_range_counts, bg_range_exposures = trunc_background_lc(self.time_bins, channel_counts,
                                                                                       bg_time_range,
                                                                                       self.exposure_on_bins)

        background_fitter = PolynomialFitter(bg_range_counts, bg_t_pre, bg_t_post, bg_range_exposures)
        background_fitter.fit_method = fit_method
        _, _ = background_fitter.fit(fit_order)
        test_statistic = background_fitter.test_statistic[0]
        dof = background_fitter.dof[0]

        time_bins = self.time_bins
        bg_counts, bg_counts_err = background_fitter.interpolate(time_bins[:-1], time_bins[1:],
                                                                 exposure=None)

        fit_info = [fit_method, fit_order, test_statistic, dof, test_statistic / dof]

        self.channel_bg_lc.counts = bg_counts[0]
        self.channel_bg_lc.counts_err = bg_counts_err[0]
        self.channel_bg_lc.fit_info = fit_info
        self.channel_bg_lc.bg_time_range = bg_time_range

        return self.channel_bg_lc

    def get_data(self):
        return self.time_bins, self.counts, self.counts_err

    def get_plot_data(self):
        return self.time_bins[:-1], self.counts, self.counts_err


class ChannelBackgroundLightCurve():

    def __init__(self, time_bins, counts, counts_err, dead_time_on_bins, channel_range, energy_range, bg_time_range,
                 fit_info):
        self.time_bins, self.counts, self.counts_err = time_bins, counts, counts_err

        self.dead_time_on_bins = dead_time_on_bins
        self.exposure_on_bins = np.diff(time_bins) - dead_time_on_bins

        self.channel_range, self.energy_range = channel_range, energy_range

        self.bg_time_range = bg_time_range
        self.fit_info = fit_info

    def get_plot_data(self):
        return self.time_bins[:-1], self.counts, self.counts_err

    def get_data(self):
        return self.time_bins, self.counts, self.counts_err


class ChannelNetLightCurve():

    def __init__(self, time_bins, counts, counts_err, channel_total_lc: ChannelLightCurve,
                 channel_bg_lc: ChannelBackgroundLightCurve):
        self.time_bins, self.counts, self.counts_err = time_bins, counts, counts_err

        self.channel_total_lc, self.channel_bg_lc = channel_total_lc, channel_bg_lc

    def get_plot_data(self):
        return self.time_bins[:-1], self.counts, self.counts_err

    def get_data(self):
        return self.time_bins, self.counts, self.counts_err


class LightCurve():

    def __init__(self, detector, time_bins, channel_bins, energy_bins, channel_lc_list, dead_time_on_bins,
                 evt_info: EvtInfo):
        """

        Args:
            detector ():
            time_bins ():
            channel_bins ():
            energy_bins ():
            channel_lc_list (list of ChannelLightCurve):
            dead_time_on_bins ():
            evt_info ():
        """
        self.evt_info = evt_info

        self.detector = copy.deepcopy(detector)
        self.ebounds = evt_info.ebounds

        self.channel_lc_list = channel_lc_list

        self.time_bins, self.dead_time_on_bins = time_bins, dead_time_on_bins
        self.exposure_on_bins = np.diff(time_bins) - dead_time_on_bins

        self.time_range = [time_bins[0], time_bins[-1]]

        self.channel_bins = channel_bins
        self.energy_bins = energy_bins

        # on default: correct the light curve by deadtime
        self._flag_correct_by_dead_time = None
        self.correct_by_dead_time()

    def update_channel_lc(self, time_bins, counts, counts_err, dead_time_on_bins):
        counts = np.array(counts)
        counts_err = np.array(counts_err)
        if len(counts.shape) == 1:
            counts = counts[np.newaxis, :]
            counts_err = counts_err[np.newaxis, :]

        c_lc_obj_list = []
        for index in range(len(counts)):
            c_channel_range, c_energy_range = self.channel_bins[index:index + 2], self.energy_bins[index:index + 2]
            c_lc_obj = ChannelLightCurve(time_bins, counts[index], counts_err[index], dead_time_on_bins,
                                         c_channel_range,
                                         c_energy_range)
            c_lc_obj_list.append(c_lc_obj)

    def _check_channel_index(self, channel_index):
        channel_len = len(self.channel_lc_list)

        if channel_index is None or channel_index < 0 or channel_index >= channel_len:
            raise ValueError(
                f"The input channel_index ({channel_index}) out of range (max channel index: {channel_len - 1}).")

    def get_channel_lc(self, channel_index=None):
        """
        get light curve of chose channel index
        Args:
            channel_index:

        Returns:

        """
        if channel_index is None:
            channel_lc_list = self.channel_lc_list
        else:
            self._check_channel_index(channel_index)
            channel_lc_list = self.channel_lc_list[channel_index]

        return channel_lc_list

    def concate_channel_lc(self):
        """
        concatenate light curve of each channel
        Returns:
                counts : (``nchans``, ``ntimes``) array_like
                Count data of each channel over time bins.
        """
        counts = []

        for channel_lc in self.channel_lc_list:
            counts.append(channel_lc.counts)

        return np.array(counts)

    def get_plot_data(self, correct_by_dead_time=True, channel_index=None):
        """
        get the data for plot
        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:
            (np.array, np.array, np.array): times, counts(counts/s), counts(counts/s) error

        """

        time_bins, y_list, y_err_list = self.get_data(correct_by_dead_time=correct_by_dead_time,
                                                      channel_index=channel_index)

        result_y = np.sum(y_list, axis=0) / np.diff(time_bins)
        result_y_err = np.sqrt(np.sum(y_list, axis=0)) / np.diff(time_bins)

        return time_bins[:-1], result_y, result_y_err

    def get_data(self, correct_by_dead_time=True, channel_index=None):
        """

        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:
            (np.ndarray, np.ndarray, np.ndarray)

        """
        if channel_index is not None:
            self._check_channel_index(channel_index)
            channel_lc_list = [self.channel_lc_list[channel_index]]
        else:
            channel_lc_list = self.channel_lc_list

        y_list = []
        y_err_list = []

        if correct_by_dead_time is True:
            for c_lc in channel_lc_list:
                y_list.append(c_lc.counts)
                y_err_list.append(c_lc.counts_err)
        else:
            for c_lc in channel_lc_list:
                y_list.append(c_lc.counts_uncorrect_by_dead_time)
                y_err_list.append(c_lc.count_error_uncorrect_by_dead_time)

        return self.time_bins, np.array(y_list), np.array(y_err_list)

    @property
    def flag_correct_by_dead_time(self):
        return self._flag_correct_by_dead_time

    def correct_by_dead_time(self):
        """
        correct counts by dead time
        Returns:

        """
        if self._flag_correct_by_dead_time is True:
            return

        correct_factor = (self.exposure_on_bins / np.diff(self.time_bins))
        for channel_lc in self.channel_lc_list:
            channel_lc.correct_by_dead_time(correct_factor)

        self._flag_correct_by_dead_time = True

    def fit_background(self, bg_time_range, fit_method="2pass", fit_order=1):
        """
        fit background of the light curve
        Args:
            bg_time_range (list): background time range
            fit_method (str): fit method
            fit_order (int): order of fit function

        Returns:

        """
        from gecam.fitting.polynomial_fitter import PolynomialFitter

        time_bins, exposure_on_bins = self.time_bins, self.exposure_on_bins
        dead_time_on_bins = self.dead_time_on_bins

        channel_counts_all = []
        for channel_lc in self.channel_lc_list:
            channel_counts_all.append(channel_lc.counts_uncorrect_by_dead_time)
        channel_counts_all = np.array(channel_counts_all)

        # truncate background light curve
        bg_t_pre, bg_t_post, bg_range_counts, bg_range_exposures = trunc_background_lc(self.time_bins,
                                                                                       channel_counts_all,
                                                                                       bg_time_range,
                                                                                       exposure_on_bins)

        # fit background
        background_fitter = PolynomialFitter(bg_range_counts, bg_t_pre, bg_t_post, bg_range_exposures)
        background_fitter.fit_method = fit_method
        _, _ = background_fitter.fit(fit_order)
        channel_test_statistic = background_fitter.test_statistic
        channel_dof = background_fitter.dof
        # get the background of light curve
        channel_bg_counts, channel_bg_counts_err = background_fitter.interpolate(time_bins[:-1], time_bins[1:],
                                                                                 exposure=None)

        # ensemble ChannelBackgroundLightCurve
        channel_bg_lc_list = []
        for c_index in range(len(self.channel_lc_list)):
            c_lc_obj = self.channel_lc_list[c_index]
            c_bg_counts, c_bg_counts_err = channel_bg_counts[c_index], channel_bg_counts_err[c_index]
            c_test_statistic, c_dof = channel_test_statistic[c_index], channel_dof[c_index]

            c_fit_info = [fit_method, fit_order, c_test_statistic, c_dof, c_test_statistic / c_dof]

            c_bg_lc_obj = ChannelBackgroundLightCurve(time_bins, c_bg_counts, c_bg_counts_err, dead_time_on_bins,
                                                      c_lc_obj.channel_range, c_lc_obj.energy_range, bg_time_range,
                                                      c_fit_info)
            c_lc_obj.channel_bg_lc = c_bg_lc_obj

            channel_bg_lc_list.append(c_bg_lc_obj)

        obj = BackgroundLightCurve(self.detector, self.time_bins, self.channel_bins, self.energy_bins,
                                   channel_bg_lc_list, bg_time_range, self.dead_time_on_bins, self.evt_info,
                                   background_fitter)

        return obj


class BackgroundLightCurve:

    def __init__(self, detector, time_bins, channel_bins, energy_bins, c_lc_obj_list,
                 bg_time_range, dead_time_on_bins, evt_info: EvtInfo, background_fitter):
        """

        Args:
            detector ():
            time_bins ():
            channel_bins ():
            energy_bins ():
            c_lc_obj_list (list of ChannelBackgroundLightCurve):
            bg_time_range (list of list):
            dead_time_on_bins (np.ndarray):
            evt_info (list):
            background_fitter ():
        """
        self.detector = copy.deepcopy(detector)

        self.bg_channel_lc_list = c_lc_obj_list

        self.time_range = [time_bins[0], time_bins[-1]]
        self.bg_time_range = bg_time_range

        self.time_bins, self.dead_time_on_bins = time_bins, dead_time_on_bins
        self.exposure_on_bins = np.diff(time_bins) - dead_time_on_bins

        self.evt_info = evt_info

        self.channel_bins, self.energy_bins = channel_bins, energy_bins

        self.background_fitter = background_fitter

        self._flag_correct_by_dead_time = True

    @property
    def flag_correct_by_dead_time(self):
        return self._flag_correct_by_dead_time

    def _check_channel_index(self, channel_index):
        channel_len = len(self.bg_channel_lc_list)

        if channel_index is None or channel_index < 0 or channel_index >= channel_len:
            raise ValueError(
                f"The input channel_index ({channel_index}) out of range (max channel index: {channel_len - 1}).")

    def show_fitting_quality(self, channel_range: list = None):
        """

        Args:
            channel_index ():

        Returns:

        """

        quality_list = []
        if channel_range is None:
            bg_lc_list = self.bg_channel_lc_list
        else:
            bg_lc_list = self.bg_channel_lc_list[channel_range[0]:channel_range[1]]

        for lc in bg_lc_list:
            lc_fit_info = lc.fit_info
            quality_list.append(lc_fit_info[-1])

        fig = LineFigure("Fitting quality\n close to 1 is good", xlabel="Binned channel", y_label="Reduced chi-square")
        fig.add_data(y=quality_list, marker='o')
        fig.add_line(1, direction="h", color="#499c54", linestyle='--')

        return quality_list, fig

    def get_channel_lc(self, channel_index=None):
        if channel_index is None:
            channel_lc_list = self.bg_channel_lc_list
        else:
            self._check_channel_index(channel_index)
            channel_lc_list = self.bg_channel_lc_list[channel_index]

        return channel_lc_list

    def get_plot_data(self, channel_index=None):
        """
        get the data for plot
        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:
            (np.array, np.array, np.array): times, counts(counts/s), counts(counts/s) error

        """

        time_bins, y_list, y_err_list = self.get_data(channel_index)

        result_y = np.sum(y_list, axis=0) / np.diff(time_bins)

        result_y_err = np.sqrt(np.square(y_err_list).sum(axis=0))

        return time_bins[:-1], result_y, result_y_err

    def get_data(self, channel_index=None):
        """

        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:

        """
        if channel_index is not None:
            channel_lc_list = [self.bg_channel_lc_list[channel_index]]
        else:
            channel_lc_list = self.bg_channel_lc_list

        y_list = []
        y_err_list = []

        for c_lc in channel_lc_list:
            y_list.append(c_lc.counts)
            y_err_list.append(c_lc.counts_err)

        return self.time_bins, np.array(y_list), np.array(y_err_list)


class NetLightCurve:

    def __init__(self, total_lc: LightCurve, bg_lc: BackgroundLightCurve):
        self.total_lc, self.bg_lc = total_lc, bg_lc

        total_lc_x, total_lc_y, total_lc_y_err = total_lc.get_data(correct_by_dead_time=True)
        _, bg_lc_y, bg_lc_y_err = bg_lc.get_data()

        self._flag_correct_by_dead_time = True

        net_lc_y = total_lc_y - bg_lc_y
        net_lc_y_err = np.sqrt(np.square(total_lc_y) + np.square(bg_lc_y_err))

        channel_total_lc_list = total_lc.channel_lc_list
        channel_bg_lc_list = bg_lc.bg_channel_lc_list

        self.net_channel_lc_list = []
        for index in range(len(net_lc_y)):
            net_channel_lc_y = net_lc_y[index]
            net_channel_lc_y_err = net_lc_y_err[index]

            net_channel_lc = ChannelNetLightCurve(total_lc_x, net_channel_lc_y, net_channel_lc_y_err,
                                                  channel_total_lc_list[index], channel_bg_lc_list[index])
            self.net_channel_lc_list.append(net_channel_lc)

    @property
    def flag_correct_by_dead_time(self):
        return self._flag_correct_by_dead_time

    def _check_channel_index(self, channel_index):
        channel_len = len(self.net_channel_lc_list)

        if channel_index is None or channel_index < 0 or channel_index >= channel_len:
            raise ValueError(
                f"The input channel_index ({channel_index}) out of range (max channel index: {channel_len - 1}).")

    def get_channel_lc(self, channel_index=None):
        if channel_index is None:
            channel_lc_list = self.net_channel_lc_list
        else:
            self._check_channel_index(channel_index)
            channel_lc_list = self.net_channel_lc_list[channel_index]

        return channel_lc_list

    def get_plot_data(self, channel_index=None):
        """
        get the data for plot
        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:
            (np.array, np.array, np.array): times, counts(counts/s), counts(counts/s) error

        """

        time_bins, y_list, y_err_list = self.get_data(channel_index)

        result_y = np.sum(y_list, axis=0) / np.diff(time_bins)

        result_y_err = np.sqrt(np.square(y_err_list).sum(axis=0))

        return time_bins[:-1], result_y, result_y_err

    def get_data(self, channel_index=None):
        """

        Args:
            channel_index (int, optional): type is int: channel index. default: choose all channel

        Returns:

        """
        if channel_index is not None:
            channel_lc_list = [self.net_channel_lc_list[channel_index]]
        else:
            channel_lc_list = self.net_channel_lc_list

        y_list = []
        y_err_list = []

        for c_lc in channel_lc_list:
            y_list.append(c_lc.counts)
            y_err_list.append(c_lc.counts_err)

        return channel_lc_list[0].time_bins, np.array(y_list), np.array(y_err_list)
