#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.plot.gecam_plot import GecamPlot

class LightCurveFigure(GecamPlot):

    def __init__(self, lc_data, trig_time=None, ref_time=None, satellite="GECAM-B", **kwargs):
        """

        Args:
            lc_data (tuple): (x,y,y_error)
            trig_time (float):trigger met
            ref_time (): reference met
            satellite (): GECAM-A, GECAM-B, GECAM-C, HXMT
            **kwargs (tuple):
        """
        super().__init__(satellite=satellite, **kwargs)

        self._selections = []
        self.step_type = "mid"
        self.legend = []

        self.lc_index = 1
        self._temp_y_lim = None
        self.trig_time = trig_time

        if ref_time is not None:
            self.ref_time = ref_time
            xlabel = f"Time (s) since reference time (T0={self._met_func(self.ref_time).iso}, {self.ref_time})"
        elif trig_time is not None:
            self.ref_time = trig_time
            xlabel = f"Time (s) since trigger time (T0={self._met_func(self.trig_time).iso}, {self.trig_time})"
        else:
            x, y, y_err = lc_data
            self.ref_time = x[0]
            xlabel = f"Time (s) since reference time (T0={self._met_func(self.ref_time).iso}, {self.ref_time})"

        self.add_data(lc_data, color="black")

        font_size = 10
        # self._ax.set_title(f"GECAM-{lc_obj.evt_info.satellite.upper()}", fontsize=12)
        self._ax.set_xlabel(xlabel, fontsize=font_size)
        self._ax.set_ylabel('Count Rate (count/s)', fontsize=font_size)
        self._ax.xaxis.set_tick_params(labelsize=font_size)
        self._ax.yaxis.set_tick_params(labelsize=font_size)
        self._ax.set_xscale('linear')
        self._ax.set_yscale('linear')

    def add_data(self, lc_data, show_error=True, err_color="#595959", **kwargs):
        kwargs.setdefault("label", f"lc-{self.lc_index}")

        x, y, y_err = lc_data

        self.lc_index += 1

        self._ax.step(x - self.ref_time, y, where=self.step_type, **kwargs)

        if y_err is not None and show_error:
            self._ax.errorbar(x - self.ref_time, y, yerr=y_err, ls='', color=err_color)

        self._temp_y_lim = self._ax.get_ylim()

    def add_background(self, bg_data=None, bg_time_range=None, show_error=True, err_color="#b15b2e", **kwargs):
        kwargs.setdefault("color", '#bb3e3e')
        kwargs.setdefault("linewidth", 2)

        if bg_data is not None:
            x, y, y_err = bg_data

            self._ax.plot(x - self.ref_time, y, **kwargs)

            if y_err is not None and show_error:
                self._ax.errorbar(x - self.ref_time, y, yerr=y_err, ls='', color=err_color, linewidth=2)

        if bg_time_range is not None:
            self.add_range_selection(bg_time_range)

    def add_selection(self, lc_data, **kwargs):
        kwargs.setdefault("facecolor", '#9a4e0e')
        kwargs.setdefault("alpha", 0.3)

        x, y, y_err = lc_data

        self._selections.append(lc_data)
        self._ax.fill_between(x - self.ref_time, self._temp_y_lim[0], y, step=self.step_type, **kwargs)

    def add_range_selection(self, range_list, **kwargs):
        kwargs.setdefault("facecolor", '#50beff')
        kwargs.setdefault("alpha", 0.2)

        y_lim = self._temp_y_lim
        for index, item_range in enumerate(range_list):
            ref_range = [item_range[0] - self.ref_time, item_range[1] - self.ref_time]

            self._ax.fill_between(ref_range, y_lim[0], y_lim[1], step=self.step_type, **kwargs)

    def show_legend(self):
        self._ax.legend()
