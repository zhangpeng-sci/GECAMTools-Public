# gecam_plot.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
from gecam.time import GecamMet, HxmtMet, HebsMet


class GecamPlot:

    def __init__(self, figsize=(8, 5), dpi=100, satellite="GECAM-B", **kwargs):

        self._figure = plt.figure(figsize=figsize, dpi=dpi)

        self._ax = self._figure.add_subplot(111, **kwargs)
        self._ax.grid(ls='--', c='#d7d7d7')

        self._format_coordinates()

        if satellite in ["GECAM-A", "GECAM-B"]:
            Met = GecamMet
        elif satellite == "GECAM-C":
            Met = HebsMet
        elif satellite == "HXMT":
            Met = HxmtMet
        else:
            Met = GecamMet

        self._met_func = Met

    def _format_coordinates(self):
        # Set the format of the coordinate readout
        self._ax.format_coord = lambda x, y: ""

        # Set the x minor tick frequency
        minorLocator = AutoMinorLocator()
        self._ax.xaxis.set_minor_locator(minorLocator)

        # Set the y minor tick frequency
        minorLocator = AutoMinorLocator()
        self._ax.yaxis.set_minor_locator(minorLocator)

    @property
    def fig(self):
        return self._figure

    @property
    def title(self):
        return self._ax.get_title()

    def set_title(self, val):
        self._ax.set_title(val)

    @property
    def ax(self):
        return self._ax

    @property
    def xscale(self):
        return self._ax.get_xscale()

    def set_xscale(self, val):
        if val not in ["linear", "log"]:
            raise ValueError("Scale must be either 'linear' or 'log'")
        self._ax.set_xscale(val)

    @property
    def xlim(self):
        return self._ax.get_xlim()

    def set_xlim(self, val: tuple):
        self._ax.set_xlim(val)

    @property
    def yscale(self):
        return self._ax.get_yscale()

    def set_yscale(self, val):
        if val not in ["linear", "log"]:
            raise ValueError("Scale must be either 'linear' or 'log'")
        self._ax.set_yscale(val)

    @property
    def ylim(self):
        return self._ax.get_ylim()

    def set_ylim(self, val):
        self._ax.set_ylim(val)

    @property
    def xlabel(self):
        return self._ax.get_xlabel()

    def set_xlabel(self, val):
        self._ax.set_xlabel(val)

    @property
    def ylabel(self):
        return self._ax.get_ylabel()

    def set_ylabel(self, val):
        self._ax.set_ylabel(val)

    def add_line(self, value, direction="h", **kwargs):
        """
        add a mark line
        Args:
            value (float):
            direction (str): h:horizon. v:vertical
            **kwargs (dict):

        Returns:

        """

        if direction == "h":
            self._ax.axhline(value, **kwargs)
        elif direction == "v":
            self._ax.axvline(value, **kwargs)

    def show_legend(self):
        self._ax.legend()

    def show(self):
        plt.show()

    def savefig(self, *args, **kwargs):
        """
        matplotlib.figure.Figure.savefig
        Save the current figure.

        Call signature::

          savefig(fname, dpi=None, facecolor='w', edgecolor='w',
                  orientation='portrait', papertype=None, format=None,
                  transparent=False, bbox_inches=None, pad_inches=0.1,
                  frameon=None, metadata=None)

        Args:
            **kwargs ():

        Returns:

        """
        self.fig.savefig(*args, **kwargs)
