# burst_duration: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#


from gecam.data.evt import Evt
from gecam.data.detector import Detector, GRD, CPD
from gecam.data.curve import NetLightCurve
from gecam.fitting.base_polynomial_fitter import BasePolynomialFitter
from gecam.plot.gecam_plot import GecamPlot
from gecam.time import GecamMet, HxmtMet, HebsMet

import numpy as np
import matplotlib.pyplot as plt
import copy


def _search_cross_index(line0, line1, choose_result_index=None, default=None):
    """

    Args:
        line0 ():
        line1 ():
        choose_result_index ():
        default (): 无交点的序号

    Returns:

    """
    cross_index_list = _search_index_of_cross_point(line0, line1)

    if cross_index_list is None:
        return default
    else:
        if choose_result_index is None:
            return cross_index_list[0]
        else:
            return cross_index_list[choose_result_index]


def _search_index_of_cross_point(line0, line1):
    sub_line_sign = np.sign(line0 - line1)
    equal_index_list = np.where(sub_line_sign == 0)[0]
    if len(equal_index_list) > 0:
        return equal_index_list

    start_index_list = np.where((sub_line_sign[1:] + sub_line_sign[:-1]) == 0)[0]
    if len(start_index_list) == 0:
        return None
    else:
        return start_index_list


def calc_duration(t: np.ndarray, counts: np.ndarray, net_counts: np.ndarray, net_uncert: np.ndarray, f: float,
                  bg_range: list):
    """
    时间中点计数、净计数、净计数误差、百分数
    @author: Wangchen Xue
    Args:
        t (np.ndarray):
        counts ()np.ndarray:
        net_counts (np.ndarray):
        net_uncert (np.ndarray):
        f (float):
        bg_range (list):

    Returns:

    """
    prev_interval, post_interval = bg_range
    prev_mask = (prev_interval[0] <= t) & (t <= prev_interval[1])  # 0%流量区间
    post_mask = (post_interval[0] <= t) & (t <= post_interval[1])  # 100%流量区间

    cumsum_net = np.cumsum(net_counts)
    cumsum_prev = cumsum_net[prev_mask]
    cumsum_post = cumsum_net[post_mask]

    cumsum_err = np.sqrt(np.cumsum(np.square(net_uncert)))
    prev_err = cumsum_err[prev_mask]
    post_err = cumsum_err[post_mask]

    # 0%流量的估计值和误差
    Lz, Lz_var = wleastsq(np.ones_like(cumsum_prev), cumsum_prev, 1.0 / prev_err)
    Lz_err = np.sqrt(Lz_var[0, 0])
    # 100%流量的估计值和误差
    Lt, Lt_var = wleastsq(np.ones_like(cumsum_post), cumsum_post, 1.0 / post_err)
    Lt_err = np.sqrt(Lt_var[0, 0])

    # >>> 0%流量 >>>
    mask_left = np.flatnonzero((prev_interval[0] < t) & (t < post_interval[0]))
    cumsum_src_left = cumsum_net[mask_left]
    t_left = t[mask_left]
    # 0%流量处idx
    src_start_index = _search_cross_index(cumsum_src_left,
                                          np.full(cumsum_src_left.size, Lz),
                                          choose_result_index=-1,
                                          default=0)
    # <<< 0%流量 <<<

    # 初始化
    f1 = (1.0 - f) / 2.0  # 0.05
    f2 = 1.0 - (1.0 - f) / 2.0  # 0.95

    # >>> 5%流量 >>>
    mask_left = np.flatnonzero((prev_interval[0] < t) & (t < post_interval[0]))
    cumsum_src_left = cumsum_net[mask_left]
    t_left = t[mask_left]

    # 找出5%流量处idx
    L1 = Lz + f1 * (Lt - Lz)  # L5
    idx1 = _search_cross_index(cumsum_src_left,
                               np.full(cumsum_src_left.size, L1),
                               choose_result_index=-1,
                               default=0)

    # 5%流量处时间点
    tau1 = t_left[idx1]

    # >>> 5%流量处的时间点误差 >>>
    # 5%流量处累计总计数T
    T1 = np.sum(counts[src_start_index: idx1 + 1])
    # 5%流量处累计净计数误差S_err
    S1_err = np.sqrt(T1 + (f2 * Lz_err) ** 2.0 + (f1 * Lt_err) ** 2.0)

    # 5%流量 -1sigma误差处时间点
    idx1_left = _search_cross_index(cumsum_src_left,
                                    np.full(cumsum_src_left.size, L1 - S1_err),
                                    choose_result_index=-1,
                                    default=0)
    tau1_left = t_left[idx1_left]

    # 5%流量 +1sigma误差处时间点
    idx1_right = _search_cross_index(cumsum_src_left,
                                     np.full(cumsum_src_left.size, L1 + S1_err),
                                     choose_result_index=0,
                                     default=-1)
    tau1_right = t_left[idx1_right]

    # 5%流量处时间点的1sigma误差
    tau1_err = tau1_right - tau1_left

    # <<< 5%流量 <<<

    # >>> 95%流量 >>>
    mask_right = np.flatnonzero((prev_interval[1] < t) & (t < post_interval[1]))
    cumsum_src_right = cumsum_net[mask_right]
    t_right = t[mask_right]

    # 找出95%流量处idx
    L2 = Lz + f2 * (Lt - Lz)  # L95
    idx2 = _search_cross_index(cumsum_src_right,
                               np.full(cumsum_src_right.size, L2),
                               choose_result_index=0,
                               default=-1)

    # 95%流量处时间点
    tau2 = t_right[idx2]

    # >>> 95%流量处的时间点误差 >>>
    # 95%流量处累计总计数T
    T2 = np.sum(counts[src_start_index: idx2 + 1])
    # 95%流量处累计净计数误差S_err
    S2_err = np.sqrt(T2 + (f1 * Lz_err) ** 2.0 + (f2 * Lt_err) ** 2.0)

    # 95%流量 -1sigma误差处时间点
    idx2_left = _search_cross_index(cumsum_src_right,
                                    np.full(cumsum_src_right.size, L2 - S2_err),
                                    choose_result_index=-1,
                                    default=0)
    tau2_left = t_right[idx2_left]

    # 95%流量 +1sigma误差处时间点
    idx2_right = _search_cross_index(cumsum_src_right,
                                     np.full(cumsum_src_right.size, L2 + S2_err),
                                     choose_result_index=0,
                                     default=-1)
    tau2_right = t_right[idx2_right]

    # 95%流量处时间点的1sigma误差
    tau2_err = tau2_right - tau2_left

    # <<< 95%流量 <<<

    # T90及误差
    tau_f = tau2 - tau1
    tau_err = np.sqrt(tau1_err * tau1_err + tau2_err * tau2_err)

    return tau_f, tau_err, (tau1, tau2), (mask_left[0] + idx1, mask_right[0] + idx2), (Lz, Lt)


def wleastsq(X, y, w, return_cov=True):
    """
    Return the least-squares solution to a linear matrix equation, which
    minimizes the weighted Euclidean 2-norm :math:`||W^{1/2} (y - bX)||`.
    This function is adapted from `numpy` polynomial fitter.

    Parameters
    ----------
    X : (M, N) array_like
        "Coefficient" matrix.
    y : (M,) array_like
        Ordinate or "dependent variable" values.
    w : (M,) array_like
        Weights to apply to the y-coordinates of the sample points. For
        gaussian uncertainties, use 1/sigma (not 1/sigma**2).
    return_cov : bool, optional
        Whether to return covariance. The default is True.

    Returns
    -------
    b : (N,) ndarray
        Weighted least-squares solution.
    cov : (N, N) ndarray
        The covariance matrix of the parameter estimates. The diagonal of
        this matrix are the variance estimates for each parameter.

    Warns
    -----
    RankWarning
        The rank of the coefficient matrix in the least-squares fit is
        deficient.

    """
    if len(X.shape) == 1:
        X = np.ascontiguousarray(np.atleast_2d(X).T)

    order = X.shape[1]

    # return if all values of y are zeros
    if all(y == 0):
        b = np.full(order, 0.0)
        if return_cov:
            cov = np.full((order, order), 0.0)
            return b, cov
        else:
            return b

    # set up least squares equation with weight
    WX = w[:, None] * X
    Wy = w * y

    # scale WX to improve condition number and solve
    scale = np.sqrt(np.square(WX).sum(axis=0))
    scale[scale == 0] = 1
    b, resids, rank, s = np.linalg.lstsq(WX / scale, Wy, rcond=None)
    b = b / scale

    if return_cov:
        # scale the covariance matrix, to reduce the potential bias of
        # weights
        fac = resids / (X.shape[0] - order)
        scaled_cov = fac * np.linalg.inv(WX.T @ WX)
        return b, scaled_cov
    else:
        return b


class BurstDuration():

    def __init__(self):
        self.evt_info = None

        self.total_lc_1D_data = None, None, None
        self.bg_lc_1D_data = None, None, None
        self.net_lc_1D_data = None, None, None

        self.cumsum_lc_data = None, None, None

        self.cumsum_lc_x_bg1, self.cumsum_lc_y_bg1, self.cumsum_lc_y_err_bg1 = None, None, None
        self.cumsum_lc_x_bg2, self.cumsum_lc_y_bg2, self.cumsum_lc_y_err_bg2 = None, None, None

        self.cumsum_lc_x_T100, self.cumsum_lc_y_T100, self.cumsum_lc_y_err_T100 = None, None, None
        self.cumsum_lc_x_T90, self.cumsum_lc_y_T90, self.cumsum_lc_y_err_T90 = None, None, None
        self.cumsum_lc_x_T50, self.cumsum_lc_y_T50, self.cumsum_lc_y_err_T50 = None, None, None

        self._T100_start, self._T100, self._T100_err = None, None, None
        self._T90_start, self._T90, self._T90_err = None, None, None
        self._T50_start, self._T50, self._T50_err = None, None, None

    @property
    def T100(self):
        return self._T100_start, self._T100, self._T100_err

    @property
    def T90(self):
        return self._T90_start, self._T90, self._T90_err

    @property
    def T50(self):
        return self._T50_start, self._T50, self._T50_err

    def _get_range_index(self, x, x_range):
        start_index = np.where(x <= x_range[0])[0][-1]
        stop_index = np.where(x >= x_range[1])[0][0]
        if stop_index - start_index <= 0:
            stop_index = start_index + 1

        return start_index, stop_index

    def _trunc_bg(self, x, y, bg_range):
        """
        truncate background range x and y
        Args:
            x ():
            y ():
            bg_range ():

        Returns:

        """

        bg0_index_start, bg0_index_stop = self._get_range_index(x, bg_range)

        bg0_x = x[bg0_index_start:bg0_index_stop]
        y_on_bg0 = y[bg0_index_start:bg0_index_stop]

        return bg0_x, y_on_bg0

    def _search_cross_index(self, line0, line1, choose_result_index=None, default=None):
        cross_index_list = self._search_index_of_cross_point(line0, line1)

        if cross_index_list is None:
            return default
        else:
            if choose_result_index is None:
                return cross_index_list[0]
            else:
                return cross_index_list[choose_result_index]

    def _search_index_of_cross_point(self, line0, line1):
        sub_line_sign = np.sign(line0 - line1)

        start_index_list = np.where((sub_line_sign[1:] + sub_line_sign[:-1]) == 0)[0]
        if len(start_index_list) == 0:
            return None
        else:
            return start_index_list

    def generate_total_light_curve_with_detectors(self, evt, detectors: Detector or list, slice_kwargs_dic=None,
                                                  lc_kwargs_dic: dict = None):
        """
        generate total light curve
        Args:
            evt ():
            detectors ():
            slice_kwargs_dic ():
            lc_kwargs_dic ():

        Returns:
            lc_dic (dict): { "det_name": det_light_curve object },
            total_lc_1D_data (tuple): dets_total_lc_x, dets_total_lc_1D_y, dets_total_lc_1D_y_err
            dets_exposure (np.ndarray): sum of exposures of each detectors

        """
        self.evt_info = evt.info

        dets, dets_lc_list, _ = evt.generate_light_curve_with_detectors(detectors, slice_kwargs_dic,
                                                                        lc_kwargs_dic,
                                                                        lc_bg_fit_kwargs_dic=None)

        lc_dic = {}
        dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = None, None, None
        dets_exposure = None
        for index, det_lc in enumerate(dets_lc_list):
            temp_det = dets[index]

            total_x, total_y, total_y_err = det_lc.get_data()
            if dets_total_lc_x is None:
                dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = total_x, total_y, np.square(total_y_err)
                dets_exposure = det_lc.exposure_on_bins
            else:
                dets_total_lc_y = dets_total_lc_y + total_y
                dets_total_lc_y_err = dets_total_lc_y_err + np.square(total_y_err)
                dets_exposure += det_lc.exposure_on_bins

            lc_dic[temp_det.full_name] = det_lc

        dets_total_lc_1D_y = np.sum(dets_total_lc_y, axis=0)
        dets_total_lc_1D_y_err = np.sqrt(np.sum(dets_total_lc_y_err, axis=0))

        self.total_lc_1D_data = dets_total_lc_x, dets_total_lc_1D_y, dets_total_lc_1D_y_err

        return lc_dic, self.total_lc_1D_data, dets_exposure

    def generate_net_light_curve_with_detectors(self, evt, detectors: Detector or list, slice_kwargs_dic=None,
                                                lc_kwargs_dic: dict = None, lc_bg_fit_kwargs_dic=None):
        """
        generate net light curve
        Args:
            evt ():
            detectors ():
            slice_kwargs_dic ():
            lc_kwargs_dic ():
            lc_bg_fit_kwargs_dic ():

        Returns:

        """
        self.evt_info = evt.info

        if lc_bg_fit_kwargs_dic is None or len(lc_bg_fit_kwargs_dic) == 0:
            raise Exception("The `lc_bg_fit_kwargs_dic` is used to fit background of light curve, it can not be None.")

        dets, dets_lc_list, dets_bg_lc_list = evt.generate_light_curve_with_detectors(detectors, slice_kwargs_dic,
                                                                                      lc_kwargs_dic,
                                                                                      lc_bg_fit_kwargs_dic)

        lc_dic = {}
        dets_net_lc_x, dets_net_lc_y, dets_net_lc_y_err = None, None, None
        dets_bg_lc_x, dets_bg_lc_y, dets_bg_lc_y_err = None, None, None
        dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = None, None, None
        for index, det_lc in enumerate(dets_lc_list):
            temp_det = dets[index]
            det_bg_lc = dets_bg_lc_list[index]

            det_net_lc = NetLightCurve(det_lc, det_bg_lc)

            net_x, net_y, net_y_err = det_net_lc.get_data()
            total_x, total_y, total_y_err = det_lc.get_data()
            bg_x, bg_y, bg_y_err = det_bg_lc.get_data()
            if dets_net_lc_x is None:
                dets_net_lc_x, dets_net_lc_y, dets_net_lc_y_err = net_x, net_y, np.square(net_y_err)
                dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = total_x, total_y, np.square(total_y_err)
                dets_bg_lc_x, dets_bg_lc_y, dets_bg_lc_y_err = bg_x, bg_y, np.square(bg_y_err)
            else:
                dets_net_lc_y = dets_net_lc_y + net_y
                dets_net_lc_y_err = dets_net_lc_y_err + np.square(net_y_err)

                dets_total_lc_y = dets_total_lc_y + total_y
                dets_total_lc_y_err = dets_total_lc_y_err + np.square(total_y_err)

                dets_bg_lc_y = dets_bg_lc_y + bg_y
                dets_bg_lc_y_err = dets_bg_lc_y_err + np.square(bg_y_err)

            lc_dic[temp_det.full_name] = det_net_lc

        dets_total_lc_1D_y = np.sum(dets_total_lc_y, axis=0)
        dets_total_lc_1D_y_err = np.sqrt(np.sum(dets_total_lc_y_err, axis=0))

        dets_bg_lc_1D_y = np.sum(dets_bg_lc_y, axis=0)
        dets_bg_lc_1D_y_err = np.sqrt(np.sum(dets_bg_lc_y_err, axis=0))

        dets_net_lc_1D_y = np.sum(dets_net_lc_y, axis=0)
        # TOD:所有探头总净计数误差等于sqrt(所有探头总计数+各探头本底拟合误差的平方和)
        # fix: 2023年6月9日17:10:51
        dets_net_lc_1D_y_err = np.sqrt(np.sum(dets_total_lc_y, axis=0) +
                                       np.sum(dets_bg_lc_y_err, axis=0))

        dets_net_lc_y_cumsum = np.cumsum(np.sum(dets_net_lc_y, axis=0))
        dets_net_lc_y_cumsum_err = np.sqrt(np.cumsum(dets_net_lc_1D_y + np.square(dets_net_lc_1D_y_err)))

        self.total_lc_1D_data = dets_net_lc_x, dets_total_lc_1D_y, dets_total_lc_1D_y_err
        self.bg_lc_1D_data = dets_net_lc_x, dets_bg_lc_1D_y, dets_bg_lc_1D_y_err
        self.net_lc_1D_data = dets_net_lc_x, dets_net_lc_1D_y, dets_net_lc_1D_y_err

        self.cumsum_lc_data = dets_net_lc_x, dets_net_lc_y_cumsum, dets_net_lc_y_cumsum_err

        return lc_dic, self.cumsum_lc_data

    def cal_net_light_curve_cumsum(self, evt, det_list: list, lc_time_bin, lc_channel_bin, lc_bg_range: list,
                                   bg_fit_method="2pass", bg_fit_order=1, only_recommend=True, lc_channel_range=None,
                                   lc_time_range=None):
        """
        extract cumulative sum of net light curve
        Args:
            evt ():
            det_list ():
            lc_time_bin ():
            lc_channel_bin ():
            lc_channel_range ():
            lc_bg_range ():
            bg_fit_method ():
            bg_fit_order ():
            only_recommend ():

        Returns:

        """
        self.evt_info = evt.info

        lc_dic = {}

        dets_net_lc_x, dets_net_lc_y, dets_net_lc_y_err = None, None, None
        dets_bg_lc_x, dets_bg_lc_y, dets_bg_lc_y_err = None, None, None
        dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = None, None, None
        for det in det_list:
            if det.gain_type in det.unique_gain_type_list():
                gain_type_list = [det.gain_type]
            else:
                gain_type_list = det.unique_gain_type_list()
            if len(gain_type_list) == 0:
                gain_type_list = [None]
            # Calculate the high and low gains separately
            for gain_type in gain_type_list:
                temp_det = copy.deepcopy(det)
                temp_det.set_gain_type(gain_type)
                temp_det.set_satellite(self.evt_info.satellite)
                print(temp_det.full_name)

                det_events_all = evt.select_detector(det.number)

                det_events = det_events_all.slice(gain_type=temp_det.gain_type, only_recommend=only_recommend,
                                                  channel_range=lc_channel_range)
                det_lc = det_events.to_light_curve(time_bin=lc_time_bin, channel_bin=lc_channel_bin,
                                                   time_range=lc_time_range)
                det_bg_lc = det_lc.fit_background(lc_bg_range, bg_fit_method, bg_fit_order)

                det_net_lc = NetLightCurve(det_lc, det_bg_lc)

                total_x, total_y, total_y_err = det_lc.get_data()
                bg_x, bg_y, bg_y_err = det_bg_lc.get_data()
                net_x, net_y, net_y_err = det_net_lc.get_data()
                if dets_net_lc_x is None:
                    dets_total_lc_x, dets_total_lc_y, dets_total_lc_y_err = total_x, total_y, np.square(total_y_err)
                    dets_bg_lc_x, dets_bg_lc_y, dets_bg_lc_y_err = bg_x, bg_y, np.square(bg_y_err)
                    dets_net_lc_x, dets_net_lc_y, dets_net_lc_y_err = net_x, net_y, np.square(net_y_err)

                else:
                    dets_total_lc_y = dets_total_lc_y + total_y
                    dets_total_lc_y_err = dets_total_lc_y_err + np.square(total_y_err)

                    dets_bg_lc_y = dets_bg_lc_y + bg_y
                    dets_bg_lc_y_err = dets_bg_lc_y_err + np.square(bg_y_err)

                    dets_net_lc_y = dets_net_lc_y + net_y
                    dets_net_lc_y_err = dets_net_lc_y_err + np.square(net_y_err)

                lc_dic[temp_det.full_name] = det_net_lc

        # np.sqrt( np.square(det0_net_err) +np.square(det1_net_err)+..+)
        # dets_net_lc_y_err = np.sqrt(dets_net_lc_y_err)
        # dets_total_lc_y_err = np.sqrt(dets_total_lc_y_err)

        dets_total_lc_1D_y = np.sum(dets_total_lc_y, axis=0)
        dets_total_lc_1D_y_err = np.sqrt(np.sum(np.square(dets_total_lc_y_err), axis=0))

        dets_bg_lc_1D_y = np.sum(dets_bg_lc_y, axis=0)
        dets_bg_lc_1D_y_err = np.sqrt(np.sum(np.square(dets_bg_lc_y_err), axis=0))

        dets_net_lc_1D_y = np.sum(dets_net_lc_y, axis=0)
        # TOD:所有探头总净计数误差等于sqrt(所有探头总计数+各探头本底拟合误差的平方和)
        # fix: 2023年3月9日14:54:13
        dets_net_lc_1D_y_err = np.sqrt(np.sum(dets_total_lc_y, axis=0) +
                                       np.sum(dets_net_lc_y_err * dets_net_lc_y_err, axis=0))

        dets_net_lc_y_cumsum = np.cumsum(np.sum(dets_net_lc_y, axis=0))
        dets_net_lc_y_cumsum_err = np.sqrt(np.cumsum(dets_net_lc_1D_y + np.square(dets_net_lc_1D_y_err)))

        self.cumsum_lc_data = dets_net_lc_x, dets_net_lc_y_cumsum, dets_net_lc_y_cumsum_err
        self.total_lc_1D_data = dets_net_lc_x, dets_total_lc_1D_y, dets_total_lc_1D_y_err
        self.bg_lc_1D_data = dets_net_lc_x, dets_bg_lc_1D_y, dets_bg_lc_1D_y_err
        self.net_lc_1D_data = dets_net_lc_x, dets_net_lc_1D_y, dets_net_lc_1D_y_err

        return lc_dic, self.cumsum_lc_data

    def update_custom_data(self, total_lc_data: list, net_lc_data: list, cumsum_lc_data=None):
        """
        use the custom data to calculate burst duration
        Args:
            total_lc_data (list): total light curve (time bins, counts(one dimension), counts err)
            net_lc_data (list): net light curve (time bins, counts(one dimension), counts err)
            cumsum_lc_data (list, optimal):cumsum net light curve, (time bins, counts(one dimension), counts err)

        Returns:
            cumsum_lc_data (list): (time bins, counts(one dimension), counts err)

        """
        if cumsum_lc_data is None:
            net_lc_x = net_lc_data[0]
            net_lc_y_cumsum = np.cumsum(net_lc_data[1])
            net_lc_y_cumsum_err = np.sqrt(np.cumsum(net_lc_data[1] + np.square(net_lc_data[2])))
            cumsum_lc_data = (net_lc_x, net_lc_y_cumsum, net_lc_y_cumsum_err)

        self.cumsum_lc_data = cumsum_lc_data
        self.net_lc_1D_data = net_lc_data
        self.total_lc_1D_data = total_lc_data

        return cumsum_lc_data

    # def cal_burst_duration_by_total_light_curve(self, total_lc_data: list, src_range, bg_range, bg_fit_order):
    #     """
    #     calculate burst duration by counts
    #
    #     Args:
    #
    #     Returns:
    #
    #     """
    #
    #     cumsum_lc_x, cumsum_lc_y, cumsum_lc_y_err = self.cumsum_lc_data
    #     if cumsum_lc_x is None:
    #         raise Exception("Please calculate the light curve cumsum data first")
    #
    #     self.cumsum_lc_bg_range = bg_range
    #
    #     # calculte center of time bins
    #     cumsum_lc_x_center = cumsum_lc_x[:-1] + np.diff(cumsum_lc_x) / 2
    #
    #     temp_result = calc_duration(cumsum_lc_x_center,
    #                                 self.total_lc_1D_data[1],
    #                                 self.net_lc_1D_data[1],
    #                                 self.net_lc_1D_data[2],
    #                                 1, bg_range)
    #
    #     # 时间中点计数、净计数、净计数误差、百分数、零流量区间、全流量区间
    #     t90, t90_err, t90_met_range, t90_index_range, cumsum_t100_range = calc_duration(cumsum_lc_x_center,
    #                                                                                     self.total_lc_1D_data[1],
    #                                                                                     self.net_lc_1D_data[1],
    #                                                                                     self.net_lc_1D_data[2],
    #                                                                                     0.9, bg_range)
    #
    #     t50, t50_err, t50_met_range, t50_index_range, cumsum_t100_range2 = calc_duration(cumsum_lc_x_center,
    #                                                                                      self.total_lc_1D_data[1],
    #                                                                                      self.net_lc_1D_data[1],
    #                                                                                      self.net_lc_1D_data[2],
    #                                                                                      0.5, bg_range)
    #
    #     self._T90_start, self._T90, self._T90_err = t90_met_range[0], t90, t90_err
    #     self._T50_start, self._T50, self._T50_err = t50_met_range[0], t50, t50_err
    #     self._T90_met_range, self._T90_index_range = t90_met_range, t90_index_range
    #     self._T50_met_range, self._T50_index_range = t50_met_range, t50_index_range
    #     self._cumsum_T100_range = cumsum_t100_range
    #
    #     return t90, t90_err, t50, t50_err

    def cal_burst_duration_by_cumsum_counts(self, bg_range: list):
        """
        cal_burst_duration_by_cumsum_counts
        Args:
            bg_range (tuple or list):

        Returns:

        """

        cumsum_lc_x, cumsum_lc_y, cumsum_lc_y_err = self.cumsum_lc_data
        if cumsum_lc_x is None:
            raise Exception("Please calculate the light curve cumsum data first")

        self.cumsum_lc_bg_range = bg_range

        # calculte center of time bins
        cumsum_lc_x_center = cumsum_lc_x[:-1] + np.diff(cumsum_lc_x) / 2

        t100, t100_err, t100_met_range, t100_index_range, _ = calc_duration(cumsum_lc_x_center,
                                                                            self.total_lc_1D_data[1],
                                                                            self.net_lc_1D_data[1],
                                                                            self.net_lc_1D_data[2],
                                                                            1, bg_range)

        # 时间中点计数、净计数、净计数误差、百分数、零流量区间、全流量区间
        t90, t90_err, t90_met_range, t90_index_range, cumsum_t100_range = calc_duration(cumsum_lc_x_center,
                                                                                        self.total_lc_1D_data[1],
                                                                                        self.net_lc_1D_data[1],
                                                                                        self.net_lc_1D_data[2],
                                                                                        0.9, bg_range)

        t50, t50_err, t50_met_range, t50_index_range, _ = calc_duration(cumsum_lc_x_center,
                                                                        self.total_lc_1D_data[1],
                                                                        self.net_lc_1D_data[1],
                                                                        self.net_lc_1D_data[2],
                                                                        0.5, bg_range)

        self._T100_start, self._T100, self._T100_err = t100_met_range[0], t100, t100_err
        self._T90_start, self._T90, self._T90_err = t90_met_range[0], t90, t90_err
        self._T50_start, self._T50, self._T50_err = t50_met_range[0], t50, t50_err
        self._T90_met_range, self._T90_index_range = t90_met_range, t90_index_range
        self._T50_met_range, self._T50_index_range = t50_met_range, t50_index_range
        self._cumsum_T100_range = cumsum_t100_range

        return t90, t90_err, t50, t50_err

    @property
    def T100(self):
        return self._T100_start, self._T100, self._T100_err

    @property
    def T90(self):
        return self._T90_start, self._T90, self._T90_err

    @property
    def T50(self):
        return self._T50_start, self._T50, self._T50_err

    def plot_light_curve_cumsum(self, ref_time: float = None, set_time_range: tuple = None):
        cumsum_lc_x, cumsum_lc_y, cumsum_lc_y_err = self.cumsum_lc_data
        cumsum_lc_x = cumsum_lc_x[:-1]

        if set_time_range is not None:
            time_filter = np.where((cumsum_lc_x >= set_time_range[0]) & (cumsum_lc_x <= set_time_range[1]))[0]
            cumsum_lc_x_trunc, cumsum_lc_y_trunc, cumsum_lc_y_err_trunc = cumsum_lc_x[time_filter], \
                cumsum_lc_y[time_filter], \
                cumsum_lc_y_err[time_filter]

            y_interval = cumsum_lc_y_trunc[0]
            cumsum_lc_y_trunc = cumsum_lc_y_trunc - y_interval

            x_lim = set_time_range
        else:
            cumsum_lc_x_trunc, cumsum_lc_y_trunc, cumsum_lc_y_err_trunc = cumsum_lc_x, cumsum_lc_y, cumsum_lc_y_err
            x_lim = None
            y_interval = 0

        if self.evt_info is None:
            trig_time = None
            satellite_name = None
        else:
            trig_time = self.evt_info.trig_met
            satellite_name = self.evt_info.satellite_full_name

        fig = LightCurveCumsumFigure((cumsum_lc_x_trunc, cumsum_lc_y_trunc, cumsum_lc_y_err_trunc),
                                     trig_time=trig_time, ref_time=ref_time,
                                     satellite=satellite_name)

        if x_lim is not None:
            fig.set_xlim([x_lim[0] - fig.ref_time, x_lim[1] - fig.ref_time])

        if self._T90_start is not None:
            cumsum_T100_range = self._cumsum_T100_range

            t90_start_index, t90_stop_index = self._T90_index_range[0], self._T90_index_range[1]
            t50_start_index, t50_stop_index = self._T50_index_range[0], self._T50_index_range[1]

            fig.add_T100(cumsum_T100_range[0] - y_interval, cumsum_T100_range[1] - y_interval)
            fig.add_T90(cumsum_lc_x[t90_start_index], cumsum_lc_x[t90_stop_index],
                        cumsum_lc_y[t90_start_index] - y_interval,
                        cumsum_lc_y[t90_stop_index] - y_interval, self._T90, self._T90_err)
            fig.add_T50(cumsum_lc_x[t50_start_index], cumsum_lc_x[t50_stop_index],
                        cumsum_lc_y[t50_start_index] - y_interval,
                        cumsum_lc_y[t50_stop_index] - y_interval, self._T50, self._T50_err)

            fig.add_range_selection(self.cumsum_lc_bg_range)
            fig.show_legend()

        return fig

    def plot_light_curve_cumsum2(self, ref_time=None, show_bg=False):
        fig = LightCurveCumsumFigure((self.cumsum_lc_x[:-1], self.cumsum_lc_y, self.cumsum_lc_y_err),
                                     trig_time=self.evt_info.trig_met, ref_time=ref_time)

        if show_bg:
            fig.add_range_selection(self.cumsum_lc_bg_range)

        if self.cumsum_lc_y_T100 is not None:
            fig.add_T100(self.cumsum_lc_x_T100[0], self.cumsum_lc_x_T100[-1], self.cumsum_lc_y_T100[0],
                         self.cumsum_lc_y_T100[-1], self._T100, self._T100_err)
            fig.add_T90(self.cumsum_lc_x_T90[0], self.cumsum_lc_x_T90[-1], self.cumsum_lc_y_T90[0],
                        self.cumsum_lc_y_T90[-1], self._T90, self._T90_err)
            fig.add_T50(self.cumsum_lc_x_T50[0], self.cumsum_lc_x_T50[-1], self.cumsum_lc_y_T50[0],
                        self.cumsum_lc_y_T50[-1], self._T50, self._T50_err)
            fig.show_legend()

        return fig


class LightCurveCumsumFigure(GecamPlot):

    def __init__(self, lc_data, trig_time=None, ref_time=None, satellite="GECAM-B", **kwargs):
        super().__init__(satellite=satellite, **kwargs)

        self._selections = []
        self.step_type = "mid"
        self.legend = []

        self.lc_index = 1
        self._temp_y_lim = None
        self.trig_time = trig_time

        if ref_time is not None:
            self.ref_time = ref_time
            xlabel = f"Time (s) since reference time (T0={self._met_func(self.ref_time).iso}, {self.ref_time})"
        elif trig_time is not None:
            self.ref_time = trig_time
            xlabel = f"Time (s) since trigger time (T0={self._met_func(self.trig_time).iso}, {self.trig_time})"
        else:
            x, y, y_err = lc_data
            self.ref_time = x[0]
            xlabel = f"Time (s) since reference time (T0={self._met_func(self.ref_time).iso}, {self.ref_time})"

        self.add_data(lc_data, color="black")

        font_size = 10
        # self._ax.set_title(f"GECAM-{lc_obj.evt_info.satellite.upper()}", fontsize=12)
        self._ax.set_xlabel(xlabel, fontsize=font_size)
        self._ax.set_ylabel('Cumulative counts', fontsize=font_size)
        self._ax.xaxis.set_tick_params(labelsize=font_size)
        self._ax.yaxis.set_tick_params(labelsize=font_size)
        self._ax.set_xscale('linear')
        self._ax.set_yscale('linear')

    def add_data(self, lc_data, **kwargs):
        # kwargs.setdefault("label", f"lc-{self.lc_index}")

        x, y, y_err = lc_data

        self.lc_index += 1

        self._ax.step(x - self.ref_time, y, where=self.step_type, **kwargs)

        self._temp_y_lim = self._ax.get_ylim()
        self._temp_x_lim = self._ax.get_xlim()

    def add_T100(self, y_bottom, y_top):
        self._ax.axhline(y_bottom, xmin=0, xmax=1, color="green", linestyle='dotted')
        self._ax.axhline(y_top, xmin=0, xmax=1, color="green", linestyle='dotted')

        # self._ax.vlines(x_start - self.ref_time, ymin=self._temp_y_lim[0], ymax=y_bottom, color="green",
        #                 linestyle='dotted')
        # self._ax.vlines(x_stop - self.ref_time, ymin=self._temp_y_lim[0], ymax=y_top, color="green", linestyle='dotted')

        self._T100_y_bottom = y_bottom
        self._T100_y_top = y_top

    def add_T90(self, x_start, x_stop, y_bottom, y_top, T90, T90_err):
        if x_start is not None:
            self._ax.vlines(x_start - self.ref_time, ymin=self._T100_y_bottom, ymax=y_bottom, color="red",
                            linestyle='--',
                            label="$T_{90}$=" + f"{round(T90, 3)}+/-{round(T90_err, 3)}")
        self._ax.hlines(y_bottom, xmin=self._temp_x_lim[0], xmax=x_start - self.ref_time,
                        color="red", linestyle='--')

        if x_stop is not None:
            self._ax.vlines(x_stop - self.ref_time, ymin=self._T100_y_bottom, ymax=y_top,
                            color="red", linestyle='--')
        self._ax.hlines(y_top, xmin=self._temp_x_lim[0], xmax=x_stop - self.ref_time,
                        color="red", linestyle='--')

    def add_T50(self, x_start, x_stop, y_bottom, y_top, T50, T50_err):
        self._ax.vlines(x_start - self.ref_time, ymin=self._T100_y_bottom, ymax=y_bottom,
                        color="blue", linestyle='--', label="$T_{50}$=" + f"{round(T50, 3)}+/-{round(T50_err, 3)}")
        self._ax.hlines(y_bottom, xmin=self._temp_x_lim[0], xmax=x_start - self.ref_time,
                        color="blue", linestyle='--')

        self._ax.vlines(x_stop - self.ref_time, ymin=self._T100_y_bottom, ymax=y_top,
                        color="blue", linestyle='--')
        self._ax.hlines(y_top, xmin=self._temp_x_lim[0], xmax=x_stop - self.ref_time,
                        color="blue", linestyle='--')

    def add_range_selection(self, range_list, **kwargs):
        kwargs.setdefault("facecolor", '#50beff')
        kwargs.setdefault("alpha", 0.2)

        y_lim = self._temp_y_lim
        for index, item_range in enumerate(range_list):
            ref_range = [item_range[0] - self.ref_time, item_range[1] - self.ref_time]

            self._ax.fill_between(ref_range, y_lim[0], y_lim[1], step=self.step_type, **kwargs)

    def show_legend(self):
        self._ax.legend(loc="center right")
