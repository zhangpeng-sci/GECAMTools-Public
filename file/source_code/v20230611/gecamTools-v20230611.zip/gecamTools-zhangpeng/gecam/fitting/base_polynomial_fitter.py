#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import warnings
import numpy as np
from numpy import polyfit, poly1d, polyval


class BasePolynomialFitter:
    """
    A one-dimensional polynomial class.
    """

    def __int__(self):
        pass

    def fit(self, x, y, y_err=None, fit_order=1):
        params, cov = polyfit(x, y, w=y_err, deg=fit_order, cov=True)
        # The "fitting error" is the square root of the variance of each parameter
        params_error = np.sqrt(np.diag(cov))
        fit_func = poly1d(params)

        self.fit_func, self.params, self.params_error = fit_func, params, params_error

    def interpolate(self, x):
        """
        Interpolate the fitted model over the given x.
        """
        y = self.fit_func(np.array(x))
        y_err = np.sqrt(y)

        return y, y_err


if __name__ == '__main__':
    a = BasePolynomialFitter()
    a.fit(x=[1, 2, 3], y=[1, 2, 3])

    print(a.interpolate([1, 2, 3]))
    print(a.interpolate([2, 3, 41]))
