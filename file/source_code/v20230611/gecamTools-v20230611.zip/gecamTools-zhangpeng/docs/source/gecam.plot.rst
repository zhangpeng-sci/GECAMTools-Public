gecam.plot package
==================

Submodules
----------

gecam.plot.light\_curve module
------------------------------

.. automodule:: gecam.plot.light_curve
   :members:
   :undoc-members:
   :show-inheritance:

gecam.plot.spec module
----------------------

.. automodule:: gecam.plot.spec
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gecam.plot
   :members:
   :undoc-members:
   :show-inheritance:
