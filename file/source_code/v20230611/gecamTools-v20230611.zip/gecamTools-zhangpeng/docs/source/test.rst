test package
============

Submodules
----------

test.BKG5 module
----------------

.. automodule:: test.BKG5
   :members:
   :undoc-members:
   :show-inheritance:

test.calcDeadTime2 module
-------------------------

.. automodule:: test.calcDeadTime2
   :members:
   :undoc-members:
   :show-inheritance:

test.dtime module
-----------------

.. automodule:: test.dtime
   :members:
   :undoc-members:
   :show-inheritance:

test.test2 module
-----------------

.. automodule:: test.test2
   :members:
   :undoc-members:
   :show-inheritance:

test.test3 module
-----------------

.. automodule:: test.test3
   :members:
   :undoc-members:
   :show-inheritance:

test.test\_detector module
--------------------------

.. automodule:: test.test_detector
   :members:
   :undoc-members:
   :show-inheritance:

test.test\_evt module
---------------------

.. automodule:: test.test_evt
   :members:
   :undoc-members:
   :show-inheritance:

test.test\_spec module
----------------------

.. automodule:: test.test_spec
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: test
   :members:
   :undoc-members:
   :show-inheritance:
