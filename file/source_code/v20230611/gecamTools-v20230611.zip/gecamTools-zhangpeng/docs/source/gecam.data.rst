gecam.data package
==================

Submodules
----------

gecam.data.detector module
--------------------------

.. automodule:: gecam.data.detector
   :members:
   :undoc-members:
   :show-inheritance:

gecam.data.evt module
---------------------

.. automodule:: gecam.data.evt
   :members:
   :undoc-members:
   :show-inheritance:

gecam.data.file module
----------------------

.. automodule:: gecam.data.file
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gecam.data
   :members:
   :undoc-members:
   :show-inheritance:
