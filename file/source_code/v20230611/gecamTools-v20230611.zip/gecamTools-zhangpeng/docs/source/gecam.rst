gecam package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   gecam.api
   gecam.data
   gecam.generate
   gecam.plot
   gecam.utils

Submodules
----------

gecam.config module
-------------------

.. automodule:: gecam.config
   :members:
   :undoc-members:
   :show-inheritance:

gecam.time module
-----------------

.. automodule:: gecam.time
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gecam
   :members:
   :undoc-members:
   :show-inheritance:
