# GECAMTools v0.0.2 使用说明

## 更新说明

### v0.0.2

一、 修改项： 
1. <font color=#008000>时间转换（新增）</font>
2. <font color=orange>生成能谱文件（修复本底拟合错误）</font>

***

二、 功能：  

1. 显示光变
2. 显示能谱
3. 生成能谱文件
4. 时间转换

### v0.0.1

初始版本，功能：

1. 显示光变
2. 显示能谱
3. 生成能谱文件

## 安装与卸载
1. 所需环境  
    1.1 windows、linux、mac  
    1.2 python版本>=3.6

2. 安装流程  
    2.1 下载源程序  
    gecamTools-master.zip  
    
    2.2 安装  
    将会自动安装GECAMTools以及相关依赖库  
    `pip install gecamTools-master.zip`
    
    2.3 测试  
    `import gecam`

3. 卸载流程  
    `pip uninstall GECAMTools`

## 获取示例所用的测试数据

测试数据（gbg_evt_tn210511_112749_fb_v00.fits）的下载链接： [点击下载](https://ihepbox.ihep.ac.cn/ihepbox/index.php/s/iEE9AZQyNuJljr0)   

测试数据是通过IHEP BOX分享的，使用高能所账号登录即可

## 读取事例数据（daily或trigger）


```python
from gecam.data.evt import EVT
from gecam.data.detector import GRD, CPD
import numpy as np
import matplotlib.pyplot as plt
```


```python
fits_path = r"gbg_evt_tn210511_112749_fb_v00.fits"

evt=EVT(fits_path)
```

    File name: gbg_evt_tn210511_112749_fb_v00.fits
    Telescope: GECAM-B
    Instrument: GRD
    Observation met: (74431501.0, 74431899.0)
    Trigger id: tn210511_112749_fb
    Trigger met: 74431600.6; utc: 2021-05-11T11:26:40.600
    Location(J2000): RA:317.99; DEC: 59.53


## 时间转换


```python
from gecam.time import GecamMet
```


```python
evt.trig_met
```




    74431600.6




```python
# met转时间字符串
trig_time_str=GecamMet(evt.trig_met).iso
# met转datetime
trig_datetime=GecamMet(evt.trig_met).datetime
# met转MJD
trig_mjd=GecamMet(evt.trig_met).mjd

trig_time_str,trig_datetime,trig_mjd
```




    ('2021-05-11T11:26:40',
     datetime.datetime(2021, 5, 11, 11, 26, 40, 600000, tzinfo=datetime.timezone.utc),
     59345.4768587963)




```python
# 时间字符串转met
met1=GecamMet.from_iso(trig_time_str)
# datetime转met
met2=GecamMet.from_datetime(trig_datetime)
# MJD转met
met3=GecamMet.from_mjd(trig_mjd)

met1,met2,met3
```




    (<GecamMet seconds = 74431600.600000>,
     <GecamMet seconds = 74431600.600000>,
     <GecamMet seconds = 74431600.600000>)



## 批量选取探头


```python
# 示例：选取所有探头，所有增益
choose_det=[GRD(i,None) for i in range(1,26)]
```


```python
# 示例：选取10个高增益，15个低增益
choose_det=[]

choose_det.extend([GRD(i,"high") for i in range(1,11)])

choose_det.extend([GRD(i,"low") for i in range(11,26)])
```

## 输出光变


```python
# 光变的时间bin
evt.lc_time_bin = 0.1
# 光变的时间范围
evt.time_range = (evt.trig_met - 40, evt.trig_met + 50)

# 选择多个探头 GRD(18, "high") 标识GRD18高增益，GRD(20, None)全增益（过滤重复事例）
choose_det=[GRD(1, "high"),GRD(19, "low"),GRD(20, "all")]

# 生成多个探头叠加的光变(lc_data_dic中包含光变的数据)
lc_data_dic=evt.light_curve(choose_det)
```


![png](images/output_21_0.png)


## 输出能谱


```python
# 能谱的时间范围
evt.time_range = (evt.trig_met - 10, evt.trig_met + 20)
# 能谱的能道范围
evt.channel_range = [50, 180]
# 能谱的能道合并（整数），均匀并道
evt.spec_channel_bin=1
choose_det=[
    GRD(18, "high"),GRD(19, "low"),
]

# 生成多个探头的叠加能谱(spec_data_dic中包含能谱的数据)
spec_data_dic=evt.spectrum(choose_det)
```


![png](images/output_23_0.png)


## 生成能谱文件


```python
# 感兴趣的时间范围
source_time_range = (evt.trig_met - 1, evt.trig_met + 9)
# 高增益能道分bin（整数），示例：4：表示均匀的每4道进行合并
channel_range_list_low = 4
# 低增益能道分bin（整数），示例：4：表示均匀的每4道进行合并
channel_range_list_high = 4
# 本底时间段（绝对时间），可用evt.trig_met获取触发时间
# （如果事例文件是daily文件，需手动定义：evt.trig_met=**）
bg_time_range_list = [[evt.trig_met - 30, evt.trig_met - 10],
                      [evt.trig_met + 25, evt.trig_met + 40]]

# 用于本底拟合的光变时间bin
time_bin_width = 0.1
# 用于本底拟合的阶次
bg_fit_order = 2
# 选择输出能谱的探头，输入探头如果为全增益，则会分别输出高低增益
detector_list = [
    GRD(18, "high"),
]

# 能谱文件的输出文件夹路径（文件夹会自动创建）
out_dir=rf"/root/temp/test2/"

# 生成能谱文件
# 参考rmfit，先生成光变（能谱）,画出源的范围，再生成能谱文件
spec_file_data_dic=evt.generate_spec_fits(detector_list, source_time_range, channel_range_list_high, channel_range_list_low,
                       time_bin_width, bg_time_range_list, bg_fit_order,out_dir)
```

    g18H


### 查看能谱文件
1. 进入out_dir，查看能谱的fits文件  
2. full_spec_bg18H_v01.fits 为GRD18-高增益的总能谱
3. bg_spec_bg18H_v01.fits 为GRD18-高增益的背景能谱
4. net_spec_bg18H_v01.fits 为GRD18-高增益的净能谱

### 查看能谱相关数据


```python
spec_file_data_dic.keys()
```




    dict_keys(['bg18H'])




```python
# 查看能谱数据

for det in spec_file_data_dic.keys():
    
    det_spec_data=spec_file_data_dic[det]
    print(det_spec_data.keys())
    
    lc_x=det_spec_data['lc_x']
    lc_y=det_spec_data['lc_y']
    bg_lc_y=det_spec_data['bg_lc_y']
    net_lc_y=det_spec_data['net_lc_y']
    
#     ...
#     各个能段的活时间
    exposure_list=det_spec_data['exposure_list']
#     各个能段本底拟合的信息
    channel_bg_fit_info=det_spec_data['channel_bg_fit_info']
    
```

    dict_keys(['channel_bins', 'lc_x', 'lc_y', 'bg_lc_y', 'net_lc_y', 'spec', 'spec_err', 'bg_spec', 'bg_spec_err', 'net_spec', 'net_spec_err', 'exposure_list', 'channel_bg_fit_info'])



```python
spec_file_data_dic['bg18H']['channel_bg_fit_info']["168-172"].keys()
```




    dict_keys(['time_bin', 'time_range', 'lc_x_all', 'lc_y_all', 'lc_deadtime_all', 'bg_time_range', 'bg_fit_y', 'bg_fit_y_err', 'bg_fit_result'])




```python

```


```python
choose_det='bg18H'
choose_channel="168-172"
trig_met=evt.trig_met

spec_channel_data=spec_file_data_dic[choose_det]['channel_bg_fit_info'][choose_channel]
bg_fit_result=spec_channel_data["bg_fit_result"]

fig = plt.figure(figsize=(10, 5), dpi=100)
plt.title(f"{choose_det},channel:[{choose_channel})\n{bg_fit_result}")

lc_x=spec_channel_data["lc_x_all"]-trig_met
lc_y=spec_channel_data["lc_y_all"]
lc_y_min=np.min(lc_y)
lc_y_max=np.max(lc_y)

bg_time_range_list=spec_channel_data["bg_time_range"]

plt.step(lc_x,lc_y,where="mid",label="lc")
plt.step(lc_x,spec_channel_data["bg_fit_y"],where="mid",label="bg-fit")
plt.errorbar(lc_x, spec_channel_data["bg_fit_y"], yerr=spec_channel_data["bg_fit_y_err"], ls='',label="bg-fit-err")

for index,(bg_t_start,bg_t_stop) in enumerate(bg_time_range_list):
    plt.fill_between([bg_t_start-trig_met,bg_t_stop-trig_met],lc_y_min, lc_y_max, facecolor='red', alpha=0.1,label=f"bg{index+1}")

plt.legend()

plt.xlabel(f"Time $T$, $T_0$ is trigger time")
plt.ylabel("Counts")
```




    Text(0, 0.5, 'Counts')




![png](images/output_32_1.png)



```python
bg_time_range_list
```




    [[74431570.6, 74431590.6], [74431625.6, 74431640.6]]


