# 模块
    每个文件应该包含一个许可样板. 根据项目使用的许可(例如, Apache 2.0, BSD, LGPL, GPL), 选择合适的样板.

***
# 函数和方法
一个函数必须要有文档字符串, 除非它满足以下条件:
外部不可见  
非常短小  
简单明了  

函数注释示例：  

    def geocenter_to_spacecraft(phi, theta, geo_cosines):
        """Convert `n` points from geocenter frame to spacecraft frame
        
        Args:
            phi (float or np.array): The azimuthal location of positions in 
                                     geocentric coordinates
            theta (float or np.array): The polar location of positions in 
                                       geocentric coordinates    
            geo_cosines (np.array): (3,3) array containing the direction cosines
        
        Returns:
            (np.array, np.array): Azimuth and zenith positions in the spacecraft frame
        
        Raises:
            IOError: An error occurred accessing the bigtable.Table object.
            
        """
        
        pass
# 类
类应该在其定义下有一个用于描述该类的文档字符串. 如果你的类有公共属性(Attributes), 那么文档中应该有一个属性(Attributes)段. 并且应该遵守和函数参数相同的格式.

    class SampleClass(object):
        """Summary of class here.
    
        Longer class information....
        Longer class information....
    
        Attributes:
            likes_spam: A boolean indicating if we like SPAM or not.
            eggs: An integer count of the eggs we have laid.
        """
    
        def __init__(self, likes_spam=False):
            """Inits SampleClass with blah."""
            self.likes_spam = likes_spam
            self.eggs = 0
    
        def public_method(self):
            """Performs operation blah."""
***     
# 块注释和行注释

最需要写注释的是代码中那些技巧性的部分. 如果你在下次 代码审查 的时候必须解释一下,   
那么你应该现在就给它写注释. 对于复杂的操作, 应该在其操作开始前写上若干行注释.   
对于不是一目了然的代码, 应在其行尾添加注释.

    # We use a weighted dictionary search to find out where i is in
    # the array.  We extrapolate position based on the largest num
    # in the array and the array size and then do binary search to
    # get the exact number.
    
    if i & (i-1) == 0:        # True if i is 0 or a power of 2.
    为了提高可读性, 注释应该至少离开代码2个空格.
    
    另一方面, 绝不要描述代码. 假设阅读代码的人比你更懂Python, 他只是不知道你的代码要做什么.
    
    # BAD COMMENT: Now go through the b array and make sure whenever i occurs
    # the next element is i+1