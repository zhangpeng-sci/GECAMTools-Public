# GECAMTools 合作开发手册

## 所需软件
1. Python  
    python环境：python版本>=3.6 (不建议安装python 3.9及以上版本)  
    建议使用Anaconda创建独立的python环境使用，防止出现不同软件的依赖库版本不兼容问题。 [Miniconda使用说明](https://www.jianshu.com/p/7299c2d4d170)
        
2. Git  
    [Git使用教程](https://www.runoob.com/git/git-tutorial.html)   

3. python开发IDE  
   建议使用Pycharm,[Pycharm使用教程](https://www.runoob.com/w3cnote/pycharm-windows-install.html)   
    

## 安装与卸载
1.使用Git,fork GECAMTools到自己的仓库  
2.创建分支  
3.切换分支  
4.编写程序  
    4.1 安装开发所需库 [requirements_dev.txt](requirements_dev.txt)  
         `pip install requirements_dev.txt`   
    4.2 实现程序  
        文件以及程序命名规则,[命名规则](name_rule.md)  
        需编写充分的注释(英文),[注释要求](annotation.md)
         
5.提交更新  
6.提交合并申请

