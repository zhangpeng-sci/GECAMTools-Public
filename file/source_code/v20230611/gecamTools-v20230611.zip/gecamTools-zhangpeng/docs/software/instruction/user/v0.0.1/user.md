# GECAMTools v0.0.1 使用说明

## 安装与卸载
1. 所需环境  
    1.1 windows、linux、mac  
    1.2 python版本>=3.6

2. 安装流程  
    2.1 下载源程序  
    gecamTools-master.zip  
    
    2.2 安装  
    将会自动安装GECAMTools以及相关依赖库  
    `pip install gecamTools-master.zip`
    
    2.3 测试  
    `import gecam`

3. 卸载流程  
    `pip uninstall GECAMTools`

## 读取事例数据（daily或trigger）


```python
from gecam.data.evt import EVT
from gecam.data.detector import GRD, CPD
import numpy as np
```


```python
fits_path = r"gbg_evt_tn210511_112749_fb_v00.fits"

evt=EVT(fits_path)
```

    File name: gbg_evt_tn210511_112749_fb_v00.fits
    Telescope: GECAM-B
    Instrument: GRD
    Observation met: (74431501.0, 74431899.0)
    Trigger id: tn210511_112749_fb
    Trigger met: 74431600.6; utc: 2021-05-11T11:26:40.600
    Location(J2000): RA:317.99; DEC: 59.53


## 输出光变


```python
# 光变的时间bin
evt.lc_time_bin = 0.1
# 光变的时间范围
evt.time_range = (evt.trig_met - 40, evt.trig_met + 50)
# 选择多个探头 GRD(18, "high") 标识GRD18高增益，GRD(20, None)全增益（过滤重复事例）
choose_det=[GRD(1, "high"),GRD(19, "low"),GRD(20, None)]

# 生成多个探头叠加的光变(lc_data_dic中包含光变的数据)
lc_data_dic=evt.light_curve(choose_det)
```


![png](images/lc_example.png)


## 输出能谱


```python

# 能谱的时间范围
evt.time_range = (evt.trig_met - 10, evt.trig_met + 20)
# 能谱的能道范围
evt.channel_range = [50, 180]
# 能谱的能道合并（整数），均匀并道
evt.spec_channel_bin=1
choose_det=[GRD(18, "high"),GRD(19, "low")]

# 生成多个探头的叠加能谱(spec_data_dic中包含能谱的数据)
spec_data_dic=evt.spectrum(choose_det)
```


![png](images/spec_example.png)


## 生成能谱文件


```python

# 感兴趣的时间范围
source_time_range = (evt.trig_met - 1, evt.trig_met + 9)
# 高增益能道分bin（整数），示例：4：表示均匀的每4道进行合并
channel_range_list_low = 4
# 低增益能道分bin（整数），示例：4：表示均匀的每4道进行合并
channel_range_list_high = 4
# 本底时间段（绝对时间），可用evt.trig_met获取触发时间（如果事例文件是daily文件，需手动定义：evt.trig_met=**）
bg_time_range_list = [[evt.trig_met - 30, evt.trig_met - 10],
                      [evt.trig_met + 25, evt.trig_met + 40]]

# 用于本底拟合的光变时间bin
time_bin_width = 0.1
# 用于本底拟合的阶次
bg_fit_order = 2
# 选择输出能谱的探头，输入探头如果为全增益，则会分别输出高低增益
detector_list = [
    GRD(18, "high"),
]
# 能谱文件的输出文件夹路径（文件夹会自动创建）
out_dir=rf"/root/temp/test/"

# 生成能谱文件
spec_file_data_dic=evt.generate_spec_fits(detector_list, source_time_range, channel_range_list_high, channel_range_list_low,
                       time_bin_width, bg_time_range_list, bg_fit_order,out_dir)
```

### 查看能谱文件
1. 进入out_dir，查看能谱的fits文件  
2. full_spec_bg18H_v01.fits 为GRD18-高增益的总能谱
3. bg_spec_bg18H_v01.fits 为GRD18-高增益的背景能谱
4. net_spec_bg18H_v01.fits 为GRD18-高增益的净能谱


```python
# 查看能谱数据

for det in spec_file_data_dic.keys():
    
    det_spec_data=spec_file_data_dic[det]
    print(det_spec_data.keys())
    
    lc_x=det_spec_data['lc_x']
    lc_y=det_spec_data['lc_y']
    bg_lc_y=det_spec_data['bg_lc_y']
    net_lc_y=det_spec_data['net_lc_y']
    
#     ...
#     各个能段的活时间
    exposure_list=det_spec_data['exposure_list']
    
```

    dict_keys(['channel_bins', 'lc_x', 'lc_y', 'bg_lc_y', 'net_lc_y', 'spec', 'spec_err', 'bg_spec', 'bg_spec_err', 'net_spec', 'net_spec_err', 'exposure_list'])

