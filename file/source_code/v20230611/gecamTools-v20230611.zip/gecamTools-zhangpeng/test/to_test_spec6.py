# test_spec6: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt

evt_path = r"D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
evt = Evt.open(evt_path)

trig_met = evt.info.trig_met

chooose_det = [GRD(18, gain_type="both"), GRD(19, gain_type="both")]

slice_kwargs_dic = {
    "time_range": [trig_met - 50, trig_met + 60],
    "only_recommend": True
}
lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": [4, 4],  # [channel_bin_high_gain,channel_bin_low_gain]
    "correct_by_dead_time": True,
}
lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 40, trig_met - 10], [trig_met + 25, trig_met + 60]],
    "fit_order": 1,
}
spec_file_kwargs_dic = {
    "src_range_list": [
        [trig_met - 1, trig_met + 9],
    ],
    "rsp_list": [["gbg_18H_x_evt_v00.rsp", "gbg_18L_x_evt_v00.rsp"],
                 ["gbg_25H_x_evt_v00.rsp", "gbg_25L_x_evt_v00.rsp"]],
    "out_dir": r"E:\gecamTools\test_gecam\evt_file\test/spec/"
}

spec_data = evt.generate_spec_file_with_detecotrs(chooose_det, slice_kwargs_dic, lc_kwargs_dic,
                                                  lc_bg_fit_kwargs_dic, spec_file_kwargs_dic)

print(1)