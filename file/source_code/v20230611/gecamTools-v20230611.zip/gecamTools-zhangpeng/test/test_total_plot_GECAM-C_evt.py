# test_total_plot: 
#
#     Authors: Peng Zhang (IHEP), Yanqiu Zhang (IHEP)
#              Wangchen Xue (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import matplotlib.pyplot as plt
from gecam.data.evt import Evt
from gecam.plot.light_curve import LightCurveFigure
from gecam.data.spec import SpecFile
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.detector import Detector, GRD

file_path = "D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
file_path = r"E:\gecamTools\test_hebs\gbc_evt_bn230120_105312_v00.fits"
file_path = r"E:\gecamTools\test_hebs\gcg_evt_tn220921_205416_gc_v00.fits"
# 读取HXMT的事例文件
evt = Evt.open(file_path)

trig_met = evt.info.trig_met
chooose_det = [GRD(11, gain_type="both"), GRD(12, gain_type="both")]
slice_kwargs_dic = {
    "time_range": [trig_met - 50, trig_met + 60],
    "only_recommend": True
}

lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": 1,
    "correct_by_dead_time": True,
}
fig_kwargs_dic = {
    "bg_range": [[trig_met - 40, trig_met - 30], [trig_met + 30, trig_met + 40]],
    "src_range": [trig_met - 5, trig_met + 12]
}

# # # 画多探头的叠加光变
# total_lc_obj, dets_lc_list, lc_data, lc_fig = evt.plot_light_curve_with_detectors(chooose_det, slice_kwargs_dic,
#                                                                                   lc_kwargs_dic, fig_kwargs_dic)
#
# plt.show()
#
#
# spec_kwargs_dic = {
#     "channel_bin": 1
# }
# fig_kwargs_dic = {}
#
# # 画多探头的叠加的能谱
# total_spec_obj, dets_spec_list, plot_spec_data, spec_fig = evt.plot_spectrum_with_detectors(chooose_det,
#                                                                                             slice_kwargs_dic,
#                                                                                             spec_kwargs_dic,
#                                                                                             fig_kwargs_dic)
# plt.show()

lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": [1, 1],  # [channel_bin_high_gain,channel_bin_low_gain]
}
lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 40, trig_met - 30], [trig_met + 25, trig_met + 60]],
    "fit_order": 1,
}
spec_file_kwargs_dic = {
    "src_range_list": [
        [trig_met - 5, trig_met - 1],
        [trig_met - 5, trig_met + 9],
        [trig_met - 5, trig_met + 4],
        [trig_met + 4, trig_met + 10]
    ],
    "rsp_list": [["det1_high_gain.rsp", "det1_low_gain.rsp"],
                 ["det2_high_gain.rsp", "det2_low_gain.rsp"]],
    "out_dir": "E:/gecamTools/test_spec_gecam_evt/"
}

a = evt.generate_spec_file_with_detecotrs(chooose_det, slice_kwargs_dic, lc_kwargs_dic,
                                          lc_bg_fit_kwargs_dic, spec_file_kwargs_dic)

print(1)
