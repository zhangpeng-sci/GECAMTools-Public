import numpy as np
from astropy.io import fits
import matplotlib.pyplot as plt

grb_name_list = ["GRB220610295", "GRB220610906", "GRB220612013", "GRB220613395", "GRB220617673",
                 "GRB220617772", "GRB220618382", "GRB220618761", "GRB220619207", "GRB220620016",
                 "GRB220620064", "GRB220620261", "GRB220622394", "GRB220623649", "GRB220624124"]

burst_info_fits=fits.open(r"C:\Users\10500\Desktop\test\fermi_burst_info_20220930.fits")

burst_info_list=burst_info_fits[1].data


for grb_name in grb_name_list:

    grb_info=burst_info_list[burst_info_list["NAME"]==grb_name][0]
    ra,dec=grb_info["RA"],grb_info["DEC"]
    trig_mjd=grb_info["TRIGGER_TIME"]
    t90=grb_info["T90"]
    t90_start = grb_info["T90_START"]




    print(1)




a = np.load(r"C:\Users\10500\Desktop\test\dets_spec_info.npy", allow_pickle=True)
b = np.load(r"C:\Users\10500\Desktop\test\dets_spec_data.npy", allow_pickle=True)
c = np.load(r"C:\Users\10500\Desktop\test\dets_total_lc_data.npy", allow_pickle=True)

print(1)
