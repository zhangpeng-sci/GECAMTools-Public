from gecam.data.evt import Evt
from gecam.data.detector import GRD, CPD
import matplotlib.pyplot as plt

evt = Evt.open("D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits")

detector_list = [
    GRD(18, "both"),
]

evt_info = evt.info
trig_met = evt_info.trig_met

lc_met_range = [trig_met - 50, trig_met + 50]

# evt.plot_light_curve(detector_list, time_range=lc_met_range, time_bin=1, channel_range=None,
#                      energy_range=None, only_recommend=True, src_range=None, bg_range=None, ref_met=None)
#
# plt.show()
#
# evt.plot_spectrum(detector_list, time_range=lc_met_range, channel_bin=None, energy_bin=None, channel_range=None,
#                   energy_range=None, only_recommend=True)
# plt.show()

src_range_list = [
    [trig_met - 5, trig_met - 1],
    [trig_met - 5, trig_met + 9],
    [trig_met - 5, trig_met + 4],
    [trig_met + 4, trig_met + 10]

]

channel_bin = [1, 1]

bg_range_list = [[trig_met - 40, trig_met - 10], [trig_met - 40, trig_met - 10]]

spec_out_dir = r"E:/gecamTools/test_compare/"

evt.generate_spec_file(detector_list, src_range_list, channel_bin, bg_range_list, rsp_list=None, time_bin=0.1,
                       bg_fit_order=2, only_recommend=True,
                       out_dir=spec_out_dir)
