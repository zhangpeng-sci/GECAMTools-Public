# test_yanqiu: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong* (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.posatt import PosAtt
from gecam.coord import radec_to_thetaphi
from gecam.utils import rsp_utils
import matplotlib.pyplot as plt
import numpy as np
import os


class Generate_Lightcurve_GECAM:
    def __init__(self, DataPath, PhotoPath, recommed_flag, triggrer_time, time_bin, GRD_list, GRB_name, lC_range,
                 source_range, BG_range):
        self.DataPath = DataPath
        self.PhotoPath = PhotoPath
        self.recommed_flag = recommed_flag
        self.triggrer_time = triggrer_time
        self.time_bin = time_bin
        self.GRD_list = GRD_list
        self.GRB_name = GRB_name
        self.lC_range = lC_range
        self.source_range = source_range
        self.BG_range = BG_range

    def Judge(path):
        if os.path.exists(path):
            pass
        else:
            os.mkdir(path)

    def plot_lightcurve(self):
        Generate_Lightcurve_GECAM.Judge(self.PhotoPath)
        Generate_Lightcurve_GECAM.Judge(self.PhotoPath + f'\{self.GRB_name}')
        evt = Evt.open(self.DataPath)
        lc_l, lc_r = self.lC_range
        # BG1_l, BG1_r, BG2_l, BG2_r = self.BG_range
        trig_met = evt.info.trig_met = self.triggrer_time
        # Source_Range = np.array(self.source_range).reshape(int(len(self.source_range)/2),2)
        lc_time_range = (trig_met + lc_l, trig_met + lc_r)
        # bg_time_range_list = [[trig_met + BG1_l, trig_met + BG1_r], [trig_met + BG2_l, trig_met + BG2_r]]
        bg_time_range_list = [[trig_met + BG[0], trig_met + BG[1]] for BG in self.BG_range]
        # for i in range(int(Source_Range.size/2)):
        for id, Source_Range in enumerate(self.source_range):
            source_l, source_r = Source_Range
            src_time_range = (trig_met + source_l, trig_met + source_r)
            for det in self.GRD_list:
                lc_data, lc_fig = evt.plot_light_curve([GRD(int(det))], time_range=lc_time_range,
                                                       time_bin=self.time_bin,
                                                       only_recommend=self.recommed_flag, src_range=src_time_range,
                                                       bg_range=bg_time_range_list, ref_met=trig_met)
                lc_fig.savefig(f'{self.PhotoPath}\{self.GRB_name}\lightcurve_GRD{det}_phase{id + 1}.png',
                               bbox_inches='tight')
                plt.close()


class Generate_Spectrum_GECAM(Generate_Lightcurve_GECAM):
    def __init__(self, DataPath, PhotoPath, recommed_flag, triggrer_time, time_bin, GRD_list, GRB_name, lC_range,
                 source_range, BG_range, out_dir, channel_bins_high, channel_bins_low, bg_fit_order):
        Generate_Lightcurve_GECAM.__init__(self, DataPath, PhotoPath, recommed_flag, triggrer_time, time_bin, GRD_list,
                                           GRB_name, lC_range, source_range, BG_range)
        self.out_dir = out_dir
        self.channel_bins_high = channel_bins_high
        self.channel_bins_low = channel_bins_low
        self.bg_fit_order = bg_fit_order

    def Judge(path):
        if os.path.exists(path):
            pass
        else:
            os.mkdir(path)

    def Spectrum_Generate(self):
        Generate_Spectrum_GECAM.Judge(self.out_dir)
        Generate_Spectrum_GECAM.Judge(self.out_dir + f'\{self.GRB_name}')

        det_list = []
        for det in self.GRD_list:
            det_list.append(GRD(int(det)))
        evt = Evt.open(self.DataPath)
        lc_l, lc_r = self.lC_range
        # BG1_l, BG1_r, BG2_l, BG2_r = self.BG_range
        trig_met = evt.info.trig_met = self.triggrer_time
        channel_bins = [self.channel_bins_high, self.channel_bins_low]
        # bg_range_list = [[trig_met + BG1_l, trig_met + BG1_r], [trig_met + BG2_l, trig_met + BG2_r]]
        bg_range_list = [[trig_met + BG[0], trig_met + BG[1]] for BG in self.BG_range]
        # Source_Range = [(self.source_range[i],self.source_range[i+1]) for i in range(len(self.source_range)-1)]
        # # np.array(self.source_range).reshape(int(len(self.source_range)/2),2)
        src_range_list = []
        for Source_Range in self.source_range:
            source_l, source_r = Source_Range
            src_range_list.append([trig_met + source_l, trig_met + source_r])
        rsp_list = None
        spec_data = evt.generate_spec_file(det_list, src_range_list, channel_bins, bg_range_list, rsp_list,
                                           self.time_bin, "2pass", self.bg_fit_order, self.recommed_flag,
                                           self.out_dir + f'\{self.GRB_name}')
        Generate_Spectrum_GECAM.Plot_BG_Fit_Merit(self, spec_data)
        return spec_data

    def Plot_BG_Fit_Merit(self, spec_data):
        Generate_Spectrum_GECAM.Judge(self.PhotoPath)
        Generate_Spectrum_GECAM.Judge(self.PhotoPath + f'\{self.GRB_name}')
        # choose_det = []
        # choose_det.extend([GRD(int(i), "high") for i in self.GRD_list])
        # choose_det.extend([GRD(int(i), "low") for i in self.GRD_list])
        # det_name = ['b' + det.full_name for det in choose_det]
        channel_range = [0, 498]
        for det in spec_data.keys():
            spec_data_list = spec_data.get(det)
            # 查看本底拟合的好坏
            bg_lc = spec_data_list.get("bg_lc")
            bg_lc.show_fitting_quality(channel_range=channel_range)
            plt.savefig(f'{self.PhotoPath}\{self.GRB_name}\The BG Fit Merit of {det}.png')
            plt.close()


class Generate_Rsp_GECAM:
    def __init__(self, DataPath, triggrer_time, GRD_list, GRB_name, out_dir, ra, dec):
        self.DataPath = DataPath
        self.triggrer_time = triggrer_time
        self.GRD_list = GRD_list
        self.GRB_name = GRB_name
        self.out_dir = out_dir
        self.ra = ra
        self.dec = dec

    def Judge(path):
        if os.path.exists(path):
            pass
        else:
            os.mkdir(path)

    def Rsp_Generate(self):
        Generate_Rsp_GECAM.Judge(self.out_dir)
        Generate_Rsp_GECAM.Judge(self.out_dir + f'/{self.GRB_name}')
        det_list = []
        for det in self.GRD_list:
            det_list.append(GRD(int(det)))
        posatt_obj = PosAtt.open(self.DataPath)
        # 选定met时间，或使用触发时间 evt.trig_met
        choose_met = self.triggrer_time
        quat = posatt_obj.get_quat(choose_met)
        # 设定源坐标（J2000）
        ra = self.ra
        dec = self.dec
        # 根据源的坐标和卫星姿态计算入射角（deg）
        theta, phi = radec_to_thetaphi(ra, dec, quat)
        print(theta, phi)
        det_rsp_list = []
        event_type = 'evt'
        for det in det_list:
            temp_rsp_list = []
            for gain_type in ["high", "low"]:
                det.set_gain_type(gain_type)
                det.set_satellite("b")
                temp_rsp_path = rsp_utils.generate_rsp_fits(det.full_name, theta, phi, choose_met, 'evt',
                                                            out_dir + f'/{self.GRB_name}/')
                temp_rsp_list.append(os.path.basename(temp_rsp_path))
            det_rsp_list.append(temp_rsp_list)
        return det_rsp_list


from gecam.time import GecamMet, HebsMet, HxmtMet
from gecam.data.detector import GRD, CPD

a=GRD(1).full_name
met_func = GecamMet
triggrer_time = met_func.from_iso('2022-12-01T22:06:59.079')
triggrer_time = triggrer_time.met
DataPath = r"D:\test\gecam\gbg_evt_221201_22_v00.fits"
PhotoPath = r"D:\test\gecam\1/"
out_dir = r"D:\test\gecam\1/"
GRB_name = 'SGR221201'
recommed_flag = False
# triggrer_time = 95890865.1
lC_range = [-20, 20]
source_range = [(0, 0.05), (0, 0.1), (0, 0.5), (0, 1)]
time_bin = 0.05
BG_range = [(-20., -5), (4, 18)]
# lC_range = [34, 35]
# source_range = [34.45,34.55]
# time_bin = 0.005
# BG_range = [34., 34.4, 34.6, 35]
GRD_list = np.array([3, 4, 10])
# channel_bins_high = 1
channel_bins_low = 10
channel_bins_high = list(np.unique(
    np.append(np.append(np.arange(0, 35, 1), np.logspace(np.log10(35), np.log10(200), num=48).astype(int)),
              np.arange(200, 498, 1))))
bg_fit_order = 1
lightcurve = Generate_Lightcurve_GECAM(DataPath, PhotoPath, recommed_flag, triggrer_time, time_bin, GRD_list, GRB_name,
                                       lC_range, source_range, BG_range)
lightcurve.plot_lightcurve()
spectrum = Generate_Spectrum_GECAM(DataPath, PhotoPath, recommed_flag, triggrer_time, time_bin, GRD_list, GRB_name,
                                   lC_range, source_range, BG_range, out_dir, channel_bins_high, channel_bins_low,
                                   bg_fit_order)
spec_data = spectrum.Spectrum_Generate()



