# test_spec5: 
#
#     Authors: Peng Zhang (IHEP), Wangchen Xue (IHEP),
#              Yanqiu Zhang (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt

evt_path = r"D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
evt = Evt.open(evt_path)

# 过滤出探头18的数据
det_events = evt.select_detector(18)

det_sliced_events = det_events.slice(gain_type="high", only_recommend=True)

# 提取触发时间
trig_met = evt.info.trig_met

# 光变的总时间范围（绝对时间）
lc_time_range = (trig_met - 50, trig_met + 70)

# 定义源时间段
src_time_range = [trig_met - 3, trig_met + 9]
# 定义本底时间段
bg_time_range_list = [[trig_met - 40, trig_met - 20],
                      [trig_met + 25, trig_met + 60]]

# 时间bin，单位秒
time_bin = 2
# 能道分bin，整数为均匀分bin，一维列表为自定义分bin
channel_bin = 1

det_sliced_lc = det_sliced_events.to_light_curve(lc_time_range, time_bin, channel_bin)
# 本底拟合，拟合阶次为2
det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=2)
# 提取源时间段的光变
det_src_lc = det_sliced_events.to_light_curve(src_time_range, time_bin, channel_bin)

# 生成能谱文件的数据,时间分解谱
# det_sliced_lc： 单个探头的光变
# det_sliced_bg_lc： 单个探头的本底光变
from gecam.data.spec import SpecFile

spec_file = SpecFile(det_sliced_lc, det_sliced_bg_lc)

# 添加第一个源时间段
src_time_range = (trig_met - 1, trig_met + 9)
spec, bg_spec, net_spec = spec_file.add_src(src_time_range)


# 添加第二个源时间段
src_time_range2 = (trig_met + 9, trig_met + 15)

custom_bg_spec=(bg_spec.counts,bg_spec.counts_err)
spec2, bg_spec2, net_spec2 = spec_file.add_src(src_time_range2,custom_bg_spec=custom_bg_spec)

spec_file.write(out_dir=r"E:\gecamTools\test_gecam\evt_file\test/spec2/")

from gecam.plot.spectrum import SpectrumFigure

# 画出能谱文件的数据（当前选择第一段源时间段的能谱）
spec_fig = SpectrumFigure()
spec_fig.add_data(spec.get_plot_data(), color="#474747", err_color="#474747", label="full-spec",
                  linewidth=1)
spec_fig.add_data(bg_spec.get_plot_data(), color="#0c5da5", err_color="#0c5da5", label="bg-spec",
                  linewidth=1)
spec_fig.add_data(net_spec.get_plot_data(), color="#16bf55", err_color="#16bf55", label="net-spec",
                  linewidth=1)

# 截断显示
spec_fig.set_xlim([0, 200])
# spec_fig.set_yscale("linear")
spec_fig.show_legend()
# spec_fig.savefig(r"C:\Users\10500\Desktop\g高能项目\会议\空间天文卫星数据处理讲习班/spec.png", transparent=True,
#                  bbox_inches='tight', pad_inches=0.0)
# plt.show()
