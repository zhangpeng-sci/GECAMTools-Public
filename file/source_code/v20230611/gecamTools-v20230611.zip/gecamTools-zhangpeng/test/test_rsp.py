from gecam.data.posatt import PosAtt
from gecam.coord import radec_to_thetaphi
from gecam.utils import rsp_utils
from gecam.data.detector import GRD
from RSP_Generator import gen_rsp_fits
from gecam.time import GecamMet
import os

# 读取posatt文件
posatt_path = r"/gecamfs/Archived-DATA/GSDC/LEVEL1/triggers/2022/04/tn220418_171621_gb/gb_posatt_tn220418_171621_v00.fits"
posatt_obj = PosAtt.open(posatt_path)

# 选定met时间
# choose_met = 74431600.6
choose_met = GecamMet.from_iso("2022-04-18T17:16:21.650").met
# 设定源坐标（J2000）
ra = 224.344
dec = -17.539
burst_name = "bn220418_171621"
out_dir = "./rsp/"
if not os.path.exists(out_dir):
    os.makedirs(out_dir)

# 获取时间点对应的卫星姿态（四元数）
quat = posatt_obj.get_quat(choose_met)

# 根据源的坐标和卫星姿态计算入射角（deg）
theta, phi = radec_to_thetaphi(ra, dec, quat)

choose_dets = []
choose_dets.extend([GRD(number=i, gain_type="high") for i in range(1, 26)])
choose_dets.extend([GRD(i, "low") for i in range(1, 26)])
for det in choose_dets:
    det.set_satellite("b")

for det in choose_dets:
    det.set_satellite("b")
    print(det.full_name)
    # x:表示x射线
    # rsp文件命名应该是类似这样的： gbg_15H_x_evt_bn220418_155159_v00.rsp
    out_path = f"{out_dir}{det.full_name}_x_evt_{burst_name}_v00.rsp"
    rsp_sig = gen_rsp_fits(det.full_name, theta, phi, fits_filepath=out_path, is_overwrite=True,
                           event_type='evt', particle='gamma', MET=choose_met, temp=None, hv=None)
    print(rsp_sig)
