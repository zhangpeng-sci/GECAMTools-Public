# test_total_plot: 
#
#     Authors: Peng Zhang (IHEP), Yanqiu Zhang (IHEP)
#              Wangchen Xue (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import matplotlib.pyplot as plt
from gecam.data.hxmt_evt import EvtHxmt
from gecam.plot.light_curve import LightCurveFigure
from gecam.data.spec import SpecFile
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.detector import Detector, HE, LE

# 读取HXMT的事例文件
evt = EvtHxmt.open(r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\HEB221009553_HE-Evt.fits")

trig_met = evt.info.trig_met
time_range = [trig_met - 50, trig_met + 80]

# 注意HXMT，所使用的channel都是代表的事例数据中的PI，而不是CHANNEL
#             time_range (list): [time_min, time_max) ,   time_min<= time < time_max
#             channel_range (list): [channel_min, channel_max)
#             pulse_width_range (list): [pulse_width_min, pulse_width_max)
slice_kwargs_dic = {
    "time_range": [trig_met - 50, trig_met + 80],
    "channel_range": None
}

lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": 1,
    "correct_by_dead_time": r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\DeadTime_Proportion.txt",
}
fig_kwargs_dic = {
    "bg_range": [[trig_met - 40, trig_met - 30], [trig_met + 25, trig_met + 60]],
    "src_range": [trig_met - 1, trig_met + 7]
}

# # 画多探头的叠加光变
total_lc_obj, dets_lc_list, lc_data, lc_fig = evt.plot_light_curve_with_detectors([HE(1), HE(2)], slice_kwargs_dic,
                                                                                  lc_kwargs_dic, fig_kwargs_dic)
plt.show()
#
spec_kwargs_dic = {
    "channel_bin": 1
}
fig_kwargs_dic = {}

# 画多探头的叠加的能谱
total_spec_obj, dets_spec_list, plot_spec_data, spec_fig = evt.plot_spectrum_with_detectors([HE(1), HE(2)],
                                                                                            slice_kwargs_dic,
                                                                                            spec_kwargs_dic,
                                                                                            fig_kwargs_dic)
plt.show()
det_list = [HE(1), HE(2)]

lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 40, trig_met - 30], [trig_met + 25, trig_met + 60]],
    "fit_order": 1,
}
spec_file_kwargs_dic = {
    "src_range_list": [
        [trig_met - 5, trig_met - 1],
        [trig_met - 5, trig_met + 9],
        [trig_met - 5, trig_met + 4],
        [trig_met + 4, trig_met + 10]
    ],
    "rsp_list": ["test.rsp","test.rsp","test.rsp","test.rsp"],
    "out_dir": "E:/gecamTools/test_compare/"
}

a = evt.generate_spec_file_with_detecotrs(det_list, slice_kwargs_dic, lc_kwargs_dic,
                                          lc_bg_fit_kwargs_dic, spec_file_kwargs_dic)

print(1)
