from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt

# 事例文件路径
evt_path = r"D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
evt = Evt.open(evt_path)

# 获取触发事例数据中的触发时间
trig_met = evt.info.trig_met
# 选择多个探头，例：GRD18（包含高低增益），GRD19(高增益)
chooose_det = [GRD(18, gain_type="both"), GRD(19, gain_type="high")]

# 光变的整体时间区间
lc_time_range = (trig_met - 50, trig_met + 60)
# 源时间区间
src_time_range = (trig_met - 5, trig_met + 12)
src_time_range2 = (trig_met + 9, trig_met + 15)
# 多段本底的时间区间
bg_time_range_list = [[trig_met - 40, trig_met - 30], [trig_met + 30, trig_met + 40]]
# 光变的时间bin，单位：秒
time_bin = 1

# 是否选取推荐事例，True:只选取推荐事例  False:选取全部事例
only_recommend = True

lc_data, lc_fig = evt.plot_light_curve(chooose_det, time_range=lc_time_range, time_bin=time_bin,
                                       only_recommend=only_recommend, src_range=src_time_range,
                                       bg_range=bg_time_range_list)
# lc_fig.axes[0].set_xlim([0,10])
lc_x, lc_y, _lc_y_err = lc_data