from gecam.data.evt import Evt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD, CPD
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure

import matplotlib.pyplot as plt

# fits_path = "D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
fits_path = r"E:\gecamTools\test\gbg_evt_tn211121_065951_gb_v01.fits"
fits_path = r"E:\gecamTools\test_hebs\gcg_evt_tn221005_062232_gc_v00.fits"
fits_path = r"E:\gecamTools\test_hebs\gcg_evt_tn221004_024246_gc_v00.fits"
fits_path = r"E:\gecamTools\test_hebs\gcg_evt_tn221007_235536_gc_v00.fits"
evt = Evt.open(fits_path)

trig_met = evt.info.trig_met

src_time_range = (trig_met - 1, trig_met + 2)

bg_time_range_list = [[trig_met - 5, trig_met - 10], [trig_met + 5, trig_met + 10]]

# 时间bin，单位秒
time_bin = 0.1
# [1,4,7]
channel_bin = 4

# 过滤出探头的数据
det_events = evt.select_detector(10)

# 对于探头数据进一步的数据过滤，增益、时间范围、能量范围、能道范围、是否只使用推荐事例
# gain_type=None, time_range=None, energy_range=None, channel_range=None, only_recommend=True
det_sliced_events = det_events.slice(gain_type="high", only_recommend=True, energy_range=[0, 1000])

# det1_events.slice_custom()


# 对于过滤后的数据提取分能段的光变
lc_time_range = (trig_met - 50, trig_met + 60)
det_sliced_lc = det_sliced_events.to_light_curve(lc_time_range, time_bin, channel_bin)
# 本底拟合
det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=1)
# 提取源时间段的光变
det_src_lc = det_sliced_events.to_light_curve(src_time_range, time_bin, channel_bin)

det_sliced_bg_lc.show_fitting_quality(channel_range=[10, 100])
plt.show()

# 画出总时长光变（合并各个能段）
det_sliced_lc_fig = LightCurveFigure(det_sliced_lc.get_plot_data(), trig_time=trig_met, dpi=100)
# 画出本底
det_sliced_lc_fig.add_background(det_sliced_bg_lc.get_plot_data(),
                                 bg_time_range=det_sliced_bg_lc.bg_time_range)
# 画出源时间段的阴影
det_sliced_lc_fig.add_selection(det_src_lc.get_plot_data())
det_sliced_lc_fig.show_legend()
plt.show()

# 画出能段序号为100的光变
choose_channel_index = 100

channel_lc = det_sliced_lc.get_channel_lc(choose_channel_index)
channel_src_lc = det_src_lc.get_channel_lc(choose_channel_index)
channel_bg_lc = det_sliced_bg_lc.get_channel_lc(choose_channel_index)

det_sliced_c_lc_fig = LightCurveFigure(channel_lc.get_plot_data(), trig_time=trig_met)
det_sliced_c_lc_fig.add_background(channel_bg_lc.get_plot_data(),
                                   bg_time_range=channel_bg_lc.bg_time_range, label="bg")

det_sliced_c_lc_fig.add_selection(channel_src_lc.get_plot_data(), label="src")
det_sliced_c_lc_fig.show_legend()
plt.show()
