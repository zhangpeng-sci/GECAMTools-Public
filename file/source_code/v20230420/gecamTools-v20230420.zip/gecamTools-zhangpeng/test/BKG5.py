# -*- coding: utf-8 -*-
"""
@author: xuewc<xuewc@ihep.ac.cn>
"""

import matplotlib.pyplot as plt
from astropy.io import fits
from lmfit import minimize, Parameters, fit_report
import numpy as np
from numpy import exp, log
from numpy.polynomial import Polynomial
import corner


def background_model_counts(coeffs, t, tbin_width):
    return exp(Polynomial(coeffs)(t))*tbin_width


def lnL(pars, t, tbin_width, data):
    coeffs = list(pars.valuesdict().values())
    model = background_model_counts(coeffs, t, tbin_width)
    return np.sum(data*np.log(model) - model)


def cstat(pars, t, tbin_width, data, data_term):
    coeffs = list(pars.valuesdict().values())
    model = background_model_counts(coeffs, t, tbin_width)
    return model - data*log(model)
    #2*(model - data*log(model) + data_term)


def by_minimization(evt_time, t0, bkg_intervals, src_interval, dt, order):
    '''
    A background fitter and estimator using MLE.

    Parameters
    ----------
    evt_time : array_like
        事例数据的 MET 时间.
    t0 : float
        事例数据的 MET 时间零点.
    bkg_intervals : array_like
        相对于 ``t0`` 的本底区间列表, 例如 [-2, -1.2, 6.8, 10]
    src_interval : array_like
        相对于 ``t0`` 的源信号区间列表, 例如 [-0.5, 4.2].
    dt : float
        用于生成光变数据的时标, 该数据只用于拟合, 不对外输出. 一般情况下, ``dt`` 越小
        本底估计越准, 但计算耗时增加.
    order : int
        拟合函数的阶数.

    Returns
    -------
    tuple

        ``src_interval`` 内的本底估计值 ``bkg`` 及标准差 ``sigma_bkg``,
        最佳拟合参数 ``best_pars`` 及协方差 ``covar``, 对时间序列的偏移量 ``shift``
        和归一量 ``scale``.

    '''
    evt_time = np.array(evt_time) - t0
    bkg_intervals = np.array(bkg_intervals)
    src_interval = np.array(src_interval)
    
    bkg_time, bkg_dt, bkg_count = np.array([]), np.array([]), np.array([])
    for i in range(0, len(bkg_intervals), 2):
        _t1, _t2 = bkg_intervals[i:i+2]
        _tbins = np.linspace(_t1, _t2, int(np.ceil(_t2 - _t1)/dt + 1))
        bkg_time = np.r_[bkg_time, (_tbins[:-1] + _tbins[1:])/2]
        bkg_dt = np.r_[bkg_dt, _tbins[1:] - _tbins[:-1]]
        _mask = (_t1 <= evt_time) & (evt_time <= _t2)
        _count = np.histogram(evt_time[_mask], _tbins)[0]
        bkg_count = np.r_[bkg_count, _count]
    
    if all(bkg_count == 0):
        return 0, 0 # bkg, sigma_bkg
    
    shift = (max(bkg_time) + min(bkg_time))/2
    bkg_time_adj = bkg_time - shift
    scale = 1/max(abs(bkg_time)) if any(abs(bkg_time) > 1) else 1
    bkg_time_adj = scale*bkg_time
    bkg_dt_adj = scale*bkg_dt
    
    data_term = bkg_count*log([c if c else 1 for c in bkg_count]) - bkg_count
    dof = len(bkg_dt) - (order + 1)
    
    pre_coef = [0]*(order + 1)
    pars = Parameters()
    pars.add_many(*[(f'b{n}', bn) for n, bn in enumerate(pre_coef)])
    res = minimize(
        fcn=cstat,
        params=pars,
        method='powell',
        args=(bkg_time_adj, bkg_dt_adj, bkg_count, data_term),
        reduce_fcn=lambda c: np.sum(c)/dof,
        calc_covar=False,
        max_nfev=10000
    )
    
    best_pars = np.array(list(res.params.valuesdict().values())) # shape=(deg,)
    model_count = background_model_counts(best_pars, bkg_time_adj, bkg_dt_adj)
    plt.figure()
    plt.errorbar(bkg_time, bkg_count, bkg_count**0.5, bkg_dt/2, fmt='k ')
    plt.plot(bkg_time, model_count, 'r')
    r_cstat = np.sum(cstat(res.params, bkg_time_adj, bkg_dt_adj, bkg_count, data_term))/dof
    r_pchi2 = np.sum((bkg_count - model_count)**2/model_count)/dof
    
    vec_t = np.array([bkg_time_adj**i for i in range(order + 1)])
    vec_sigma = 1/model_count # shape=(n,)
    vec_ti = (vec_t).reshape(order+1, 1, -1)
    vec_tj = (vec_t).reshape(1, order+1, -1)
    # vec_fi*vec_fj gives a (deg, deg, n) shape array
    fim = np.sum(vec_sigma*(vec_ti*vec_tj)*model_count**2, axis=-1)
    #hessian_matrix = np.sum(
    #    bkg_count/(model_count)**2*(vec_ti*vec_tj)
    #    + (1-bkg_count/model_count)*(vec_ti*vec_tj)*model_count,
    #    axis=-1
    #)
    covar = np.linalg.inv(fim)
    
    t1, t2 = src_interval
    t1 = scale*(t1 - shift)
    t2 = scale*(t2 - shift)
    tbins = np.linspace(t1, t2, int(np.ceil(t2 - t1)/dt + 1))
    twidth = tbins[1] - tbins[0]
    t = (tbins[1:] + tbins[:-1])/2
    vec_t = np.array([t**i for i in range(order + 1)]) # shape=(deg, n)
    bkg = np.exp(np.dot(vec_t.T, best_pars))
    bkg = twidth*np.sum(bkg)
    
    sigma_bkg = np.sqrt(
        twidth*np.sum(np.sum(vec_t*np.dot(covar, vec_t), 0)*bkg)
    )
    print(best_pars, r_cstat, r_pchi2, covar, sep='\n')
    print(bkg,sigma_bkg,'\n', bkg-sigma_bkg, bkg+sigma_bkg, bkg-2.706*sigma_bkg, bkg+2.706*sigma_bkg)
    return bkg, sigma_bkg, best_pars, covar, shift, scale


def by_mcmc(evt_time, t0, bkg_intervals, src_interval, dt, order, steps=2000):
    pre_res = by_minimization(
        evt_time, t0, bkg_intervals, src_interval, dt, order
    )
    pre_coef, pre_covar = pre_res[2], pre_res[3]
    evt_time = np.array(evt_time) - t0
    bkg_intervals = np.array(bkg_intervals)
    src_interval = np.array(src_interval)
    
    bkg_time, bkg_dt, bkg_count = np.array([]), np.array([]), np.array([])
    for i in range(0, len(bkg_intervals), 2):
        _t1, _t2 = bkg_intervals[i:i+2]
        _n = np.ceil(_t2 - _t1)/dt
        _tbins = np.linspace(_t1, _t2, int(_n))
        bkg_time = np.r_[bkg_time, (_tbins[:-1] + _tbins[1:])/2]
        bkg_dt = np.r_[bkg_dt, _tbins[1:] - _tbins[:-1]]
        _mask = (_t1 <= evt_time) & (evt_time <= _t2)
        _count = np.histogram(evt_time[_mask], _tbins)[0]
        bkg_count = np.r_[bkg_count, _count]
    
    if all(bkg_count == 0):
        return 0, 0 # bkg, sigma_bkg
    
    shift = (max(bkg_time) + min(bkg_time))/2
    bkg_time_adj = bkg_time - shift
    scale = 1/max(abs(bkg_time)) if any(abs(bkg_time) > 1) else 1
    bkg_time_adj = scale*bkg_time
    bkg_dt_adj = scale*bkg_dt
    
    dof = len(bkg_dt) - (order + 1)
    
    pars = Parameters()
    pars.add_many(*[(f'b{n}', bn) for n, bn in enumerate(pre_coef)])#+np.random.random(order+1)
    res = minimize(
        fcn=lnL,
        params=pars,
        method='emcee',
        args=(bkg_time_adj, bkg_dt_adj, bkg_count),
        steps=steps
    )
    highest_prob = np.argmax(res.lnprob)
    hp_loc = np.unravel_index(highest_prob, res.lnprob.shape)
    best_pars = res.chain[hp_loc]
    model_count = background_model_counts(best_pars, bkg_time_adj, bkg_dt_adj)
    emcee_plot = corner.corner(
        res.flatchain,
        labels=res.var_names,
        truths=list(res.params.valuesdict().values()),
        quantiles=[0.16, 0.84],
        show_titles=True
    )
    r_pchi2 = np.sum((bkg_count - model_count)**2/model_count)/dof
    print(best_pars, r_pchi2, sep='\n')
    pre_error = np.sqrt(np.diagonal(pre_covar))

    corel = np.empty((order+1, order+1))
    for i in range(order+1):
        for j in range(order+1):
            corel[i,j]=pre_covar[i,j]/pre_error[i]/pre_error[j]
    print('################\nMCMC:\n', fit_report(res.params))
    print('################\nMinimization:')
    for coef, error in zip(pre_coef, pre_error):
        print(f'{coef:.8f} +/- {error:.8f} ({coef-error:.3f}, {coef+error:.3f})')
    print(np.round(corel,3))
    return best_pars, shift, scale,0,0#, bkg, sigma_bkg

if __name__ == '__main__':
    with fits.open(
        r'C:\Users\xwc\Desktop\IPython Notebook\GRB210822A'
        r'\GECAM\gbg_evt_tn210822_091818_gb_v00.fits'
    ) as hdul:
        evt = hdul['EVENTS21'].data
        evt = evt[evt['PI'] == 128]#128
        
    pars, s, f, bkg, sigma_bkg = by_minimization(
        evt['TIME'], 83323103.75, [-55.25, -16.25,  44.75, 141.75], [-15.75,  44.25],
        dt=1, order=2
    )