# test_gecam: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
from gecam.data.binned import BinnedFile
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
import matplotlib.pyplot as plt
from gecam.data.spec import SpecFile
from gecam.data.detector import GRD

file_path = r'E:\gecamTools\test_gecam\gbg_btime_bn221015_021354_v00.fits'
file_path = r"E:\gecamTools\test_gecam\gbg_bspec_bn221015_021354_v00.fits"
file_path=r"C:\Users\10500\Documents\WeChat Files\wxid_6638676386812\FileStorage\File\2023-03\gcg_bspec_221015_05_v00.fits"

bin_file = BinnedFile.open(file_path)
# trig_met = 119499284
trig_met=56352504.83+1500
time_bin = 1
channel_bin = 5
bg_time_range_list = [[trig_met - 100, trig_met - 40],
                      [trig_met + 50, trig_met + 100]]
# 定义源时间段
src_time_range = [trig_met + 1, trig_met + 9]

lc_kwargs_dic = {
    "time_bin": 1,
}
fig_kwargs_dic = {
    "bg_range": bg_time_range_list,
    "src_range": src_time_range
}

# bin_file.plot_light_curve([GRD(1)], channel_range=[0, 300], lc_kwargs_dic=lc_kwargs_dic,fig_kwargs_dic=fig_kwargs_dic)
# plt.show()

det_btime = bin_file.select_detector(1)

det_btime_sliced = det_btime.slice(gain_type="low")

det_sliced_lc = det_btime_sliced.to_light_curve(time_bin=time_bin, channel_bin=channel_bin, correct_by_dead_time=True)
# 本底拟合，拟合阶次为2
det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=1)
# # 提取源时间段的光变
det_src_lc = det_btime_sliced.to_light_curve(time_bin=time_bin,
                                             channel_bin=channel_bin,
                                             correct_by_dead_time=True)

# det_sliced_lc_fig = LightCurveFigure(det_sliced_lc.get_plot_data(), trig_time=trig_met,
#                                      satellite=bin_file.info.satellite_full_name)
# det_sliced_lc_fig.add_background(det_sliced_bg_lc.get_plot_data(),
#                                  bg_time_range=det_sliced_bg_lc.bg_time_range)
# det_sliced_lc_fig.add_selection(det_src_lc.get_plot_data())
#
# det_sliced_lc_fig.set_title(f"{bin_file.info.satellite_full_name}\n{bin_file.info.file_type}")
#
# plt.show()

det_sliced_spectrum = det_btime.to_spectrum(gain_type="low")
det_sliced_spectrum_fig = SpectrumFigure(det_sliced_spectrum.get_plot_data())
plt.show()

spec_file = SpecFile(det_sliced_lc, det_sliced_bg_lc)
# 添加第一个源时间段
spec, bg_spec, net_spec = spec_file.add_src(src_time_range)

# 能谱对应的响应文件
rsp_path = "test.rsp"
out_dir = r"E:\gecamTools\test_gecam/spec_file_btime/"
spec_file.write(out_dir, rsp_path=rsp_path)
