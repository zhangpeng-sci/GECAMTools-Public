from gecam.data.binned import BinnedFile
from gecam.data.evt import Evt
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
import matplotlib.pyplot as plt
from gecam.data.spec import SpecFile

file_path = r'E:\gecamTools\test_gecam\gbg_btime_bn221015_021354_v00.fits'
# file_path = r"E:\gecamTools\test_gecam\gbg_bspec_bn221015_021354_v00.fits"
file_path = r"E:\gecamTools\test_hebs\gcg_evt_221014_19_v01.fits"

bin_file = Evt.open(file_path)
trig_met = bin_file.info.trig_met
trig_met = 56314731.0 + 2700
time_bin = 1
bg_time_range_list = [[trig_met - 100, trig_met - 40],
                      [trig_met + 50, trig_met + 100]]
# 定义源时间段
src_time_range = [trig_met - 1, trig_met + 9]

det_events = bin_file.select_detector(1)

det_sliced_events = det_events.slice(gain_type="high", only_recommend=True)

det_sliced_lc = det_sliced_events.to_light_curve(time_bin=time_bin, correct_by_dead_time=True)
# 本底拟合，拟合阶次为2
det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=1)
# # 提取源时间段的光变
det_src_lc = det_sliced_events.to_light_curve(time_range=src_time_range,  time_bin=time_bin,
                                              correct_by_dead_time=True)

det_sliced_lc_fig = LightCurveFigure(det_sliced_lc.get_plot_data(), trig_time=trig_met,
                                     satellite=bin_file.info.satellite_full_name)
det_sliced_lc_fig.add_background(det_sliced_bg_lc.get_plot_data(),
                                 bg_time_range=det_sliced_bg_lc.bg_time_range)
det_sliced_lc_fig.add_selection(det_src_lc.get_plot_data())

det_sliced_lc_fig.set_title(f"{bin_file.info.satellite_full_name}\n{bin_file.info.file_type}")

plt.show()

# det_sliced_spectrum = det_btime.to_spectrum(gain_type="high")
# det_sliced_spectrum_fig = SpectrumFigure(det_sliced_spectrum.get_plot_data())
# plt.show()

spec_file = SpecFile(det_sliced_lc, det_sliced_bg_lc)
# 添加第一个源时间段
spec, bg_spec, net_spec = spec_file.add_src(src_time_range)

# 能谱对应的响应文件
rsp_path = "test.rsp"
out_dir = r"E:\gecamTools\test_gecam/evt_file/"
spec_file.write(out_dir, rsp_path=rsp_path)
