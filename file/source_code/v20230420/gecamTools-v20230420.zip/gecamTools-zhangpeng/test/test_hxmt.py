# test_hxmt: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import matplotlib.pyplot as plt
from gecam.data.hxmt_evt import EvtHxmt
from gecam.plot.light_curve import LightCurveFigure
from gecam.data.spec import SpecFile
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.detector import Detector, HE, LE

evt = EvtHxmt.open(r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\HEB221009553_HE-Evt.fits")

trig_met = evt.info.trig_met
time_range = [trig_met - 50, trig_met + 80]

evt.plot_light_curve_with_detectors([HE(1), HE(2)])

det_events = evt.select_detector(1)

det_sliced_events = det_events.slice(time_range=time_range)

time_bin = 1
channel_bin = 4

det_sliced_lc = det_sliced_events.to_light_curve(time_bin=time_bin, channel_bin=channel_bin,
                                                 correct_by_dead_time=r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\DeadTime_Proportion.txt")

bg_time_range_list = [[trig_met - 40, trig_met - 30],
                      [trig_met + 25, trig_met + 60]]

# 本底拟合，拟合阶次为2
det_sliced_bg_lc = det_sliced_lc.fit_background(bg_time_range_list, fit_order=1)

src_time_range = [trig_met - 1, trig_met + 7]
# 提取源时间段的光变
det_src_lc = det_sliced_events.to_light_curve(src_time_range, time_bin, channel_bin,
                                              correct_by_dead_time=r"E:\gecamTools\test_hxmt\HXMT_HE\HEB221009553\DeadTime_Proportion.txt")

det_sliced_lc_fig = LightCurveFigure(det_sliced_lc.get_plot_data(), trig_time=trig_met,
                                     satellite=evt.info.satellite_full_name)
# # 画出本底
det_sliced_lc_fig.add_background(det_sliced_bg_lc.get_plot_data(),
                                 bg_time_range=det_sliced_bg_lc.bg_time_range)
# 画出源时间段的阴影
det_sliced_lc_fig.add_selection(det_src_lc.get_plot_data())
det_sliced_lc_fig.show_legend()
det_sliced_lc_fig.set_title(evt.info.satellite_full_name)
plt.show()

src_time_range = [trig_met - 1, trig_met + 9]
spec_file = SpecFile(det_sliced_lc, det_sliced_bg_lc)
# 添加第一个源时间段
spec, bg_spec, net_spec = spec_file.add_src(src_time_range)

# 画出能谱文件的数据（当前选择第一段源时间段的能谱）
spec_fig = SpectrumFigure()
spec_fig.add_data(spec.get_plot_data(), color="#474747", err_color="#474747", label="full-spec", linewidth=1)
spec_fig.add_data(bg_spec.get_plot_data(), color="#0c5da5", err_color="#0c5da5", label="bg-spec", linewidth=1)
spec_fig.add_data(net_spec.get_plot_data(), color="#16bf55", err_color="#16bf55", label="net-spec", linewidth=1)
# 截断显示
spec_fig.set_xlim([0, 200])
spec_fig.show_legend()
plt.show()

# 能谱对应的响应文件
rsp_path = "test.rsp"
out_dir = r"E:\gecamTools\test_hxmt\HXMT_HE/"
spec_file.write(out_dir, rsp_path=rsp_path)
