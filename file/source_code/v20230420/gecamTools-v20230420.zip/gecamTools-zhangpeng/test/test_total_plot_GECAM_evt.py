# test_total_plot: 
#
#     Authors: Peng Zhang (IHEP), Yanqiu Zhang (IHEP)
#              Wangchen Xue (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import matplotlib.pyplot as plt
from gecam.data.evt import Evt
from gecam.plot.light_curve import LightCurveFigure
from gecam.data.spec import SpecFile
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.detector import Detector, GRD

file_path = "D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
# 读取HXMT的事例文件
evt = Evt.open(file_path)

trig_met = evt.info.trig_met
chooose_det = [GRD(18, gain_type="both"), GRD(19, gain_type="high")]
slice_kwargs_dic = {
    "time_range": [trig_met - 50, trig_met + 60],
    "channel_range": [0, 498],
    "only_recommend": True
}

lc_kwargs_dic = {
    "time_bin": 1,
    "channel_bin": [0,498],
    "correct_by_dead_time": True,
}
fig_kwargs_dic = {
    "bg_range": [[trig_met - 40, trig_met - 30], [trig_met + 30, trig_met + 40]],
    "src_range": [trig_met - 5, trig_met + 12]
}

# # 画多探头的叠加光变
total_lc_obj, dets_lc_list, lc_data, lc_fig = evt.plot_light_curve_with_detectors(chooose_det, slice_kwargs_dic,
                                                                                  lc_kwargs_dic, fig_kwargs_dic)

plt.show()

# 获取触发事例数据中的触发时间
trig_met = evt.info.trig_met
# 选择多个探头，例：GRD18（包含高低增益），GRD19(高增益)
chooose_det=[GRD(18,gain_type="both"), GRD(19,gain_type="high")]

# 光变的整体时间区间
lc_time_range = (trig_met - 50, trig_met + 60)
# 源时间区间
src_time_range = (trig_met - 5, trig_met+12)
src_time_range2 = (trig_met + 9, trig_met + 15)
# 多段本底的时间区间
bg_time_range_list = [[trig_met - 40, trig_met - 30],[trig_met +30, trig_met +40]]
# 光变的时间bin，单位：秒
time_bin = 1

# 是否选取推荐事例，True:只选取推荐事例  False:选取全部事例
only_recommend = True

lc_data, lc_fig = evt.plot_light_curve(chooose_det, time_range=lc_time_range, time_bin=time_bin,
                                       only_recommend=only_recommend, src_range=src_time_range,
                                       bg_range=bg_time_range_list)

plt.show()


#
spec_kwargs_dic = {
    "channel_bin": 1
}
fig_kwargs_dic = {}

# 画多探头的叠加的能谱
total_spec_obj, dets_spec_list, plot_spec_data, spec_fig = evt.plot_spectrum_with_detectors([HE(1), HE(2)],
                                                                                            slice_kwargs_dic,
                                                                                            spec_kwargs_dic,
                                                                                            fig_kwargs_dic)
plt.show()

lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 40, trig_met - 30], [trig_met + 25, trig_met + 60]],
    "fit_order": 1,
}
spec_file_kwargs_dic = {
    "src_range_list": [
        [trig_met - 5, trig_met - 1],
        [trig_met - 5, trig_met + 9],
        [trig_met - 5, trig_met + 4],
        [trig_met + 4, trig_met + 10]
    ],
    "rsp_list": ["test.rsp", "test.rsp", "test.rsp", "test.rsp"],
    "out_dir": "E:/gecamTools/test_spec_gecam_evt/"
}

a = evt.generate_spec_file_with_detecotrs(chooose_det, slice_kwargs_dic, lc_kwargs_dic,
                                          lc_bg_fit_kwargs_dic, spec_file_kwargs_dic)

print(1)
