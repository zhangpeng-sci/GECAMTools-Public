# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/09/24/0024 10:35
@Version:1.0
@Desc   :


"""
import numpy as np
import matplotlib.pyplot as plt


channel_max = 100
channel_bin = 4
channels_min = np.arange(0, channel_max, channel_bin)
channels_max = np.arange(channel_bin, channel_max + channel_bin, channel_bin)
channels_max[-1] = channel_max
a = np.vstack((channels_min, channels_max)).transpose()

counts_list = np.arange(1, 100000, 1000)

if type(counts_list) in [list, np.ndarray]:
    print(1)

time_bin = 0.128

result = []
result_x = []
for counts in counts_list:
    exposure = time_bin - 4e-6 * counts

    exposure_rate = exposure / time_bin

    result.append(exposure_rate)
    result_x.append(counts)

print(result)

plt.plot(result_x, result)
plt.show()
