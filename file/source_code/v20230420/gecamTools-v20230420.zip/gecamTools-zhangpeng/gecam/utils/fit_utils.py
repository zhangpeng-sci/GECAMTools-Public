
from numpy import polyfit, poly1d
import numpy as np
from numpy import exp, log
from numpy.polynomial import Polynomial
from scipy.stats import chi2


def goodness_of_fit(y, y_fit):
    """
    calculate goodness of Fit
    :param y: np.array

    :param y_fit: np.array

    :return:
        goodness of Fit R^2

        R^2= ssr/sst

        ssr(Sum of Squares forregression)
        sst(Sum of Squares fortotal)

    """

    ssr = np.sum(np.square(y_fit - y.mean()))

    sst = np.sum(np.square((y - y.mean())))

    return (ssr / sst).round(4)


def get_poly_fit_func(x, y, y_error=None, fit_order: int = 2):
    """
    fitting of polynomial
    :param x: 1D np.array
    :param y: 1D np.array
    :param y_error: 1D np.array, error of y
    :param fit_order: Degree of the fitting polynomial
    :return:
            fit_function
    """
    # The diagonal of cov matrix is the individual variance of each parameter, and the non-diagonal is the covariance.
    params, cov = polyfit(x, y, w=y_error, deg=fit_order, cov=True)

    # The "fitting error" is the square root of the variance of each parameter
    params_error = np.sqrt(np.diag(cov))
    # print(params)
    # print(cov)
    # print(params_error)

    fit_func = poly1d(params)
    # fit_func_error = poly1d(params_error)

    return fit_func, params, params_error

#
# def _model_rate(pars, t):
#     """
#     This function returns background model count rate at each background ``t``
#     point. The background model here is a polynomial on the exponential of `e`:
#
#     .. math::
#
#         f(t) = \exp(b_0 t^0 + b_1 t^1 + \cdots + b_n t^n)
#
#     where :math:`b_0, b_1, \cdots, b_n` is given by ``pars``.
#
#     Parameters
#     ----------
#     pars : array_like
#         The parameters of the background model.
#     t : array_like
#         Time series at which background model to be evaluated.
#
#     Returns
#     -------
#     model_rate : array
#         Background model count rate corresponding to the given ``pars`` at each
#         ``t`` point.
#
#     """
#
#     return exp(Polynomial(pars)(t))
#
#
# def _negative_log_likelihood(pars, t, tbin, bkg_data):
#     """
#     This function returns the negative logarithm of Poisson likelihood of
#     background model at each ``t`` point, given the background model parameters
#     (``pars``), time bin widths (``tbin`` with dead time correction considered)
#     and background count data (``bkg_data``).
#
#     The negative logarithm of Poisson likelihood is:
#
#     .. math::
#
#         -\ln L_i = -D_i \ln M_i + M_i + \ln D_i!
#
#     where :math:`D_i` is background count data and :math:`M_i` is count
#     predicted from background model.
#
#     Parameters
#     ----------
#     pars : array_like
#         The parameters of the background model, passed from background fitter.
#     t : array_like
#         Time series at which background model and likelihood to be evaluated.
#     tbin : array_like
#         Time bin widths corresponding to each ``t`` point, with dead time
#         correction considered.
#     bkg_data : array_like
#         Background count data of each ``t`` point, with dead time correction
#         considered.
#     Returns
#     -------
#     log_likelihood : array_like
#         Logarithm of poisson likelihood of the given parameters at each ``t``
#         point.
#
#     """
#
#     # get parameters value that passed from background fitter (lmfit.minimize)
#     pars = list(pars.valuesdict().values())
#
#     # compute the background model count through multiplying count rate by
#     # effective exposure time
#     bkg_model = _model_rate(pars, t) * tbin
#
#     # note that here we drop the term log(bkg_data!) from the log likelihood
#     # expression, since it has nothing to do with the model
#     return bkg_model - bkg_data * log(bkg_model)
#
#
# def background_fitter(t, tbin, bkg_data, bkg_intervals, order, dt=None):
#     """
#     This function fits the background count light curve by using maximum
#     likelihood estimation, and returns the background model count and error
#     (without dead time correction) at each ``t`` point corresponding to time
#     bin widths ``tbin``.
#
#     Parameters
#     ----------
#     t : array_like
#         Time series at which background to be modeled.
#     tbin : array_like
#         Time bin widths corresponding to each ``t`` point.
#     bkg_data : array_like
#         Background count data of each ``t`` point.
#     bkg_intervals : list
#         List of background time intervals to fit, for example, ``bkg_intervals=
#         [(-5, -3), (3.2, 7.0)]``.
#     order : int
#         Polynomial order, note that the polynomial here is on the exponential
#         of `e`.
#     dt : array_like, optional
#         Dead time of each time bin.
#
#     Returns
#     -------
#     bkg_model : array
#         Background model count at each ``t`` point.
#     sigma_bkg_model : array
#         Background model count error at each ``t`` point, note that this is
#         gaussian error of the background model, which should not be confused
#         with the fact that the background data are Poisson distributed.
#     goodness_of_fit: tuple
#         Reduced Pearson chi-sqaure and corresponding p-value.
#
#     """
#     from lmfit import minimize, Parameters
#
#     # initialize an array to store background data filter
#     mask = np.full_like(t, fill_value=False, dtype=bool)
#     # filter background data for fitting
#     for interval in bkg_intervals:
#         _tmp = (interval[0] <= (t - tbin / 2)) & ((t + tbin / 2) <= interval[1])
#         mask = mask | _tmp
#     t_mask = t[mask]
#     # dead time correction of tbin_mask
#     tbin_mask = tbin[mask] if dt is None else tbin[mask] - dt[mask]
#     bkg_data_mask = bkg_data[mask]
#
#     # return if no background data to fit
#     if all(bkg_data == 0):
#         bkg_model = np.zeros_like(t)
#         sigma_bkg_model = np.zeros_like(t)
#         reduced_pchisq = 0
#         p_value = 1
#         return bkg_model, sigma_bkg_model, (reduced_pchisq, p_value)
#
#     # adjust t and tbin_mask to [-1, 1], so that the evaluation of background
#     # model will not exceed memory limit
#     shift = (max(t_mask) + min(t_mask)) / 2
#     t_mask_adj = t_mask - shift
#     scale = 1 / max(abs(t_mask_adj))
#     t_mask_adj = scale * t_mask_adj
#     tbin_mask_adj = scale * tbin_mask
#
#     # degree of freedom
#     dof = len(t_mask_adj) - (order + 1)
#
#     # initial values of pars
#     init_vals = [0] * (order + 1)
#     init_pars = [(f'b{n}', bn) for n, bn in enumerate(init_vals)]
#     # initialize pars
#     pars = Parameters()
#     pars.add_many(*init_pars)
#
#     # fit background model by minimizing negative log likelihood
#     res = minimize(
#         fcn=_negative_log_likelihood,
#         params=pars,
#         method='powell',
#         args=(t_mask_adj, tbin_mask_adj, bkg_data_mask),
#         reduce_fcn=lambda l: 2 * np.sum(l) / dof,  # C-statistics
#         calc_covar=False,
#         max_nfev=10000
#     )
#
#     # get best-fit pars
#     best_pars = np.array(list(res.params.valuesdict().values()))
#     model_mask = _model_rate(best_pars, t_mask_adj) * tbin_mask_adj
#
#     # goodness of fit, i.e. reduced Pearson chi-sqaure and corresponding
#     # p-value
#     pearson_chisq = np.sum((bkg_data_mask - model_mask) ** 2 / model_mask)
#     reduced_pchisq = pearson_chisq / dof
#     p_value = chi2(dof).sf(pearson_chisq)
#
#     # by inverting the Fisher Information Matrix (FIM) of likelihood function,
#     # the covariance of best-fit pars can be obtained
#     vec_t_mask_adj = np.array([t_mask_adj ** i for i in range(order + 1)])
#     vec_t_mask_adj_i = (vec_t_mask_adj).reshape(order + 1, 1, -1)
#     vec_t_mask_adj_j = (vec_t_mask_adj).reshape(1, order + 1, -1)
#     # vec_t_mask_adj_i*vec_t_mask_adj_j gives a (order + 1, order + 1, len(t))
#     # shape array
#     fim = np.sum(
#         (vec_t_mask_adj_i * vec_t_mask_adj_j) * model_mask,
#         axis=-1
#     )
#     covar = np.linalg.inv(fim)
#
#     # compute model value (without dead time correction) at each t point
#     t_adj = scale * (t - shift)
#     tbin_adj = scale * tbin
#     bkg_model = _model_rate(best_pars, t_adj) * tbin_adj
#     vec_t_adj = np.array([t_adj ** i for i in range(order + 1)])
#     bkg_model = np.exp(np.dot(vec_t_adj.T, best_pars)) * tbin_adj
#
#     # compute model error (without dead time correction) by error propagation
#     sigma_bkg_model = np.sqrt(
#         np.sum(vec_t_adj * np.dot(covar, vec_t_adj), 0) * bkg_model
#     )
#
#     return bkg_model, sigma_bkg_model, (reduced_pchisq, p_value)


class BackgroundFitter:
    """
        Author: xuewc(IHEP)


    """
    def _model_rate(self, pars, t):
        """
        This function returns background model count rate at each background ``t``
        point. The background model here is a polynomial on the exponential of `e`:

        .. math::

            f(t) = \exp(b_0 t^0 + b_1 t^1 + \cdots + b_n t^n)

        where :math:`b_0, b_1, \cdots, b_n` is given by ``pars``.

        Parameters
        ----------
        pars : array_like
            The parameters of the background model.
        t : array_like
            Time series at which background model to be evaluated.

        Returns
        -------
        model_rate : array
            Background model count rate corresponding to the given ``pars`` at each
            ``t`` point.

        """

        return exp(Polynomial(pars)(t))

    def _negative_log_likelihood(self, pars, t, tbin, bkg_data, *args):
        """
        This function returns the negative logarithm of Poisson likelihood of
        background model at each ``t`` point, given the background model parameters
        (``pars``), time bin widths (``tbin`` with dead time correction considered)
        and background count data (``bkg_data``).

        The negative logarithm of Poisson likelihood is:

        .. math::

            -\ln L_i = -D_i \ln M_i + M_i + \ln D_i!

        where :math:`D_i` is background count data and :math:`M_i` is count
        predicted from background model.

        Parameters
        ----------
        pars : array_like
            The parameters of the background model, passed from background fitter.
        t : array_like
            Time series at which background model and likelihood to be evaluated.
        tbin : array_like
            Time bin widths corresponding to each ``t`` point, with dead time
            correction considered.
        bkg_data : array_like
            Background count data of each ``t`` point, with dead time correction
            considered.
        Returns
        -------
        log_likelihood : array_like
            Logarithm of poisson likelihood of the given parameters at each ``t``
            point.

        """

        # compute the background model count through multiplying count rate by
        # effective exposure time
        bkg_model = self._model_rate(pars, t) * tbin

        # note that here we drop the term log(bkg_data!) from the log likelihood
        # expression, since it has nothing to do with the model
        return sum(bkg_model - bkg_data * log(bkg_model))

    def _jacobian(self, pars, t, tbin, bkg_data, t_to_the_n, t_to_the_mn):
        '''This is the Jacobian of the negative log likelihood'''
        bkg_model = self._model_rate(pars, t) * tbin
        jac = np.sum((bkg_model - bkg_data) * t_to_the_n, axis=1)
        return jac

    def _hessian(self, pars, t, tbin, bkg_data, t_to_the_n, t_to_the_mn):
        '''This is the Hessian of the negative log likelihood'''
        bkg_model = self._model_rate(pars, t) * tbin
        hess = np.sum(t_to_the_mn * bkg_model, axis=-1)
        return hess

    def fit(self, t, tbin, bkg_data, bkg_intervals, order, dt=None):
        """
        This function fits the background count light curve by using maximum
        likelihood estimation, and returns the background model count and error
        (without dead time correction) at each ``t`` point corresponding to time
        bin widths ``tbin``.

        Parameters
        ----------
        t : array_like
            Time series at which background to be modeled.
        tbin : array_like
            Time bin widths corresponding to each ``t`` point.
        bkg_data : array_like
            Background count data of each ``t`` point.
        bkg_intervals : list
            List of background time intervals to fit, for example, ``bkg_intervals=
            [(-5, -3), (3.2, 7.0)]``.
        order : int
            Polynomial order, note that the polynomial here is on the exponential
            of `e`.
        dt : array_like, optional
            Dead time of each time bin.

        Returns
        -------
        bkg_model : array
            Background model count at each ``t`` point.
        sigma_bkg_model : array
            Background model count error at each ``t`` point, note that this is
            gaussian error of the background model, which should not be confused
            with the fact that the background data are Poisson distributed.
        fit_report: tuple
            The first two elements are reduced Pearson chi-sqaure and corresponding p-value of the best-fit model.
            The third element is a boolean indicates whether or not the fitter exited successfully,
            and the last one is a description to the termination of the fitter.

        """
        from scipy.optimize import minimize

        # initialize an array to restore background data filter
        mask = np.full_like(t, fill_value=False, dtype=bool)
        # filter background data for fitting
        for interval in bkg_intervals:
            _tmp = (interval[0] <= (t - tbin / 2)) & ((t + tbin / 2) <= interval[1])
            mask = mask | _tmp
        t_mask = t[mask]
        # dead time correction of tbin_mask
        tbin_mask = tbin[mask] if dt is None else (tbin - dt)[mask]
        bkg_data_mask = bkg_data[mask]

        # return default values if no background data to fit
        if all(bkg_data == 0):
            bkg_model = np.zeros_like(t)
            sigma_bkg_model = np.zeros_like(t)
            reduced_pchisq = 0
            p_value = 1
            suc = True
            message = 'Optimization terminated due to no background data to fit.'
            fit_report = (
                bkg_model, sigma_bkg_model, (reduced_pchisq, p_value, suc, message)
            )
            return fit_report

        # adjust t and tbin_mask to [-1, 1], so that the evaluation of background
        # model will not exceed memory limit
        shift = (max(t_mask) + min(t_mask)) / 2
        t_mask_adj = t_mask - shift
        scale = 1 / max(abs(t_mask_adj))
        t_mask_adj = scale * t_mask_adj
        tbin_mask_adj = scale * tbin_mask

        # degree of freedom
        deg = (order + 1)
        dof = len(t_mask_adj) - deg

        # initial values of pars
        init_vals = np.zeros(deg)

        # initialize necessary args of jac and hess
        t_to_the_n = np.array([np.power(t_mask_adj, n) for n in range(deg)])
        t_to_the_mn = t_to_the_n.reshape(deg, 1, -1) * t_to_the_n.reshape(1, deg, -1)

        # since background fitting is a small-size problems, i.e., the number of
        # parameters are usually small, here we use the nearly exact trust-region
        # algorithm to minimize the negative log likelihood function
        res = minimize(
            fun=self._negative_log_likelihood,
            x0=init_vals,
            method='trust-exact',
            args=(
                t_mask_adj, tbin_mask_adj, bkg_data_mask,  # for -log likelihood
                t_to_the_n, t_to_the_mn  # for jac and hess
            ),
            jac=self._jacobian,
            hess=self._hessian,
            # options={'gtol': 1e-8}
            # terminate if gradient norm is less than gtol, this option will
            # somehow cause failure if gtol is too small and the data have every
            # low counts
        )

        # get fit result
        best_pars = res.x
        suc = res.success
        message = res.message

        # goodness of fit, i.e. reduced Pearson chi-sqaure and corresponding
        # p-value
        model_mask = self._model_rate(best_pars, t_mask_adj) * tbin_mask_adj
        pearson_chisq = np.sum((bkg_data_mask - model_mask) ** 2 / model_mask)
        reduced_pchisq = pearson_chisq / dof
        p_value = chi2(dof).sf(pearson_chisq)

        # by inverting the Hessian of the best-fit likelihood function, the
        # covariance of best-fit pars can be obtained
        covar = np.linalg.inv(res.hess)

        # compute model value (without dead time correction) at each t point
        t_adj = scale * (t - shift)
        tbin_adj = scale * tbin
        bkg_model = self._model_rate(best_pars, t_adj) * tbin_adj

        # compute model error (without dead time correction) by error propagation
        vec_t_adj = np.array([np.power(t_adj, n) for n in range(deg)])
        sigma_bkg_model = np.sqrt(
            np.sum(vec_t_adj * np.dot(covar, vec_t_adj), 0) * bkg_model
        )

        fit_report = (
            bkg_model, sigma_bkg_model, [reduced_pchisq, p_value, suc, message]
        )
        return fit_report


if __name__ == '__main__':
    fit_wrong_data = np.load(r"C:\Users\10500\PycharmProjects\GECAMTools\test\fit_wrong.npy")

    lc_x = fit_wrong_data[0]
    lc_y = fit_wrong_data[1]
    lc_deadtime = fit_wrong_data[2]

    time_bin = 0.01
    time_bins = np.ones(lc_x.shape) * time_bin

    fit_order = 2

    trig_met = 74431600.59999999
    bg_time_range_list = [[trig_met - 40, trig_met - 10], [trig_met + 25, trig_met + 50]]
    # background_fitter(lc_x, time_bins, lc_y, bg_time_range_list, fit_order, dt=lc_deadtime)
#
# if __name__ == '__main__2':
#     def simulate_bkg_data(pars, tbins):
#         '''
#         第一个返回值是事例到达时间, 第二个返回值是对应的tbins的真实模型值。
#         '''
#         tbins = (tbins[:-1] + tbins[1:]) / 2
#         bins_width = tbins[1] - tbins[0]
#         lambda_of_bins = np.exp(Polynomial(pars)(tbins)) * bins_width
#         counts = np.random.poisson(lambda_of_bins)
#         evt_time = []
#         for i in range(tbins.size):
#             evt_time.extend(np.random.uniform(tbins[i] - bins_width / 2, tbins[i] + bins_width / 2, counts[i]))
#         return evt_time, lambda_of_bins
#
#
#     # 模拟产生光变曲线并拟合
#     tbins = np.linspace(-1, 3, 1 + 20000)
#     bin_width = tbins[1] - tbins[0]
#     a = simulate_bkg_data([10, 0.1, -0.1], tbins=tbins)
#
#     evt = sorted(a[0])
#     bkg_data = np.histogram(a[0], tbins)[0]
#     t = (tbins[:-1] + tbins[1:]) / 2
#     tbin = np.full_like(t, bin_width)
#     dt = None
#     # background_fitter 运行时长测试, 实际运行时长与每个数据点的数值大小有关
#     # 0.1 K个数据点, 10.4 ms ± 189 µs per loop (mean ± std. dev. of 7 runs, 100 loops each)
#     #   1 K个数据点, 12.9 ms ± 360 µs per loop (mean ± std. dev. of 7 runs, 100 loops each)
#     #  10 K个数据点, 36 ms ± 1.47 ms per loop (mean ± std. dev. of 7 runs, 100 loops each)
#     # 100 K个数据点, 318 ms ± 7.41 ms per loop (mean ± std. dev. of 7 runs, 100 loops each)
#     res = background_fitter(
#         t, tbin, bkg_data, [[tbins[0], tbins[-1]]], 2, dt
#     )
#     model_counts = res[0]
#     model_sigma = res[1]
#
#     # 比较拟合值与真值的差异
#     import matplotlib.pyplot as plt
#
#     with plt.style.context(['science', 'ieee', 'no-latex']):
#         fig, axes = plt.subplots(
#             2, 1,
#             sharex=True,
#             gridspec_kw={'height_ratios': [1, 0.618]},
#         )
#         fig.subplots_adjust(hspace=0, wspace=0)
#         fig.align_ylabels(axes)
#         axes[0].errorbar(t, bkg_data, xerr=bin_width / 2, lw=0.618 ** 3, c='k', zorder=0, ds='steps-mid', label='data')
#         axes[0].errorbar(t, a[1], xerr=bin_width / 2, lw=0.618 ** 2, c='r', zorder=10, ds='steps-mid', label='true')
#         axes[0].errorbar(t, model_counts, model_sigma, xerr=bin_width / 2, fmt=' ', lw=0.618, c='#0000FF', zorder=9,
#                          label=r'$1\sigma$ CI', ds='steps-mid')
#         axes[0].errorbar(t, model_counts, 2.706 * model_sigma, xerr=bin_width / 2, lw=0.618, fmt=' ', c='#00FF00',
#                          label='90% CI', ds='steps-mid')
#         axes[0].legend()
#         axes[1].errorbar(t, model_counts - a[1], model_sigma, xerr=bin_width / 2, fmt=' ', lw=0.618, c='#0000FF',
#                          zorder=9, ds='steps-mid')
#         axes[1].errorbar(t, model_counts - a[1], 2.706 * model_sigma, xerr=bin_width / 2, lw=0.618, fmt=' ',
#                          c='#00FF00', ds='steps-mid')
#         axes[1].axhline(0, lw=0.618 ** 2, c='r', zorder=10)
#
#         plt.show()
