# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/10/10/0010 20:34
@Version:1.0
@Desc   :


"""
from gecam import config
from gecam.utils import file_utils


def save_fig(fig_obj, out_dir, file_name_pre, file_type_list=None):
    """
    save the plt fig
    :param fig_obj: plt.figure
    :param out_dir: out dir path
    :param file_name_pre:
    :param file_type_list: ["pnd","pdf"]
    :return:
    """
    if file_type_list is None:
        file_type_list = ["png"]

    if not out_dir.endswith("/"):
        out_dir += "/"

    file_utils.check_dir_exit(out_dir)

    for file_type in file_type_list:
        fig_obj.savefig(f"{out_dir}{file_name_pre}.{file_type}", dpi=config.IMG_SAVE_DPI)