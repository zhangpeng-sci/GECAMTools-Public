# -*- coding: utf-8 -*- 
"""
@Software: PyCharm
@Author :Peng Zhang
@Email  :zhangp97@ihep.ac.cn
@Date   :2021/10/11/0011 9:47
@Version:1.0
@Desc   :


"""
import numpy as np

from gecam import config
from gecam.data.detector import Detector
from gecam.generate import generate_fits


def generate_all_spec_fits(detector: Detector, spec, energys_min, energys_max, channel_range_list,
                           out_dir):
    """
    generate full,background,net spec fits

    :param detector: Detector object
    :param spec:(spec, spec_err, bg_spec, bg_spec_err, net_spec, net_spec_err)
    :param channel_range_list:list
        [
            [channel_start,channel_stop),  # range:   channel_start <=channel< channel_stop
        ]
    :param energys_min:np.ndarray
        min energy of each channel
    :param energys_max:np.ndarray
        max energy of each channel
    :param exposure_list:
    :param out_dir:
    :return:
    """
    spec_version = config.PROCESS_SPEC_VERSION

    detector_name = detector.full_name()

    energys_min, energys_max = energys_min[:], energys_max[:]
    c_len = energys_min.shape[0]

    (spec, spec_err, spec_expos, bg_spec, bg_spec_err, bg_spec_expos, net_spec, net_spec_err, net_spec_expos) = spec

    # assemble grouping
    spec_all, spec_err_all = np.zeros(c_len), np.zeros(c_len)
    bg_spec_all, bg_spec_err_all = np.zeros(c_len), np.zeros(c_len)
    net_spec_all, net_spec_err_all = np.zeros(c_len), np.zeros(c_len)
    grouping_all = np.zeros(c_len)
    for index, (c_start, c_stop) in enumerate(channel_range_list):
        c_start_index, c_stop_index = c_start, c_stop

        spec_all[c_start_index], spec_err_all[c_start_index] = spec[index], spec_err[index]
        bg_spec_all[c_start_index], bg_spec_err_all[c_start_index] = bg_spec[index], bg_spec_err[index]
        net_spec_all[c_start_index], net_spec_err_all[c_start_index] = net_spec[index], net_spec_err[index]

        grouping_all[c_start_index:c_stop_index] = -1
        grouping_all[c_start_index] = 1

    all_spec_path = f"{out_dir}full_spec_{detector_name}_{spec_version}.FITS"
    bg_spec_path = f"{out_dir}bg_spec_{detector_name}_{spec_version}.FITS"
    net_spec_path = f"{out_dir}net_spec_{detector_name}_{spec_version}.FITS"

    generate_fits.generate_spec_fits(detector_name, spec_all, spec_err_all, energys_min, energys_max,
                                     grouping_all, np.mean(spec_expos), all_spec_path)

    generate_fits.generate_spec_fits(detector_name, bg_spec_all, bg_spec_err_all, energys_min, energys_max,
                                     grouping_all, np.mean(bg_spec_expos),
                                     bg_spec_path)

    generate_fits.generate_spec_fits(detector_name, net_spec_all, net_spec_err_all, energys_min, energys_max,
                                     grouping_all,
                                     np.mean(net_spec_expos),
                                     net_spec_path)

    return all_spec_path, bg_spec_path, net_spec_path
