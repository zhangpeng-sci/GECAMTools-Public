# spec.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import numpy as np

import gecam
from gecam.data.curve import Spectrum, LightCurve, BackgroundLightCurve, NetLightCurve
from gecam.utils import ebounds_utils, file_utils
import warnings, os
from astropy.io import fits
from gecam.utils.base_utils import concat_dets_name


class SpecFile():

    def __init__(self, lc: LightCurve, bg_lc: BackgroundLightCurve):
        self.lc, self.bg_lc, self.net_lc = lc, bg_lc, NetLightCurve(lc, bg_lc)
        self.channel_bins, self.energy_bins = self.lc.channel_bins, self.lc.energy_bins

        self.detector = lc.detector
        self.ebounds = lc.ebounds
        self.evt_info = lc.evt_info

        self.spec_list = []
        self.net_spec_list = []
        self.bg_spec_list = []

    def _check_src_range(self, time_range, src_time_range):
        """
        check if the source range exceed total time range
        Args:
            time_range (list or np.ndarray or tuple):
            src_time_range (list or np.ndarray or tuple):

        Returns:

        """

        if src_time_range[0] < time_range[0] or src_time_range[1] > time_range[1]:
            raise Exception(
                f"Source time range:{src_time_range} exceed time range:{time_range} of selected light curve.")

    def add_src(self, src_range: list):
        """
        add a source time range
        Args:
            src_range (list): source time range

        Returns:
            full_spec,background_spec,net_spec

        """
        src_start, src_stop = src_range

        lc_time_bins, lc_y, _ = self.lc.get_data()
        _, bg_lc_y, _ = self.bg_lc.get_data()
        _, net_lc_y, _ = self.net_lc.get_data()
        lc_y_correct_deadtime = self.net_lc.total_lc_y_corrected

        self._check_src_range((lc_time_bins[0], lc_time_bins[-1]), src_range)

        exposure_on_bins = self.lc.exposure_on_bins

        src_start_index = np.where(lc_time_bins <= src_start)[0][-1]
        src_stop_index = np.where(lc_time_bins >= src_stop)[0][0]
        if src_stop_index - src_start_index <= 0:
            src_stop_index = src_start_index + 1

        src_time_range = [lc_time_bins[src_start_index], lc_time_bins[src_stop_index]]
        src_exposure_on_bins = exposure_on_bins[src_start_index:src_stop_index]

        src_exposure_sum = src_exposure_on_bins.sum()

        # cut source light curve
        src_lc_y = lc_y[:, src_start_index:src_stop_index]
        # src_bg_lc_y = bg_lc_y[:, src_start_index:src_stop_index]
        src_net_lc_y = net_lc_y[:, src_start_index:src_stop_index]

        # total spec
        spec_data = np.sum(src_lc_y, axis=1)
        spec_err = np.sqrt(spec_data)

        spec_data_correct_deadtime = np.sum(lc_y_correct_deadtime, axis=1)
        spec_err_correct_deadtime = np.sqrt(spec_data_correct_deadtime)

        # background spec
        bg_spec_data, bg_spec_err = self.bg_lc.background_fitter.interpolate(src_time_range[0], src_time_range[1],
                                                                             src_exposure_sum)
        bg_spec_data = bg_spec_data[:, 0]
        bg_spec_err = bg_spec_err[:, 0]

        # net spec
        net_spec_data = np.sum(src_net_lc_y, axis=1)
        net_spec_err = np.sqrt(spec_data + bg_spec_err * bg_spec_err)

        spec = Spectrum(self.detector, spec_data, spec_err, src_exposure_sum, src_time_range, self.channel_bins,
                        self.energy_bins, self.evt_info, corrected_deadtime=False)
        spec.add_spectrum_corrected_deadtime(spec_data_correct_deadtime, spec_err_correct_deadtime)

        bg_spec = Spectrum(self.detector, bg_spec_data, bg_spec_err, src_exposure_sum, src_time_range,
                           self.channel_bins, self.energy_bins, self.evt_info, corrected_deadtime=True)
        net_spec = Spectrum(self.detector, net_spec_data, net_spec_err, src_exposure_sum, src_time_range,
                            self.channel_bins, self.energy_bins, self.evt_info, corrected_deadtime=True)

        self.spec_list.append(spec), self.bg_spec_list.append(bg_spec), self.net_spec_list.append(net_spec)

        return spec, bg_spec, net_spec

    def write(self, out_dir, rsp_path=None):
        """
        write spec data to Fits include full, bg and net
        Args:
            rsp_path:
            out_dir: file save dir

        Returns:

        """
        spec_len = len(self.spec_list)
        if type(rsp_path) is not list:
            rsp_path_list = [rsp_path] * spec_len
        else:
            rsp_path_list = rsp_path

        if type(self.detector) == list:
            det_name = "multi-detectors"
            det_name_all = concat_dets_name(self.detector)
        else:
            det_name, det_name_all = self.detector.full_name, self.detector.full_name

        spec_version = gecam.get_software_version()

        file_utils.check_dir_exit(out_dir)

        full_spec_path = os.path.join(out_dir, f"full_spec_{det_name}_v{spec_version}.FITS")
        bg_spec_file_name = f"bg_spec_{det_name}_v{spec_version}.FITS"
        bg_spec_path = os.path.join(out_dir, bg_spec_file_name)
        net_spec_path = os.path.join(out_dir, f"net_spec_{det_name}_v{spec_version}.FITS")

        bg_spec_path_list = [bg_spec_file_name] * spec_len

        self._write_spec(det_name_all, self.ebounds, self.spec_list, rsp_path_list, bg_spec_path_list, full_spec_path)
        self._write_spec(det_name_all, self.ebounds, self.bg_spec_list, rsp_path_list, [None] * spec_len, bg_spec_path)
        self._write_spec(det_name_all, self.ebounds, self.net_spec_list, rsp_path_list, bg_spec_path_list,
                         net_spec_path)

    def _ensemble_spec_data(self, spec_list, rsp_path_list, bg_spec_path_list):
        """
        ensemble spec file data
        Args:
            spec_list:
            rsp_path_list:

        Returns:

        """

        f_spec_num, f_time, f_time_delta, f_channel, f_counts, f_counts_err, \
            f_grouping, f_quality, f_exposure, f_respfile, f_bg_spec_file = [], [], [], [], [], [], [], [], [], [], []

        quality = np.zeros(len(self.ebounds))
        if self.evt_info.file_type == "EVT" and self.evt_info.satellite_full_name in ["GECAM-A", "GECAM-B", "GECAM-C"]:
            # Attention: Masking channel greater than 448
            quality[448:] = 1
            warnings.warn("Mask channel Quality of GECAM-A/B/C (greater than 448) to 1.")

        for index, spec in enumerate(spec_list):

            grouping_flag, grouping_counts, grouping_counts_err = ebounds_utils.generate_grouping_by_channel_bins(
                self.ebounds,
                self.channel_bins,
                spec.counts, spec.counts_err)

            f_spec_num.append(index + 1)
            f_time.append(spec.time_range[0])
            f_time_delta.append(spec.time_range[1] - spec.time_range[0])
            # f_channel.append(self.ebounds[:,0])
            f_channel.append(self.ebounds.field("CHANNEL"))
            f_counts.append(grouping_counts)
            f_counts_err.append(grouping_counts_err)
            f_grouping.append(grouping_flag)
            f_quality.append(quality)
            f_exposure.append(spec.exposure)
            f_respfile.append(rsp_path_list[index])

            bg_spec_path = bg_spec_path_list[index]
            if bg_spec_path in [None, ""]:
                bg_spec_path = ""
            else:
                bg_spec_path += '{' + str(index + 1) + '}'

            f_bg_spec_file.append(bg_spec_path)

        return f_spec_num, f_time, f_time_delta, f_channel, f_counts, f_counts_err, f_grouping, \
            f_quality, f_exposure, f_respfile, f_bg_spec_file

    def _write_spec(self, det_name, ebounds, spec_list, rsp_path_list, bg_spec_path_list, out_path):

        spec_num, time, time_delta, channel, counts, counts_err, grouping, quality, exposure, \
            respfile, bg_spec_file = self._ensemble_spec_data(spec_list, rsp_path_list, bg_spec_path_list)

        gti_start = []
        gti_stop = []
        for spec in spec_list:
            gti_start.append(spec.time_range[0])
            gti_stop.append(spec.time_range[1])

        data_len = len(counts[0])
        channel_len = len(ebounds)

        hdu0 = fits.PrimaryHDU()
        creator = f"{gecam.get_software_name()}_v{gecam.get_software_version()}"
        hdu0.header['CREATOR'] = (creator, 'Software and version creating file')

        col_channel = fits.Column(name='CHANNEL', format='1I', array=ebounds.field("CHANNEL"))
        col_e_min = fits.Column(name='E_MIN', format='1E', array=ebounds.field("E_MIN"))
        col_e_max = fits.Column(name='E_MAX', format='1E', array=ebounds.field("E_MAX"))
        hdu_ebounds = fits.BinTableHDU.from_columns([col_channel, col_e_min, col_e_max])
        hdu_ebounds.header['EXTNAME'] = ('EBOUNDS', 'name of this binary table extension')
        hdu_ebounds.header['TTYPE1'] = ('CHANNEL ', '')
        hdu_ebounds.header['TFORM1'] = ('I', '')
        hdu_ebounds.header['TUNIT1'] = ('  ', 'physical unit of field')

        hdu_ebounds.header['TTYPE2'] = ('E_MIN', '')
        hdu_ebounds.header['TFORM2'] = ('1E', '')
        hdu_ebounds.header['TUNIT2'] = ('keV', 'physical unit of field')

        hdu_ebounds.header['TTYPE3'] = ('E_MAX', '')
        hdu_ebounds.header['TFORM3'] = ('1E', '')
        hdu_ebounds.header['TUNIT3'] = ('keV', 'physical unit of field')

        col1 = fits.Column(name='SPEC_NUM', format='J', array=spec_num)
        col2 = fits.Column(name='TIME', format='D', unit="s", array=time)
        col3 = fits.Column(name='TIMEDEL', format='D', unit="s", array=time_delta)
        col4 = fits.Column(name='CHANNEL', format=f'{channel_len}I', unit="chan", array=channel)
        col5 = fits.Column(name='COUNTS', format=f'{data_len}J', unit="count", array=counts)
        col_stat_err = fits.Column(name='STAT_ERR', format=f'{data_len}D', array=counts_err)
        col6 = fits.Column(name='GROUPING', format=f'{channel_len}I', array=grouping)
        col7 = fits.Column(name='QUALITY', format=f'{channel_len}I', array=quality)
        col8 = fits.Column(name='EXPOSURE', format='D', unit="s", array=exposure)
        col9 = fits.Column(name='RESPFILE', format='150A', array=respfile)
        col10 = fits.Column(name='BACKFILE', format='150A', array=bg_spec_file)

        hdu1 = fits.BinTableHDU.from_columns(
            [col1, col2, col3, col4, col5, col_stat_err, col6, col7, col8, col9, col10])
        hdu1.header['LONGSTRN'] = ('OGIP 1.0', 'The HEASARC Long String Convention may be used')
        hdu1.header['EXTNAME'] = ('SPECTRUM', 'name of this binary table extension')
        hdu1.header['DETCHANS'] = (channel_len, 'Total no. detector channels available')
        hdu1.header['TELESCOP'] = ('GECAM', ' Telescope (mission) name')
        hdu1.header['INSTRUME'] = ('GRD', ' Instrument name')
        hdu1.header['DETNAME'] = (det_name, ' Name of the detector')

        # hdu1.header['STATERR'] = (False, 'no statisical error specified')
        hdu1.header['SYSERR'] = (0.0, 'no systematic error')
        # hdu1.header['POISSERR'] = (False, 'Poissonian statistical errors to be assumed')

        hdu1.header['GROUPING'] = (1, 'grouping of the data has been defined')
        # hdu1.header['QUALITY'] = (0, 'data quality information specified')
        hdu1.header['PHAVERSN'] = ('1992a', 'OGIP classification of FITS format')

        hdu1.header['AREASCAL'] = (1, 'area scaling factor')
        hdu1.header['BACKSCAL'] = (1.0000000000E+00, 'background scaling factor')
        hdu1.header['CORRSCAL'] = (1.0000000000E+00, 'correlation scaling factor')
        hdu1.header['ANCRFILE'] = ('NONE', 'ARF')

        hdu2_col1 = fits.Column(name='START', format='D', unit="s", array=gti_start)
        hdu2_col2 = fits.Column(name='STOP', format='D', unit="s", array=gti_stop)
        hdu2 = fits.BinTableHDU.from_columns([hdu2_col1, hdu2_col2])
        hdu2.header['LONGSTRN'] = ('OGIP 1.0', 'The HEASARC Long String Convention may be used')
        hdu2.header['EXTNAME'] = ('GTI', 'name of this binary table extension')
        hdu2.header['DETCHANS'] = (channel_len, 'Total no. detector channels available')
        hdu2.header['TELESCOP'] = ('GECAM', ' Telescope (mission) name')
        hdu2.header['INSTRUME'] = ('GRD', ' Instrument name')
        hdu2.header['DETNAME'] = (det_name, ' Name of the detector')
        hdu2.header['PHAVERSN'] = ('1992a', 'OGIP classification of FITS format')

        fits_obj = fits.HDUList([hdu0, hdu_ebounds, hdu1, hdu2])

        if out_path is not None:
            fits_obj.writeto(out_path, overwrite=True)
        else:
            return fits_obj
