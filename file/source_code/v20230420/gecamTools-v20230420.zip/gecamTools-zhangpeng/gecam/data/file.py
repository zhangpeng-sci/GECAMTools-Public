#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import os.path
import warnings, copy
from collections import OrderedDict
from astropy.io import fits
import numpy as np

from gecam import config
from gecam.data.base import EvtInfo
from gecam.utils import curve_utils, ebounds_utils
from gecam.data.detector import Detector, HE, LE
from gecam.data.curve import Spectrum, ChannelLightCurve, LightCurve
from gecam.plot.light_curve import LightCurveFigure
from gecam.plot.spectrum import SpectrumFigure
from gecam.data.spec import SpecFile
from gecam.utils.base_utils import concat_dets_name


class DataFile:
    def _file_properties(self, file_path, ignore_file_check=False):

        if not ignore_file_check:
            if not os.path.exists(file_path):
                raise IOError("File {0} does not exist".format(file_path))

        self._file_path = file_path
        self._file_dir = os.path.dirname(file_path)
        self._file_name = os.path.basename(file_path)

    def _get_satellite_name_by_telescope(self, telescope):
        if telescope is None:
            return ""

        if telescope == "HEBS":
            return "c"

        return telescope.lower()[-1]


class EngDataFile(DataFile):

    def __init__(self):
        pass


class SciDataFile(DataFile):
    """
    Science data file object
    """

    def __init__(self):
        self.info = None

    def select_detector(self, det_num):
        pass

    def match_det_channel_and_rsp(self, det: Detector, channel_bins, rsp):
        """
        match detector, chanenl and rsp file path
        Args:
            det (Detector): Detector list
            channel_bins (list): [ channel_bins_high_gain, channel_bins_low_gain ]
            rsp (list): [ rsp_high_gain, rsp_low_gain ]

        Returns:

        """
        if type(channel_bins) is int:
            channel_bins = [channel_bins, channel_bins]

        channel_bins_high_gain, channel_bins_low_gain = channel_bins
        if rsp is not None:
            rsp_high_gain, rsp_low_gain = rsp
        else:
            rsp_high_gain, rsp_low_gain = "", ""

        det_gain_type = det.gain_type

        result = []

        if det_gain_type == "high":
            result.append([det_gain_type, channel_bins_high_gain, rsp_high_gain])
        elif det_gain_type == "low":
            result.append([det_gain_type, channel_bins_low_gain, rsp_low_gain])
        else:
            result.append(["high", channel_bins_high_gain, rsp_high_gain])
            result.append(["low", channel_bins_low_gain, rsp_low_gain])

        return result

    def generate_light_curve_with_detectors(self, detectors: Detector or list, slice_kwargs_dic=None,
                                            lc_kwargs_dic: dict = None, lc_bg_fit_kwargs_dic=None):

        if slice_kwargs_dic is None:
            slice_kwargs_dic = {}
        if lc_kwargs_dic is None:
            lc_kwargs_dic = {}
        if lc_bg_fit_kwargs_dic is None:
            lc_bg_fit_kwargs_dic = {}

        this_lc_kwargs_dic = copy.deepcopy(lc_kwargs_dic)
        dets = []
        dets_lc_list = []
        dets_bg_lc_list = []

        for det in detectors:
            det.set_satellite(self.info.satellite)
            if det.gain_type in det.unique_gain_type_list():
                gain_type_list = [det.gain_type]
            else:
                gain_type_list = det.unique_gain_type_list()

            # Calculate the high and low gains separately
            for gain_type in gain_type_list:
                det_events = self.select_detector(det.number)
                det_events.detector.set_gain_type(gain_type)
                print(det_events.detector.full_name)
                dets.append(det_events.detector)

                det_events = det_events.slice(gain_type, **slice_kwargs_dic)
                det_lc = det_events.to_light_curve(**this_lc_kwargs_dic)
                dets_lc_list.append(det_lc)

                if len(lc_bg_fit_kwargs_dic) > 0:
                    det_bg_lc = det_lc.fit_background(**lc_bg_fit_kwargs_dic)
                    dets_bg_lc_list.append(det_bg_lc)

                this_lc_kwargs_dic["time_bin"] = det_lc.time_bins

        return dets, dets_lc_list, dets_bg_lc_list

    def plot_light_curve_with_detectors(self, detectors: Detector or list, slice_kwargs_dic=None,
                                        lc_kwargs_dic: dict = None, fig_kwargs_dic=None):
        """
        plot light curve of multiple detectors
        Args:
            detectors (Detector or list): List of Detector
            slice_kwargs_dic (dict):det_events.slice(**slice_kwargs_dic)
            lc_kwargs_dic (dict):det_events.to_light_curve(**lc_kwargs_dic)
            fig_kwargs_dic (dict):   ref_met, bg_range = fig_kwargs_dic.get("ref_met"), fig_kwargs_dic.get("bg_range"),
                                    src_range = fig_kwargs_dic.get("src_range")

        Returns:

        """
        if slice_kwargs_dic is None:
            slice_kwargs_dic = {}
        if fig_kwargs_dic is None:
            fig_kwargs_dic = {}
        if lc_kwargs_dic is None:
            lc_kwargs_dic = {}

        lc_x_bins, lc_y, lc_y_err, lc_dead_time = None, None, None, None

        _, dets_lc_list, _ = self.generate_light_curve_with_detectors(detectors, slice_kwargs_dic, lc_kwargs_dic)

        for det_lc in dets_lc_list:
            det_x_bins, det_y, _ = det_lc.get_data(channel_index=None)

            if lc_x_bins is None:
                lc_x_bins, lc_y, lc_dead_time = det_x_bins, det_y, det_lc.dead_time_on_bins
                # reuse the time bins of the first detector
            else:
                lc_dead_time += det_lc.dead_time_on_bins
                lc_y += det_y

        channel_bins, energy_bins = dets_lc_list[0].channel_bins, dets_lc_list[0].energy_bins
        dead_time_on_bins = lc_dead_time / len(dets_lc_list)
        lc_dets = [lc.detector for lc in dets_lc_list]

        c_lc_obj_list = []
        for index, c_counts in enumerate(lc_y):
            c_channel_range, c_energy_range = dets_lc_list[0].channel_bins[index:index + 2], \
                dets_lc_list[0].energy_bins[index:index + 2]
            c_lc_obj = ChannelLightCurve(lc_x_bins, c_counts, np.sqrt(c_counts), dead_time_on_bins,
                                         c_channel_range, c_energy_range)
            c_lc_obj_list.append(c_lc_obj)

        total_lc_obj = LightCurve(lc_dets, lc_x_bins, channel_bins, energy_bins, c_lc_obj_list,
                                  dead_time_on_bins, dets_lc_list[0].evt_info)

        img_x, img_y = lc_x_bins[:-1], np.sum(lc_y, axis=0) / np.diff(lc_x_bins)
        img_y_err = np.sqrt(np.sum(lc_y, axis=0)) / np.diff(lc_x_bins)
        plot_lc_data = (img_x, img_y, img_y_err)

        ref_met, bg_range = fig_kwargs_dic.get("ref_met"), fig_kwargs_dic.get("bg_range")
        src_range = fig_kwargs_dic.get("src_range")
        figure = LightCurveFigure(plot_lc_data, trig_time=self.info.trig_met, ref_time=ref_met,
                                  satellite=self.info.satellite_full_name)
        if bg_range is not None:
            figure.add_range_selection(bg_range)
        if src_range is not None:
            figure.add_range_selection([src_range], facecolor="#9a4e0e")

        x_label = figure.xlabel
        x_label += f"\nChannel range={slice_kwargs_dic.get('channel_range')}\nChoose detectors: {concat_dets_name(detectors, self.info.satellite)}"

        figure.set_title(self.info.satellite_full_name)
        figure.set_xlabel(x_label)

        return total_lc_obj, dets_lc_list, plot_lc_data, figure.fig

    def plot_spectrum_with_detectors(self, detectors: Detector or list, slice_kwargs_dic=None,
                                     spec_kwargs_dic: dict = None, fig_kwargs_dic=None):
        """
        plot spectrum of multiple detectors
        Args:
            detectors (Detector or list): List of Detector
            slice_kwargs_dic (dict):det_events.slice(**slice_kwargs_dic)
            spec_kwargs_dic (dict):det_events.to_light_curve(**lc_kwargs_dic)
            fig_kwargs_dic (dict):   ref_met, bg_range = fig_kwargs_dic.get("ref_met"), fig_kwargs_dic.get("bg_range"),
                                    src_range = fig_kwargs_dic.get("src_range")

        Returns:

        """
        if slice_kwargs_dic is None:
            slice_kwargs_dic = {}
        if fig_kwargs_dic is None:
            fig_kwargs_dic = {}
        if spec_kwargs_dic is None:
            spec_kwargs_dic = {}

        this_spec_kwargs_dic = copy.deepcopy(spec_kwargs_dic)
        dets_spec_list = []

        spec_channel_bins, spec_energy_bins, spec_y, spec_y_err, spec_exposure = None, None, None, None, None
        for det in detectors:
            det.set_satellite(self.info.satellite)
            if det.gain_type in det.unique_gain_type_list():
                gain_type_list = [det.gain_type]
            else:
                gain_type_list = det.unique_gain_type_list()
            if len(gain_type_list) == 0:
                gain_type_list = [None]

            # Calculate the high and low gains separately
            for gain_type in gain_type_list:
                det_events = self.select_detector(det.number)
                det_events.detector.set_gain_type(gain_type)
                print(det_events.detector.full_name)

                det_events = det_events.slice(gain_type, **slice_kwargs_dic)
                det_spec = det_events.to_spectrum(**this_spec_kwargs_dic)
                dets_spec_list.append(det_spec)
                det_x_channel_bins, det_x_energy_bins, det_y, _ = det_spec.get_data()

                if spec_channel_bins is None:
                    spec_channel_bins, spec_energy_bins, spec_y, spec_exposure = det_x_channel_bins, det_x_energy_bins, \
                        det_y, det_spec.exposure
                else:
                    spec_y += det_y
                    spec_exposure += det_spec.exposure

        spec_y_err = np.sqrt(spec_y)
        spec_exposure_avg = spec_exposure / len(dets_spec_list)
        channel_bins, energy_bins = dets_spec_list[0].channel_bins, dets_spec_list[0].energy_bins
        spec_dets = [spec.detector for spec in dets_spec_list]

        total_spec_obj = Spectrum(spec_dets, spec_y, spec_y_err, spec_exposure_avg, dets_spec_list[0].time_range,
                                  channel_bins, energy_bins, dets_spec_list[0].evt_info)

        plot_spec_data = total_spec_obj.get_plot_data()

        figure = SpectrumFigure(plot_spec_data)

        x_label = figure.xlabel
        x_label += f"\nChannel bin={this_spec_kwargs_dic.get('channel_bin', 1)}" \
                   f"\nChoose detectors: {concat_dets_name(detectors, self.info.satellite)}"

        figure.set_title(self.info.satellite_full_name)
        figure.set_xlabel(x_label)

        return total_spec_obj, dets_spec_list, plot_spec_data, figure.fig

    def generate_spec_file_with_detecotrs(self, det_list: [Detector], slice_kwargs_dic=None, lc_kwargs_dic=None,
                                          lc_bg_fit_kwargs_dic=None, spec_file_kwargs_dic=None):
        """
        generate spec file of multiple detectors

        Args:
            detectors (Detector or list): List of Detector
            slice_kwargs_dic (dict):det_events.slice(**slice_kwargs_dic)
            lc_kwargs_dic (dict):det_events.to_light_curve(**lc_kwargs_dic)
            lc_bg_fit_kwargs_dic:
                Examples:
                    lc_bg_fit_kwargs_dic = {
                        "bg_time_range": [[trig_met - 40, trig_met - 30], [trig_met + 25, trig_met + 60]],
                        "fit_order": 1,
                    }
            spec_file_kwargs_dic:
                Examples:
                    spec_file_kwargs_dic = {
                        "src_range_list": [
                            [trig_met - 5, trig_met - 1],
                            [trig_met - 5, trig_met + 9],
                            [trig_met - 5, trig_met + 4],
                            [trig_met + 4, trig_met + 10]
                        ],
                        "rsp_list": [["det1_high_gain.rsp", "det1_low_gain.rsp"],
                                     ["det2_high_gain.rsp", "det2_low_gain.rsp"]],
                        "out_dir": "/gecamTools/test_spec_gecam/"

        Returns:
            result (dict): spectrum data of each detector with differential gain,
                Examples
                Input:
                    lc_kwargs_dic = {
                        "time_bin": 1,
                        "channel_bin": [1, 1],  # [channel_bin_high_gain,channel_bin_low_gain]
                        "correct_by_dead_time": True,
                    }
                Output:

                            {
                                "bg01H": {
                                    "bg_lc":BackgroundLightCurve,
                                    "src_spec_list":[ src_range1, spec, bg_spec, net_spec ]
                                }
                            }

        """
        if slice_kwargs_dic is None:
            slice_kwargs_dic = {}
        if lc_kwargs_dic is None:
            lc_kwargs_dic = {}
        if spec_file_kwargs_dic is None:
            spec_file_kwargs_dic = {}
        if lc_bg_fit_kwargs_dic is None:
            lc_bg_fit_kwargs_dic = {}

        this_lc_kwargs_dic = copy.deepcopy(lc_kwargs_dic)

        result = {}

        bg_range_list, src_range_list = lc_bg_fit_kwargs_dic.get("bg_time_range"), spec_file_kwargs_dic.get(
            "src_range_list")
        temp_range = np.concatenate((np.array(bg_range_list).flatten(), np.array(src_range_list).flatten()))
        lc_total_range = [temp_range.min() - 1, temp_range.max() + 1]

        channel_bin_of_high_low_gain = lc_kwargs_dic.get("channel_bin", [1, 1])

        rsp_list = spec_file_kwargs_dic.get("rsp_list", None)
        out_dir = spec_file_kwargs_dic.get("out_dir", "./")

        for index, det in enumerate(det_list):
            det.set_satellite(self.info.satellite)
            det_events_all = self.select_detector(det.number)
            if rsp_list is not None:
                det_rsp_list = rsp_list[index]
            else:
                det_rsp_list = None

            det_c_rsp_list = self.match_det_channel_and_rsp(det, channel_bin_of_high_low_gain, det_rsp_list)
            for gain_type, c_bins, rsp in det_c_rsp_list:
                if gain_type not in det.unique_gain_type_list():
                    continue

                temp_det: Detector = copy.deepcopy(det)
                temp_det.set_gain_type(gain_type), temp_det.set_satellite(self.info.satellite)
                print(temp_det.full_name)

                slice_kwargs_dic["time_range"] = lc_total_range
                this_lc_kwargs_dic["channel_bin"] = c_bins

                det_events = det_events_all.slice(gain_type, **slice_kwargs_dic)

                det_lc = det_events.to_light_curve(**this_lc_kwargs_dic)
                det_bg_lc = det_lc.fit_background(**lc_bg_fit_kwargs_dic)
                spec_file = SpecFile(det_lc, det_bg_lc)

                det_spec_list = []
                for src_range in src_range_list:
                    spec, bg_spec, net_spec = spec_file.add_src(src_range)
                    det_spec_list.append([src_range, spec, bg_spec, net_spec])

                # feature_dic = {
                #     "T90": feature_utils.calculate_time_duration(det_lc, det_bg_lc, bg_range_list,"T90")
                # }

                result[temp_det.full_name] = {"lc": det_lc, "bg_lc": det_bg_lc, "src_spec_list": det_spec_list}

                spec_file.write(out_dir, rsp_path=rsp)

        return result
