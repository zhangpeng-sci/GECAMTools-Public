# spectrum.py: 
#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

from gecam.plot.gecam_plot import GecamPlot


class SpectrumFigure(GecamPlot):

    def __init__(self, spec_data=None, x_type="channel", **kwargs):
        super().__init__(**kwargs)

        self.step_type = "mid"
        self.legend = []

        self.spec_index = 1

        self._temp_y_lim = None
        self.x_type = x_type

        if x_type == "energy":
            xlabel = "Energy (Kev)"
        else:
            xlabel = "Channel"

        font_size = 10
        # initialize the plot axes, labels, ticks, and scales
        self._ax.set_xlabel(xlabel, fontsize=font_size)
        self._ax.set_ylabel('Count Rate (count/s)', fontsize=font_size)
        self._ax.xaxis.set_tick_params(labelsize=font_size)
        self._ax.yaxis.set_tick_params(labelsize=font_size)
        self._ax.set_xscale('linear')
        self._ax.set_yscale('log')

        if spec_data is not None:
            self.add_data(spec_data)

    def add_data(self, spec_data, show_error=True, err_color="#595959", **kwargs):
        kwargs.setdefault("color", "black")
        kwargs.setdefault("linewidth", 1)
        kwargs.setdefault("label", f"spec-{self.spec_index}")
        self.spec_index += 1

        channel_x, energy_x, y, y_err = spec_data

        if self.x_type == "channel":
            x = channel_x
        else:
            x = energy_x

        self._ax.step(x, y, where=self.step_type, **kwargs)

        if y_err is not None and show_error:
            self._ax.errorbar(x, y, yerr=y_err, ls='', color=err_color)

        self._temp_y_lim = self._ax.get_ylim()

    def add_selection(self, spec_data, **kwargs):
        kwargs.setdefault("facecolor", '#9a4e0e')
        kwargs.setdefault("alpha", 0.3)

        channel_x, energy_x, y, y_err = spec_data

        if self.x_type == "channel":
            x = channel_x
        else:
            x = energy_x

        self._ax.fill_between(x, self._temp_y_lim[0], y, step=self.step_type, **kwargs)

    def show_legend(self):
        self._ax.legend()
