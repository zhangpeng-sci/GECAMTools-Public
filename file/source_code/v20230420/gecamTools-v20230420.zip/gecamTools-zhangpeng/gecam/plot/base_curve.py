#
#     Authors: Shaolin Xiong (IHEP), Peng Zhang (IHEP),
#              Wangchen Xue (IHEP), Yanqiu Zhang (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import numpy as np

from gecam.plot.gecam_plot import GecamPlot


class LineFigure(GecamPlot):

    def __init__(self, title="", xlabel="", y_label="", **kwargs):
        super().__init__(**kwargs)

        self.legend = []

        font_size = 10
        self._ax.set_title(title, fontsize=12)
        self._ax.set_xlabel(xlabel, fontsize=font_size)
        self._ax.set_ylabel(y_label, fontsize=font_size)
        self._ax.xaxis.set_tick_params(labelsize=font_size)
        self._ax.yaxis.set_tick_params(labelsize=font_size)
        self._ax.set_xscale('linear')
        self._ax.set_yscale('linear')

    def add_data(self, x=None, y=None, y_err=None, err_color="#595959", **kwargs):
        if y is not None:
            if x is None:
                x=np.arange(0,len(y))

            self._ax.plot(x, y, **kwargs)

        if y_err is not None:
            self._ax.errorbar(x, y, yerr=y_err, ls='', color=err_color)
