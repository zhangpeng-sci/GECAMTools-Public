#       Module containing time-related functions
#           ref gbm-data-tools: https://fermi.gsfc.nasa.gov/ssc/data/analysis/gbm/gbm_data_tools/gdt-docs/index.html
#
#     Authors:Peng Zhang (IHEP),
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import datetime
import warnings

from astropy.time import Time
from astropy.time.formats import TimeFromEpoch


class TimeGecamSec(TimeFromEpoch):
    """Represents the number of seconds elapsed since Jan 1, 2019 00:00:00 UTC
    including leap seconds"""

    name = 'gecam'
    unit = 1.0 / 86400.0  # in days (1 day == 86400 seconds)
    epoch_val = '2019-01-01 00:01:09.184'
    # epoch_val = '2019-01-01 00:00:00'
    epoch_val2 = None
    epoch_scale = 'tt'  # Scale for epoch_val class attribute
    epoch_format = 'iso'  # Format for epoch_val class attribute


class TimeHebsSec(TimeFromEpoch):
    """Represents the number of seconds elapsed since Jan 1, 2019 00:00:00 UTC
    including leap seconds"""

    name = 'hebs'
    unit = 1.0 / 86400.0  # in days (1 day == 86400 seconds)
    epoch_val = '2021-01-01 00:01:09.184'
    # epoch_val = '2019-01-01 00:00:00'
    epoch_val2 = None
    epoch_scale = 'tt'  # Scale for epoch_val class attribute
    epoch_format = 'iso'  # Format for epoch_val class attribute


class TimeHxmtSec(TimeFromEpoch):
    """Represents the number of seconds elapsed since Jan 1, 2019 00:00:00 UTC
    including leap seconds"""

    name = 'hxmt'
    unit = 1.0 / 86400.0  # in days (1 day == 86400 seconds)
    epoch_val = '2012-01-01 00:01:06.184'
    # epoch_val = '2019-01-01 00:00:00'
    epoch_val2 = None
    epoch_scale = 'tt'  # Scale for epoch_val class attribute
    epoch_format = 'iso'  # Format for epoch_val class attribute


class Met:
    """Class representing the Gecam Epoch and allowing time conversions
    to and from it.
    
    ParaGecamMeters:
        secs (float): The GecamMet
    
    Attributes:
        datetime (:class:`datetime.datetime`): A datetime object for the GecamMet
        gps (float): The number of seconds since Jan 6, 1980 00:00:00 
                    (leap seconds are removed)
        jd (float): The Julian Date associated with the GecamMet
        GecamMet (float): The GecamMet
        mjd (float): The modified Julian Date associated with the GecamMet
        time (:class:`astropy.time.Time`): The astropy time object for the GecamMet
        unix (float): The number of seconds since Jan 1, 1970 00:00:00 with 
                      the leap seconds removed
        ymd (str): The GecamMet converted to the form `YYMMDD` in UTC
        ymd_h (str): The GecamMet converted to the form of YYMMDD_HHz in UTC
    """

    # Mission Elapsed Time (Number of seconds since 2019-01-01 00:00:00 UTC)

    def __init__(self, secs, satellite="GECAM"):
        """Creates a GecamMet object with the time set to the number of seconds since Jan 1, 2019 00:00:00 UTC
        including theleap seconds"""
        if secs < 0:
            warnings.warn(f"Time before {satellite} mission epoch")
        self._time = Time(secs, format=satellite)
        self._satellite = satellite

    @property
    def iso(self):
        """Returns the GecamMet value as a string in the form of
        yyyy-mm-ddTHH:MM:SS in UT

        Returns:
            :str: the ISO string
        """
        return self.datetime.strftime("%Y-%m-%dT%H:%M:%S.%f")

    @classmethod
    def from_iso(cls, str_time):
        """Create a new GecamMet object from an ISO-format UTC string
    
        Args:
            str_time (str): The ISO string
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        if '.' in str_time:
            dt = datetime.datetime.strptime(str_time, '%Y-%m-%dT%H:%M:%S.%f')
        else:
            dt = datetime.datetime.strptime(str_time, '%Y-%m-%dT%H:%M:%S')
        return cls.from_datetime(dt)

    @property
    def met(self):
        return self._time.gecam

    # Astropy Time
    @property
    def time(self):
        return self._time

    @classmethod
    def from_time(cls, atime):
        """
        Creates a new GecamMet object from an astropy.Time object
        Args:
            atime (:class:`astropy.time.Time`): The astropy time object

        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        obj = cls(0)
        obj._time = atime
        if obj.met < 0:
            raise Exception(f"Time before {obj._satellite} mission epoch")
        return obj

    # Python's datetime
    @property
    def datetime(self):
        try:
            return self._time.utc.to_datetime(datetime.timezone.utc)
        except ValueError:
            # Repeat last met for a leap second
            return GecamMet(self.met - 1).datetime

    @classmethod
    def from_datetime(cls, dt):
        """Creates a new GecamMet object from a datetime.datetime object
    
        Args:
            dt (:class:`datetime.datetime`): The datetime object
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        return cls.from_time(Time(dt, format='datetime'))

    # Unix timestamp (Number of seconds since 1970-01-01 00:00:00 UTC (leap seconds are ignored))
    @property
    def unix(self):
        return self.datetime.timestamp()

    @classmethod
    def from_unix(cls, unix):
        """Creates a new GecamMet object from a Unix timestamp
    
        Args:
            unix (float): A Unix time
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        return cls.from_datetime(datetime.datetime.utcfromtimestamp(unix))

    # GPS timestamp (Number of seconds since Jan 6, 1980 00:00:00 UTC (leap seconds are ignored))
    @property
    def gps(self):
        return self._time.gps

    @classmethod
    def from_gps(cls, gps):
        """Creates a new GecamMet object from a GPS timestamp
    
        Args:
            gsp (float): A GPS time
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        return cls.from_time(Time(gps, format='gps'))

    # Julian date
    @property
    def jd(self):
        return self._time.jd

    @classmethod
    def from_jd(cls, jd):
        """Creates a new GecamMet object from a Julian Date
    
        Args:
            jd (float): A Julian Date
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        return cls.from_time(Time(jd, format='jd'))

    # Modified Julian Date
    @property
    def mjd(self):
        return self._time.utc.mjd

    @classmethod
    def from_mjd(cls, mjd):
        """Creates a new GecamMet object from a Modified Julian Date
    
        Args:
            mjd (float): A Modified Julian Date
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        return cls.from_time(Time(mjd, format='mjd'))

    # Year, Month, and Day as YYMMDD
    @property
    def ymd(self):
        return self.datetime.strftime("%y%m%d")

    @classmethod
    def from_ymd(cls, ymd):
        """Creates a new GecamMet object from a 'YYMMDD' string
    
        Args:
            ymd (str): A YYMMDD string
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        dt = datetime.datetime.strptime(ymd, '%y%m%d')
        return cls.from_datetime(dt)

    # Year, Month, Day, and Hour as YYMMDD_HH
    @property
    def ymd_h(self):
        return self.datetime.strftime("%y%m%d_%Hz")

    @classmethod
    def from_ymd_h(cls, ymd):
        """Creates a new GecamMet object from a 'YYMMDD_HHz' string
    
        Args:
            ymd (str): A YYMMDD_HHz string
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        dt = datetime.datetime.strptime(ymd, '%y%m%d_%Hz')
        return cls.from_datetime(dt)

    # Current time
    @classmethod
    def now(cls):
        """Creates a new GecamMet object from the current time
    
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        m = cls(0)
        m._time = Time.now()
        return m

    def __repr__(self):
        """Returns a string representation of the GecamMet object"""
        return "<GecamMet seconds = {:.6f}>".format(self.met)

    # Math functions
    def add(self, x):
        """Returns an GecamMet object with its value set to this object's value 
        with x seconds added to it. Can also use the ``+`` operator.
    
        Args:
            x (float): seconds to add
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        if not (isinstance(x, int) or isinstance(x, float)):
            raise ValueError("Can only add int or float to GecamMet")
        return Met(self.met + x)

    def sub(self, x):
        """Returns an GecamMet object with its value set to this object's value 
        with x seconds subtracted from it. Can also use the ``-`` operator.
    
        Args:
            x (float): seconds to subtract
        
        Returns:
            :class:`GecamMet`: The GecamMet object
        """
        if isinstance(x, Met):
            return self.met - x.met
        elif isinstance(x, int) or isinstance(x, float):
            return Met(self.met - x)
        raise ValueError("Can only subtract int, float or GecamMet from GecamMet")


class GecamMet(Met):
    def __init__(self, secs):
        """Creates a GecamMet object with the time set to the number of seconds since Jan 1, 2019 00:00:00 UTC
        including theleap seconds"""
        super().__init__(secs, satellite="gecam")

    @property
    def met(self):
        return self._time.gecam

    def __repr__(self):
        """Returns a string representation of the GecamMet object"""
        return "<GecamMet seconds = {:.6f}>".format(self.met)


class HxmtMet(Met):
    def __init__(self, secs):
        """Creates a GecamMet object with the time set to the number of seconds since Jan 1, 2019 00:00:00 UTC
        including theleap seconds"""
        super().__init__(secs, satellite="hxmt")

    @property
    def met(self):
        return self._time.hxmt

    def __repr__(self):
        """Returns a string representation of the GecamMet object"""
        return "<HxmtMet seconds = {:.6f}>".format(self.met)


class HebsMet(Met):
    def __init__(self, secs):
        """Creates a GecamMet object with the time set to the number of seconds since Jan 1, 2019 00:00:00 UTC
        including theleap seconds"""
        super().__init__(secs, satellite="hebs")

    @property
    def met(self):
        return self._time.hebs

    def __repr__(self):
        """Returns a string representation of the GecamMet object"""
        return "<HebsMet seconds = {:.6f}>".format(self.met)
