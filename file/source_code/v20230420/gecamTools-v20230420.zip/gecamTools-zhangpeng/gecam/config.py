# -*- coding: utf-8 -*- 

# gecam satellite
SATELLITE_LIST = "B"

# time binned of light curve
TIME_BIN = 1.0

# time range of background light curve relative to trigger time
BG_TIME_RANGE = [(-40, -5), (60, 100)]

CHANNEL_BIN = 1

# 0<=channel<498
CHANNEL_RANGE = (0, 498)

# only choose recommend events
ONLY_RECOMMEND = True

# polynomial fit order
POLYNOMIAL_FIT_ORDER = 2

ENERGY_SPLIT_RANGE = [[8.26, 3477.43], [8.26, 19.83],
                      [19.83, 47.85], [47.85, 115.64],
                      [115.64, 215.20], [215.20, 500.96],
                      [500.96, 797.15], [797.15, 1202.82],
                      [1202.82, 1507.21], [1991.60, 3386.35]]

EXPOSURE_MAX_RATE = 0.95

# set image
IMG_SHOW_DPI = 100
IMG_SAVE_DPI = 600
