# test_duration: 
#
#     Authors: Peng Zhang (IHEP), Yanqiu Zhang (IHEP)
#              Wangchen Xue (IHEP), Shaolin Xiong (IHEP)
#
#     Written for the Gravitational wave high-energy Electromagnetic Counterpart All-sky Monitor (GECAM)
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import matplotlib.pyplot as plt

from gecam.data.evt import Evt
from gecam.analysis.burst_duration import BurstDuration
from gecam.data.detector import Detector, GRD
from gecam.time import GecamMet

file_path = "D:\sougou_download\gbg_evt_tn210511_112749_fb_v00.fits"
evt = Evt.open(file_path)

trig_met = evt.info.trig_met

det_list = [GRD(18, gain_type="both"), GRD(17, gain_type="both"), GRD(16, gain_type="both"), GRD(15, gain_type="both")]

set_time_range=None

slice_kwargs_dic = {
    "time_range": [trig_met - 30, trig_met + 40],
    "only_recommend": True
}
lc_kwargs_dic = {
    "time_bin": 0.01,
    "channel_bin": [0, 498]
}
lc_bg_fit_kwargs_dic = {
    "bg_time_range": [[trig_met - 30, trig_met - 5], [trig_met + 15, trig_met + 40]],
    "fit_order": 1
}
duration_obj2 = BurstDuration()
duration_obj2.generate_net_light_curve_with_detectors(evt, det_list, slice_kwargs_dic, lc_kwargs_dic,
                                                      lc_bg_fit_kwargs_dic)
cumsum_lc_fig2 = duration_obj2.plot_light_curve_cumsum(set_time_range=set_time_range)
plt.show()

## 查看净光变

from gecam.plot.light_curve import LightCurveFigure

net_lc_x,net_lc_y,net_lc_y_err=duration_obj2.net_lc_1D_data
lc_bg_range=lc_bg_fit_kwargs_dic.get("bg_time_range")

det_sliced_lc_fig = LightCurveFigure((net_lc_x[:-1],net_lc_y,net_lc_y_err),
                                     trig_time=duration_obj2.evt_info.trig_met, dpi=100)


det_sliced_lc_fig.add_background(bg_time_range=lc_bg_range)

plt.show()

cumsum_bg_range = [[trig_met - 30, trig_met - 5], [trig_met + 9, trig_met + 20]]
t90, t90_err, t50, t50_err = duration_obj2.cal_burst_duration_by_cumsum_counts(cumsum_bg_range)

print("T90:", t90, "T90 error:", t90_err, "T90 start met:", duration_obj2._T90_start)
print("T50:", t50, "T50 error:", t50_err, "T50 start met:", duration_obj2._T50_start)

total_lc_data, net_lc_data = duration_obj2.total_lc_1D_data, duration_obj2.net_lc_1D_data

duration_obj3 = BurstDuration()
duration_obj3.update_custom_data(total_lc_data, net_lc_data)

cumsum_lc_fig3 = duration_obj3.plot_light_curve_cumsum(set_time_range=set_time_range)
plt.show()

cumsum_bg_range = [[trig_met - 30, trig_met - 5], [trig_met + 9, trig_met + 20]]
t90, t90_err, t50, t50_err = duration_obj3.cal_burst_duration_by_cumsum_counts(cumsum_bg_range)

print("T90:", t90, "T90 error:", t90_err, "T90 start met:", duration_obj2._T90_start)
print("T50:", t50, "T50 error:", t50_err, "T50 start met:", duration_obj2._T50_start)

cumsum_lc_fig3_2 = duration_obj3.plot_light_curve_cumsum(set_time_range=set_time_range,ref_time=trig_met)
cumsum_lc_fig3_2.set_xlabel(f"Time (s) since trigger time (T0={GecamMet(trig_met).iso}, {trig_met})")

plt.show()