import setuptools

# ## generate requirements
#  # pip install pipreqs
# #  pipreqs . --encoding=utf8 --force

# Import the version information and other package variables from the gecam package init file
with open('gecam/__init__.py') as f:
    exec(f.read())

if __name__ == '__main__':
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()

    with open("requirements.txt", "r", encoding="utf-8") as f:
        requirements = f.readlines()

    setuptools.setup(
        name="GECAMTools",
        version=__VERSION__,
        author="GECAM",
        author_email="",
        description="The GECAMTools",
        long_description=long_description,
        long_description_content_type="text/markdown",
        # url="https://github.com/pypa/sampleproject",
        packages=setuptools.find_packages(),
        install_requires=requirements,
        python_requires='>=3.6',
        classifiers=[
            "Programming Language :: Python :: 3",
            "License :: OSI Approved :: MIT License",
            "Operating System :: OS Independent",
        ],
    )
