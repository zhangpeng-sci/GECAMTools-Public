gecam.api package
=================

Submodules
----------

gecam.api.plot\_lc module
-------------------------

.. automodule:: gecam.api.plot_lc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gecam.api
   :members:
   :undoc-members:
   :show-inheritance:
