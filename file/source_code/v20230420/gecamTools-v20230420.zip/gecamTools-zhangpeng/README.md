<img src="docs/source/_static/image/logo.jpg" width = "115" height = "100" alt="" align=center />  

# GECAMTools

## 使用说明

### 安装与卸载
1. 所需环境  
    1.1 系统环境：windows、linux、mac  
    1.2 python环境：python版本>=3.6 (不建议安装python 3.9及以上版本)

2. 安装流程  
    2.1 下载源程序  
    gecamTools-master.zip  
    
    2.2 安装  
    2.2.1 仅使用基本功能(即无需生成响应矩阵，可)   
    使用pip进行源码安装，自动安装GECAMTools以及相关依赖库  
    `pip install gecamTools-master.zip`
    
    建议使用Anaconda创建独立的python环境使用，防止出现不同软件的依赖库版本不兼容问题。 [Miniconda使用说明](https://www.jianshu.com/p/7299c2d4d170)
            
    2.2.2 使用全部功能(包含生成响应矩阵)   
    需在linux或mac中安装标定库CALDB   
    CALDB安装流程:    
    (1)从公共服务器上下载最新版的CALDB.(截止2021-12-01，最新版本CALDB的路径为：/gecamfs/soft/CALDB)   
    (2)标定库CALDB下载之后将source /your directory of caldb/software/tools/caldbinit.sh 这句话放环境文件里， 
    /your directory of caldb 这个是用户下载下来的 CALDB 的目录   
    (3)完成之后， source 环境文件，可进入 python，通过 `import RSP_generator` 来检验标定库是否安装成功
    
    将会自动安装GECAMTools以及相关依赖库  
    `pip install gecamTools-master.zip`
    
    2.3 测试  
    `import gecam`

3. 卸载流程  
    `pip uninstall GECAMTools`


***

## 用户手册
[v0.0.6](docs/software/instruction/user/v0.0.6/user.md)   
[v0.0.2](docs/software/instruction/user/v0.0.2/user.md)  
[v0.0.1](docs/software/instruction/user/v0.0.2/user.md)

***
## 更新日志

### v0.0.6

一、 修改项：   
1. <font color=#008000> 生成响应文件（新增）</font>
2. <font color=orange>生成能谱文件（修复能谱生成中的细节问题）</font>

二、 功能：  

1. 显示光变
2. 显示能谱
3. 生成能谱文件
4. 时间转换
5. 生成响应文件（依赖于GECAM CALDB）

***

### v0.0.2

一、 修改项： 
1. <font color=#008000>时间转换（新增）</font>
2. <font color=orange>生成能谱文件（修复本底拟合错误）</font>

二、 功能：  

1. 显示光变
2. 显示能谱
3. 生成能谱文件
4. 时间转换
***

### v0.0.1

初始版本，功能：

1. 显示光变
2. 显示能谱
3. 生成能谱文件


***

## 开发手册  
[合作开发手册](docs/software/instruction/developer/developer.md)
